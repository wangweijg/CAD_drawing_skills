---
title: 2026-09-04 模板更新 + 敏感词清理进度
tags: [CAD, 进度, 模板, 敏感词]
created: 2026-09-04
status: 进行中
---

# 2026-09-04 技能包更新进度

> 任务来源：王工指示「读取 J:\test_0100 调整后的模板 → 替换技能包内文件 → 删除技能包中铭嘉/具体项目名称」。

## 一、已完成 ✅

### 1. 环境核验
- Python 3.11.15 + `ezdxf 1.4.4` + `matplotlib 3.11.1` + `comtypes 1.4.16` 齐备。
- `quick_validate.py` → `OK | entities=723 | errors=0`。
- 新增图种生成器抽查：`gen_frame.py A2/A4` → 审计错误 0。

### 2. 主源映射（J:\test_0100 → 本包）
test_0100 的 TEST-002 模版已由旧版 **AC1009（GBK 乱码）更新为 AC1032（中文正常读取）**——这是"调整"内容。直接对应 3 张：

| test_0100（调整后） | 本包模板 |
|---|---|
| `TEST_002_Z_101` 墙柱平面布置图 | `真实剪力墙_Z1101` |
| `TEST_002_L_001` 地梁平面布置图 | `真实楼层墙图_l1001` |
| `TEST_002_B_001` 一层顶板配筋图 | `真实楼层平面_B1001` |

### 3. 模板替换
用包自带 `template_library.add_template` 从调整后的 3 个 AC1032 源重新提取并覆盖本包这 3 个模板（各写入 4 件套：.dxf / .template.json / _文本索引.txt / _构件参数.txt）。
- **旧版已备份** 至 `_archive/real_tpl_old_20260904/`，可随时还原。

### 4. 脚本敏感词清理（全部完成，残留 0）
- **代码标识符中立化**（保留"真实工程样式"语义）：
  - `mingjia` → `real`
  - `mingjia_flat` → `real_flat`
  - `MINGJIA_TEXT_H/LINE_GAP/LAYER/STYLE` → `REAL_*`
  - `MUL_MINGJIA` → `MUL_REAL`
  - 涉及文件：`cad_beam_label.py`、`cad_draw_beams.py`、`cad_draw_frame.py`（`--label-style` 可选值现在为 `today / real / real_flat`）。
- **具体项目名中立化**：`苏州风范项目` → `示例项目`（`gen_dxf_6x2.py`、`structural_demo_template.py` 的标题栏"项目名称"）。
- **措辞清理**：删除/改写 `cad_standards.py`、`gen_wall_plan.py`、`gen_arch_plan.py`、`gen_dxf_layout.py`、`template_library.py`、`cad_beam_label.py`、`cad_draw_beams.py` 中的"铭嘉/河北铭嘉/对齐铭嘉"等措辞。

## 二、未完成 ⏳

### 1. 文档敏感词清理（残留 25 处）— 正在做
以下文件仍含 `铭嘉`/`苏州风范`，**未清理**：
- `SKILL.md`（约 17 处）
- `README.md`（line 97）
- `ROADMAP.md`（line 53/75/79）
- `SETUP.md`（line 95）
- `cases/2026-09-04_五图种拓展_*.md`（line 5/20/32）

> 建议统一替换规则：
> - `铭嘉真实工程` → `真实工程`
> - `对齐铭嘉真实` → `对齐真实`
> - `铭嘉机构标准` → `机构标准`
> - `铭嘉 DXF` → `真实 DXF`
> - `铭嘉真实样图/标题栏/模板` → `真实样图/真实标题栏/真实模板`
> - `河北铭嘉工程设计有限公司` → `真实工程`（或按语境）
> - `苏州风范项目` → `示例项目`
> - 文档中 `"mingjia"` 样式名 → `"real"`（与脚本一致）

### 2. 最终校验
- 清理后用 `grep -rniE '铭嘉|苏州|风范|mingjia'` 确认全包 0 残留。
- 跑 `quick_validate.py`（errors=0）+ `template_library --list`（16 模板）+ `gen_frame` 抽查，确认识别符改名后脚本仍正常运行。

### 3. 回同步到 Hermes 安装副本
把改好的 **J:\CAD_drawing_skills（权威主源）** 重新同步到 `D:\hermes_MJ\skills\cad-automation\CAD_drawing_skills`，保持 Hermes 加载版本与主源一致。

### 4. 附带的 cad-automation 主包（D:\hermes_MJ\skills\cad-automation\SKILL.md）
该入口技能也含"铭嘉/机构"措辞与旧数量描述，**未清理**；脚本改名后其文档需同步（`--label-style real`）。是否一并清理由王工确认。

## 三、待决/暂缓（未做，等王工定夺）

1. **真实图框 A0–A4 DWG → DXF 替换自建图框**（ROADMAP 待办 #3）：`J:\test_0100\图框\A0~A4_1_100.dwg` 需调 AutoCAD COM 转 DXF，有授权/稳定风险，**本次未做**。
2. **批量导入 test_0100 全部模版**（Z_101-105、Z_201-205 柱表、B/L 各楼层、JC 基础）进模板库：按"精确执行不扩大范围"未做，如需可另批处理。

## 四、口径说明
- 本次仅替换与 test_0100 直接对应的 3 个真实模板，其余自建模板（图框/柱/梁/板/楼梯/桩基/剪力墙 demo 等）**未动**。
- 敏感词清理目标是"铭嘉 + 具体项目名（苏州风范）"；全包经查**无** 唐山/裕隆/煤医 等其它项目名。
