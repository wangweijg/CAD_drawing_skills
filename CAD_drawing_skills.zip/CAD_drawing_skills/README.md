---
title: CAD 结构施工图离线生成（22G101 平法）
tags: [CAD, 结构设计, 22G101, ezdxf, DXF, Python]
created: 2026-08-04
updated: 2026-09-04
---

# CAD 结构施工图生成包（22G101 平法 · 离线 + 实时）

用 Python + `ezdxf` **离线生成**符合 **22G101 平法** 的结构施工图 DXF；也可用 `comtypes` **实时直连已打开的 AutoCAD**，把轴网 / 柱 / 梁直接画到画布上（所见即所得）。
适用于绿色版 / 精简版 AutoCAD，以及已注册 COM、可脚本实时交互的环境。

> **拓展（2026-09-04）**：已把技能包从「仅框架梁/柱/板」拓展到 **框架、剪力墙、基础/桩基、楼梯、建筑图** 五大类，新增 5 个离线生成器（详见 `ROADMAP.md`）。

## 目录结构

```
CAD_drawing_skills/
├── README.md                      ← 本文件
├── ROADMAP.md                     ← 拓展路线图（四大类图种落地）
├── SETUP.md                       ← 换机部署说明（别的电脑接着干看这个）
├── SKILL.md                       ← 完整技能文档（绘图规范 + 踩坑清单）
├── skills、cases/                 ← 成功案例存档
├── scripts/
│   ├── cad_standards.py           ← 唯一权威标准源（70 层图层 / 文字样式 / DIM100 / 几何常量）
│   ├── cad_live.py                ← COM 基础库（连接 / 点坐标 / 标准同步 / 清理 / 柱填充）
│   ├── cad_draw_axis.py           ← 实时画参数化轴网（规范三层分离 + 双侧两级尺寸）
│   ├── cad_draw_columns.py        ← 实时画轴网节点框架柱（轮廓 + 涂黑 + 编号）
│   ├── cad_draw_beams.py          ← 实时画框架梁（双线 + 平法标注）
│   ├── gen_frame.py               ← ★离线 A0–A4 全套图框（2026-09-04 新增）
│   ├── gen_wall_plan.py           ← ★离线剪力墙平法施工图（2026-09-04 新增）
│   ├── gen_foundation.py          ← ★离线基础/桩基平法施工图（2026-09-04 新增）
│   ├── gen_stair.py               ← ★离线楼梯平法施工图（2026-09-04 新增）
│   ├── gen_arch_plan.py           ← ★离线建筑平面施工图（2026-09-04 新增）
│   ├── gen_slab_rebar_plan.py   ← ★离线楼板配筋平面图（分离式·定版，2026-09-04 新增）
│   ├── dxf_to_cad.py              ← 离线 DXF → 实时 CAD 流式映射器
│   ├── gen_dxf_6x2.py             ← 离线样例：6×2 梁板平法施工图
│   ├── structural_demo_template.py ← 离线样例：双平面结构图（最新版，可复制作模板）
│   ├── render_preview.py / pil_render.py ← DXF → PNG 预览自检（pil_render 已支持 \U+ 中文）
│   ├── quick_validate.py          ← 跑一遍脚本 + ezdxf 审计
│   └── gen_smoke_test.py          ← 最小 DXF 冒烟测试
├── output/                        ← 生成的 DXF / PNG 预览
└── _archive/                      ← 旧版文档（含已废弃的天正 / TSSD 配置，仅留档）
```

> **换到别的电脑接着做？** 先看 [[SETUP.md]]。本包没有任何自动同步，必须用 Git / 网盘 / U 盘主动搬运；所有脚本路径已相对化，整个文件夹可任意搬迁。

## 快速使用

```bash
pip install ezdxf matplotlib        # 出 PNG 预览需 matplotlib；直连 CAD 再加 comtypes
cd <本包>/scripts

# 原：框架梁板施工图（离线上+下双平面）
python structural_demo_template.py

# ★新增：A0–A4 图框
python gen_frame.py --size A0 A1 A2 A3 A4

# ★新增：剪力墙平法
python gen_wall_plan.py

# ★新增：基础/桩基平法
python gen_foundation.py

# ★新增：楼梯平法
python gen_stair.py

# ★新增：建筑平面
python gen_arch_plan.py --floor 二层 --project 某项目

python quick_validate.py            # 自检：errors=0 即通过
```

### 实时直连已打开的 AutoCAD（所见即所得）

```bash
# 依赖多一个 comtypes；移除提权标记后（_fix_runasadmin.py）CAD 与脚本都用普通用户
python cad_draw_axis.py     --x-spans 5 --x-gap 4000 --y-spans 3 --y-gap 5700
python cad_draw_columns.py  --x-spans 5 --x-gap 4000 --y-spans 3 --y-gap 5700 --size 500
python cad_draw_beams.py    --x-spans 5 --x-gap 4000 --y-spans 3 --y-gap 5700 --col-size 500
```

## 图纸内容

一份 DXF 内含上下两张平面图，轴网 / 柱 / 梁布置完全相同，仅标注不同：

| 位置 | 图名 | 依据 |
|---|---|---|
| 下图 | 结构标准层梁平法施工图 | 22G101-1 第 4 章 |
| 上图（Y+22000） | 结构标准层楼板配筋平面图 | 22G101-1 第 5 章（有梁楼盖） |

- 梁：集中标注 5 项 + 原位标注 + 附加吊筋
- 板：LB 板块编号、`B:X&Y` 贯通筋、支座非贯通纵筋
- 当前规模：**723 实体，ezdxf 审计 0 错误**

> **拓展（2026-09-04）新增图种**（均离线，审计 0 错误，已入模板库，现 16 个模板）：
> - **剪力墙**（`gen_wall_plan.py`）：墙身双线 + 边缘构件 GBZ(填充) + 连梁 LL + 墙身 Q 编号 + 洞口 + 墙身详图(分布筋/拉筋)。图层对齐真实 Z-1101（`S-WALL` 黄2 / `S-WALL_NUM` 220）。
> - **基础/桩基**（`gen_foundation.py`）：桩承台 CT 平面布置(S-FOUND) + 桩位圈(S-PILE) + 柱位(S-FOUND_INNER) + 承台/桩详图。
> - **楼梯**（`gen_stair.py`）：楼梯平面(梯段+踏步+上/下) + 剖面(踏步 h×b + 梯板厚 + AT1 平法标注 + 上下部/分布筋)。
> - **建筑平面**（`gen_arch_plan.py`）：外墙 200/内墙 120 双线 + 窗四线 + 门(扇+弧) + 房间名称/面积 + 门窗编号（自建 `A-*` 建筑图层）。
> - **图框 A0–A4**（`gen_frame.py`）：GB/T 50001 幅面，标题栏四格（图名/比例/图号/日期/设计）。
> - **楼板配筋**（`gen_slab_rebar_plan.py`）：分离式配筋(22G101 §5.2)，负筋实心红条+`附加→Φ8@200`标文平行、外伸0.25短跨、同尺寸板只注一块全注其余只注板名（定版，见 `cases/2026-09-04_楼板配筋定版.md`）。
> - 详见 `ROADMAP.md`；样例截图见 `cases/2026-09-04_五图种拓展_*.md`。

## 关键踩坑（血泪，务必先看）

1. **线型名必须是 AutoCAD 标准名** —— 写 `DOTE` 会让 CAD 直接报"线型未定义"拒绝加载，正确是 `DOT`；梁线型用 `DASHED` 而非 `DASH`。
2. **必须调用 `finalize_view()`** —— 只改 `$EXTMIN/$EXTMAX` 无效，必须写 `msp.dxf.extmin/extmax`，否则 CAD 打开一片空白。
3. **禁用第三方插件字体**（天正 / TSSD 系列）—— 换机就丢字体，文字全变 `?`。只用 `GBENOR + GBCBIG`、`txt.shx`。（配筋符号 `%%132` 用 `TSSD_Rein` = tssdeng+gbcbig，真实模板即如此。）
4. **标注不要依赖 `_ArchTick` 块** —— 用 `DIMTSZ=0.5` 建筑斜线代替。
5. **输出 R2000(AC1015)** 兼容性最好。
6. **重新生成前先在 CAD 里关掉图纸**，否则写入失败（残留 `.dwl/.dwl2`）。
7. 板支座负筋的弯钩和伸出长度必须指向板内，编号带短引线引出。
8. **实时绘图缺 `comtypes`** —— 先 `pip install comtypes`。
9. **实时绘图连不上 CAD（0x800401E3）** —— 多为 acad.exe 被打 `RUNASADMIN`；跑 `_fix_runasadmin.py` 移除后两者都用普通用户。
10. **中文存储方式** —— 技能真实模板（图框/柱表）以 `\U+XXXX` unicode 转义存中文（CAD 原生正常显示）；`pil_render.decode()` 已支持该转义，PNG 预览中文可读。

详细规范见 [[SKILL.md]]。
