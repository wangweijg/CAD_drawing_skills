---
title: 换机部署说明（家里电脑 / 新环境）
tags: [CAD, 部署, 环境配置]
created: 2026-08-04
---

# 换机部署说明

在一台全新的电脑上跑通这套 DXF 生成流程，只需三步。

## 1. 拿到文件

本包 **不含任何自动同步机制**，必须主动搬运。三选一：

| 方式 | 操作 | 适合 |
|---|---|---|
| **Git（推荐）** | 本目录已是 git 仓库，推到 GitHub 后在家 `git clone` | 长期迭代、要版本历史 |
| 网盘 | 把整个文件夹丢进坚果云 / OneDrive 同步目录 | 不想碰命令行 |
| U 盘 | 整个文件夹拷走（约 500KB） | 一次性 |

Git 方式（首次）：

```bash
# 当前电脑（仓库已初始化，按需添加远端并推送）
cd <本包所在目录>/CAD_drawing_skills
git remote add origin <你的仓库地址>
git push -u origin main

# 另一台电脑
git clone <你的仓库地址>
```

之后每次改完：本机 `git add -A && git commit -m "..." && git push`，另一台 `git pull`。

> 注：若不想推远端，用网盘（坚果云 / OneDrive）同步整个文件夹，或 U 盘拷贝均可——
> 本包是纯文本 + 标准文件，整个目录约几百 KB。

## 2. 装 Python 环境

三个依赖（前两个离线出图用，第三个实时绘图用）：

```bash
pip install ezdxf matplotlib comtypes
```

- `ezdxf` —— 生成 DXF 的核心库，本包基于 **1.4.4** 开发
- `matplotlib` —— 仅 `render_preview.py` 出 PNG 预览时用，不出预览可不装
- `comtypes` —— **实时直连已打开的 AutoCAD 必须**（CAD 实时绘制链路），没装会报 `ModuleNotFoundError: comtypes`

Python 3.9+ 均可（公司这台用的是 3.13）。

离线出图验证：

```bash
cd scripts
python quick_validate.py
# 期望输出：OK | entities=723 | errors=0 | EXTMIN=(-7940,-8360) | EXTMAX=(30940,41860) | ...
```

只要 `errors=0` 且实体数对得上，环境就没问题。

实时绘图（可选，需本机装了 AutoCAD 且已注册 COM）额外验证：

```bash
python -c "import comtypes, comtypes.client; print('comtypes OK')"   # 确认 comtypes 可用
python _fix_runasadmin.py                                            # 清掉 acad.exe 提权标记（如有）
# 打开 AutoCAD（普通用户即可），再：
python cad_draw_axis.py --x-spans 5 --x-gap 4000 --y-spans 3 --y-gap 5700
# 若 CAD 里出现轴网即联通成功；连不上见下方「实时绘图前提」
```

## 3.（可选）装回 WorkBuddy 技能

本技能包自包含：`SKILL.md` + `scripts/` + `templates/` + `references/`。
装到任意 AI 助手：把整个技能包目录复制/解压到其技能目录；其它 AI 直接把整个文件夹喂给它、让它先读 `SKILL.md` 即可。

不用 WorkBuddy 就忽略这一步，`scripts/` 里的脚本本身是纯 Python，独立可跑。

## 4. 在别的 AI 智能体上接力（核心疑问解答）

**结论：完全可行。** 本技能包本质是「纯文本文档 + 标准文件」，不绑定任何特定 AI，换一个智能体照样能读懂并接着干。

技能里**没有**机器专属依赖：所有 `*.py` 脚本路径均已相对化、DXF 用国标 SHX 字体（CAD 自带，无需安装）、Python 只依赖标准库 + `ezdxf` + `comtypes`。脚本直接 `python scripts\xxx.py` 运行，不写死任何本机用户名/盘符。

唯一需要按本机情况调整的是 AutoCAD 侧的两件事（与脚本无关、不影响代码可移植性）：
- **COM 注册**：绿色版 AutoCAD 需以管理员跑一次 `acad.exe /regserver`（一次性，写进注册表）；
- **权限对齐**：CAD 与脚本须同一完整性级别。推荐两者都用普通用户；若 acad.exe 被打了
  `RUNASADMIN` 标记导致连不上，跑 `python scripts/_fix_runasadmin.py` 移除即可。

> 历史说明：旧版本曾把本机 venv 绝对路径硬编码进启动脚本。现已全部移除，本包不含任何本机固定路径。

按你用的智能体分两种接法：

### 场景 A：家里也用 WorkBuddy（最顺滑）
把整个技能包目录复制到目标 AI 的技能目录（或把 zip 解压过去），重启后 AI 能**原生加载**这个技能，体验和你现在一样——它会自动按 22G101 规范 + 机构标准出图。

### 场景 B：用别的 AI（Claude / ChatGPT / Gemini / Cursor / Cline / 任意对话框）
这些不会自动识别 `SKILL.md` 的 frontmatter，但能**把文档当文本读**。做法是：
1. 把整个 `CAD_drawing_skills/` 文件夹喂给新智能体（上传或让其读取）；
2. 明确告诉它：*「先读 `README.md` 和 `SKILL.md`，理解 22G101 平法规则与踩坑，然后在 `scripts/structural_demo_template.py` 上继续修改」*；
3. 它读完后具备和你现在一样的领域知识，可以直接接着改梁/柱/板配筋、加平面、调标注；
4. 改完跑 `python scripts/quick_validate.py` 验证（`errors=0` 即合格）。

> 提示：`SKILL.md` 正文就是完整的绘图规范与踩坑清单，对**任何** AI 都是可读的知识；frontmatter 只是 WorkBuddy 的加载标记，别的 AI 忽略它即可。

### 接力时的关键交接点（建议在新对话里复述给 AI）
- **当前成果**：`output/structural_demo_v7_r2000.dxf`（R2000，723 实体，`errors=0`），含下方梁平法 + 上方楼板配筋双平面。
- **改动入口**：所有图形逻辑在 `scripts/structural_demo_template.py`，已抽成可复用函数（轴网/柱/梁/板负筋各一）。
- **七条铁律**（详见 README「关键踩坑」）：线型名用 `DOT` 非 `DOTE`；视图范围必须设 `msp.dxf.extmin/extmax`；禁用第三方字体；标注斜线用 `DIMTSZ` 非块；存 R2000 兜底；改图前先关 CAD 释放锁；板负筋弯钩指向板内。

## 5. 常见问题

**Q：家里没装 AutoCAD 怎么看图？**
跑 `python render_preview.py` 出 PNG 预览就能看。要正经改图还是得 CAD，或用免费的 LibreCAD / QCAD 打开 DXF。

**Q：`quick_validate.py` 报 `ModuleNotFoundError: ezdxf`？**
没装依赖，回到第 2 步。注意如果用虚拟环境，要确认跑脚本用的是同一个解释器。

**Q：生成时报权限错误 / 文件被占用？**
CAD 里还开着那张图，先关掉。目录里若残留 `.dwl` / `.dwl2` 锁文件，删掉即可。

**Q：CAD 打开一片空白 / 报线型未定义？**
这两个坑已经在脚本里修好了，详见 `README.md` 的「关键踩坑」和 `SKILL.md`。真遇到就先跑 `gen_smoke_test.py` 出个最小文件，确认是 CAD 环境问题还是脚本问题。
