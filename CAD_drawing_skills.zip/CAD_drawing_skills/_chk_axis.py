# -*- coding: utf-8 -*-
import ezdxf, io, sys, collections
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

p = r"C:\Users\wangw\.hermes\desktop-attachments\轴线.dxf"
doc = ezdxf.readfile(p)
print("=== 用户提供的 轴线.dxf (真实模板) ===")
print("layers:", [(l.dxf.name, l.dxf.color, l.dxf.linetype) for l in doc.layers])
print("linetypes:", [(lt.dxf.name, lt.dxf.description) for lt in doc.linetypes])
print("styles:", [(s.dxf.name, s.dxf.font, s.dxf.bigfont) for s in doc.styles])
print("dimstyles:", [(d.dxf.name, d.dxf.dimscale, d.dxf.dimasz, d.dxf.dimtxt, getattr(d.dxf,'dimblk',None), getattr(d.dxf,'dimtad',None)) for d in doc.dimstyles])
msp = doc.modelspace()
def typ(e):
    v = getattr(e, 'dxftype', None); return v() if callable(v) else v
c = collections.Counter(typ(e) for e in msp)
print("ent types:", dict(c))
for e in msp:
    at = ""
    if typ(e) == 'LINE':
        at = "start=%s end=%s" % (tuple(round(x,1) for x in e.dxf.start), tuple(round(x,1) for x in e.dxf.end))
    print("  ", type(e).__name__, "layer=", e.dxf.layer, "ltype=", getattr(e.dxf,'linetype',None), at)
