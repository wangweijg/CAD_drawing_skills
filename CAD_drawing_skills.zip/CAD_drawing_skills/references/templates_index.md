# 模板库总索引（2026-09-05 更新）

模板库位置：技能包内 `templates/`（自包含；`template_library.py` 定位：环境变量 `CAD_TEMPLATE_LIB` → 包内 `templates/`）
数据源：本机 `I:/Obsidian_Data/60_AI/DXF/` 下真实工程 DXF（图框_A1 / 柱子_详图 / 梁_平面配筋 / 楼板_平面配筋）＋ 自建模板（`柱子_详图_600x600`）＋ **2026-09-05 入库 TEST-005 天正真实图纸**（3 建筑 1 结构）
访问方式：`python scripts/template_library.py --list/--info/--layers/--grep/--diff/--beam-format/--add`

每个模板 4 件套：
- `<名>.template.json` — 完整结构化数据（图层/文字样式/标注样式/图块/构件/文本索引）
- `<名>_文本索引.txt` — 按图层分组的全部文字（坐标/字高/旋转）
- `<名>_构件参数.txt` — 构件统计摘要（梁/柱/板/墙 数量与清单）
- `<名>.dxf` — 原始 DXF 副本（保留源文件名，可双击打开对照）

## 模板一览
| 模板 | 类型 | CAD版本 | 图层 | 文本 | 构件 |
|------|------|---------|------|------|------|
| `建筑平面_小户型_5600x6800` | 建筑平面图 | AC1015 | 10 | 27 | 其他27 |
| `真实结构_G1G2G4柱梁板配筋` | 结构配筋图 | AC1032 | 76 | 5469 | 梁2855 柱76 板327 其他2211 |
| `真实建筑_G4平立剖门窗表` | 建筑图 | AC1032 | 42 | 21 | 其他21 |
| `真实建筑_G2门窗墙身详图` | 建筑详图 | AC1032 | 59 | 44 | 其他44 |
| `真实建筑_G1墙身详图` | 建筑详图 | AC1032 | 59 | 43 | 其他43 |
| `建筑平面_5600x4_3500x4` | 建筑平面图 | AC1015 | 11 | 60 | 其他60 |
| `楼板配筋_demo_5800x5_4500x4` | 楼板配筋图 | AC1015 | 15 | 162 | 板136 其他26 |
| `楼板配筋_demo_4500x4_3000x2` | 楼板配筋图 | AC1015 | 17 | 36 | 板16 其他20 |
| `条形基础_TJdemo` | 基础平面图 | AC1015 | 8 | 29 | 柱2 其他27 |
| `独立基础_DJdemo` | 基础平面图 | AC1015 | 9 | 44 | 柱2 其他42 |
| `结构设计总说明` | 结构总说明 | AC1015 | 6 | 33 | 其他33 |
| `建筑平面_住宅一居` | 建筑平面图 | AC1015 | 9 | 35 | 其他35 |
| `楼梯平法_AT1demo` | 楼梯详图 | AC1015 | 6 | 10 | 柱1 其他9 |
| `桩基承台_平面demo` | 基础平面图 | AC1015 | 13 | 124 | 柱2 其他122 |
| `剪力墙布置图_demo` | 剪力墙平法图 | AC1015 | 16 | 45 | 柱6 其他39 |
| `真实楼层墙图_l1001` | 楼层平面图 | AC1009 | 17 | 248 | 柱65 其他183 |
| `真实楼层平面_B1001` | 楼层平面图 | AC1009 | 28 | 131 | 柱25 其他106 |
| `真实剪力墙_Z1101` | 剪力墙平法图 | AC1009 | 15 | 177 | 柱27 其他150 |
| `图框_A4` | A4图框 | AC1015 | 5 | 5 | 其他5 |
| `图框_A3` | A3图框 | AC1015 | 5 | 5 | 其他5 |
| `图框_A2` | A2图框 | AC1015 | 5 | 5 | 其他5 |
| `图框_A0` | A0图框 | AC1015 | 5 | 5 | 其他5 |
| `图框_A1` | A1图框 | AC1021 | 5 | 1 |  |
| `柱子_详图` | 柱详图 | AC1032 | 9 | 7 | 柱4 其他5 |
| `柱子_详图_600x600` | 柱详图 | AC1015 | 9 | 13 | 柱6 其他7 |
| `梁_平面配筋` | 梁平法配筋图 | AC1009 | 8 | 33 | 梁33 |
| `楼板_平面配筋` | 楼板配筋图 | AC1009 | 10 | 30 | 板30 |

## 图层总表（5 模板并集）

| 图层 | 颜色 | 线型 | 出现于 |
|------|------|------|--------|
| `0` | 7 | CONTINUOUS | 图框_A1、柱子_详图、柱子_详图_600x600、梁_平面配筋、楼板_平面配筋 |
| `Defpoints` | 7 | Continuous | 图框_A1、柱子_详图、柱子_详图_600x600、梁_平面配筋、楼板_平面配筋 |
| `S-BEAM` | 4 | DASH | 梁_平面配筋、楼板_平面配筋 |
| `S-BEAM_TEXT` | 40 | CONTINUOUS | 梁_平面配筋 |
| `S-COLU_DE` | 7 | CONTINUOUS | 柱子_详图、柱子_详图_600x600 |
| `S-COLU_DE_TEXT` | 7 | CONTINUOUS | 柱子_详图、柱子_详图_600x600 |
| `S-COLU_TH` | 6 | CONTINUOUS | 梁_平面配筋、楼板_平面配筋 |
| `S-DIM` | 3 | CONTINUOUS | 图框_A1、柱子_详图、柱子_详图_600x600 |
| `S-DOTE` | 253 | DOTE | 梁_平面配筋、楼板_平面配筋 |
| `S-FLOOR_DOWN_TEXT` | 100 | CONTINUOUS | 楼板_平面配筋 |
| `S-FLOOR_UP_REIN` | 13 | CONTINUOUS | 楼板_平面配筋 |
| `S-FLOOR_UP_TEXT` | 7 | CONTINUOUS | 楼板_平面配筋 |
| `S-PUB_TEXT` | 7 | CONTINUOUS | 柱子_详图、柱子_详图_600x600 |
| `S-PUB_TITLE` | 4 | CONTINUOUS | 图框_A1 |
| `S-REIN` | 1 | CONTINUOUS | 柱子_详图、柱子_详图_600x600 |
| `S-TAB` | 7 | CONTINUOUS | 柱子_详图、柱子_详图_600x600 |
| `S-TAB_TEXT` | 7 | CONTINUOUS | 柱子_详图、柱子_详图_600x600 |
| `S-TEXT` | 7 | CONTINUOUS | 图框_A1、楼板_平面配筋 |
| `S_BEAM` | 4 | CONTINUOUS | 梁_平面配筋、楼板_平面配筋 |
| `S_SUBBEAMHOOP` | 1 | CONTINUOUS | 梁_平面配筋 |

## 与技能 cad_standards.LAYERS 的差异结论

- 模板层数：5 个模板并集 20 个图层；技能 cad_standards 共 46 层。
- 模板有 / 技能无（2 个）：`0`、`Defpoints`
- 技能有 / 模板无（28 个）：`AXIS`、`AXIS_TEXT`、`S-AXIS`、`S-AXIS_TEXT`、`S-BEAM_CON`、`S-BEAM_ID`、`S-BEAM_REBAR`、`S-COLU`、`S-COLU_DIM`、`S-COLU_HATCH`、`S-COLU_NUM`、`S-COLU_TEXT`、`S-DETAIL`、`S-DETAIL_TEXT`、`S-DIM_COOR`、`S-DIM_ELEV`、`S-DIM_IDEN`、`S-DIM_LEAD`、`S-DIM_SYMB`、`S-DRAWING_NUMBER`、`S-FLOOR`、`S-FLOOR_DOWN_REIN`、`S-FLOOR_NUM`、`S-FLOOR_REIN`、`S-FLOOR_TEXT`、`S-HATH`、`S-HATH_LIGHT`、`S-STIRRUP`
- 模板 `S-BEAM` 线型为 `DASH`、`S-DOTE` 为 `DOTE`（TSSD 自定义线型），acad.lin 无此标准名，技能统一用 `DASHED`/`DOT` 保证任何 CAD 都能加载。
- 模板线宽全部为默认（未显式设置），技能按出图需要自定线宽。

## 真实梁集中标注格式（梁_平面配筋 实测）

字高 **300**、行距 **312.5**（系数 1.0417）、文字样式 `TSSD_Rein`、4 行全在 `S-BEAM_TEXT`（ACI 40）。
X 向梁 `r=0` 自上而下；Y 向梁 `r=90` 自左而右。

```
行①  WKL1(2) 300x600    梁号(跨数) 宽x高      ← 乘号是小写 x
行②  %%1328@100/200(2)   箍筋 加密/非加密(肢数)
行③  2%%13218;3%%13218   上部通长;下部通长
行④  N4%%13212           侧面筋（可选）N=抗扭
```

## 真实柱详图（柱子_详图 实测）

实体：LWPOLYLINE×17、LINE×5、TEXT×7、DIMENSION×2；9 个图层（S-COLU_DE / S-REIN / S-TAB / S-TAB_TEXT / S-PUB_TEXT / S-COLU_DE_TEXT / S-DIM / 0 / Defpoints）。

关键文本：`KZ-3`、`8%%13225+4%%13220`、`%%1328@100/200`、`基础顶~3.470`、`角筋4%%13225`、`2%%13225`、`2%%13220`。

## 真实板配筋（楼板_平面配筋 实测）

关键文本：`WB1 h=120`（模板实测为屋面板）、`B:X%%1328@200`、`%%1328@150`、`830/820`（模板实测负筋伸出）。**技能绘制规则（2026-08-12 修订）**：普通楼板编号统一 `B1`（`WB` 仅屋面板）；负筋伸出 **L=板短跨/4 向上取整、从梁边起算**（4500 短跨 → 1125），不再用 830/820。
层：`S-FLOOR_UP_TEXT`(7) / `S-FLOOR_DOWN_TEXT`(100) / `S-FLOOR_UP_REIN`(13)；S-TEXT 备注“未注明板钢筋均为%%1328@200,未注明板编号均为B1”。

模板式实时绘制脚本：`scripts/cad_slab_rebar_template.py`（底筋不画网格仅注写 `B1 h=120`/`B:X%%1328@200`/`Y%%1328@200`；负筋符号跨每个板跨跨中、伸出 L=短跨/4 向上取整（4500→1125）、配筋 `%%1328@200`；无带圈编号；总说明 `未注明板钢筋均为%%1328@200,未注明板编号均为B1`；`%%132`=三级钢；副本区自动补两级 S-DIM 轴网尺寸，`--no-dim-spans` 关闭）。用法：`python cad_slab_rebar_template.py --x-spans 5 --x-gap 4500 --y-spans 2 --y-gap 6000 --beam-b 200 --offset-x 100000`。

## 自建模板：柱子_详图_600x600（2026-08-10）

600×600 柱截面 + 一层框架柱表（KZ-1 / `12%%13222` / `%%1328@100/200` / `基础顶~-3.470`），坐标归零（0~10000），可直接作为新柱详图底图。
实体：LWPOLYLINE×17（12 圆点 + 3 箍筋 + 外框 + 截面）、LINE×7、TEXT×13、DIMENSION×2；9 个图层与真实柱详图一致（S-COLU_DE / S-REIN / S-TAB / S-TAB_TEXT / S-PUB_TEXT / S-COLU_DE_TEXT / S-DIM / 0 / Defpoints）。

**几何已固化（2026-08-10）**：同目录 `柱子_详图_600x600.template.json` 含 geometry 段（外框 7700×10000 / 截面放大 10/3 / 纵筋 12 根外圈（每侧 4 根、角部重合）实心圆点 ×1.5 / 3 道 12 点箍筋 135° 弯钩 / 尺寸偏移 / 柱表 4 行布局），实时脚本 `scripts/cad_column_detail.py` 与离线脚本 `scripts/gen_column_detail.py --frame` 自动读取并逐点重放；配筋文字由 `--name/--rebar/--stirrup/--level` 传入。

## 2026-09-05 入库：TEST-005 天正真实图纸（TSSD 建筑/结构）

数据源：`I:/Obsidian_Data/60_AI/skills_test/CAD_drawing_skills_TEST_data/模版/TEST-005/`，4 张均为 **天正(TCH)+探索者(TSSD) AC1032**（中文可读）。`template_library.add_template` 已加 TCH 实体容错（无标准 `layer` 属性自动跳过）。

| 模板 | 类型 | 图层 | 文本 | 说明 |
|------|------|------|------|------|
| `真实建筑_G1墙身详图` | 建筑详图 | 59 | 43 | 1#楼：一层/二层/三层/屋顶平面、1#4#/2#3#楼梯详图、卫生间详图、墙身详图一~三（1:50）；图签 `C-SHEET-TEXT`，文字样式 `-宋体`/`_ST64S-1` |
| `真实建筑_G2门窗墙身详图` | 建筑详图 | 59 | 44 | 2#楼：各层平面、立面/剖面、门窗大样/门窗表、墙身详图一~五（1:25）；标注样式 `_TCH_ARCH&&25` |
| `真实建筑_G4平立剖门窗表` | 建筑图 | 42 | 21 | 4#楼：一层/屋顶平面（1:100）、立剖面、门窗表、窗大样、墙身详图；含保温复合板/真石漆立面材质说明 |
| `真实结构_G1G2G4柱梁板配筋` | 结构配筋图 | 76 | 5469 | 结构版（TSSD）：KZ 柱表（编号/标高/纵筋/箍筋）、梁板配筋；文字样式 `TSSD_Rein`/`TSSD_Dimension`/`FromPkpm`，标注样式 `TSSD_*_100` 系列；构件 梁2855 柱76 板327 |

**实测结论**：
- 建筑图用 `C-SHEET-TEXT` 做图签标题 + `AXIS/DOTE` 轴网 + `A-*` 建筑层（A-OVER-A-BJ 轮廓/A-ASIS 虚墙线/A-WALL-L 墙线/WALL/COLUMN/WINDOW/STAIR/SURFACE 填充），图名/比例/楼号集中在 `C-SHEET-TEXT`。
- 结构版（`真实结构_G1G2G4柱梁板配筋`）与技能 cad_standards 高度一致：`S-BEAM_TEXT`(40)/`S-DIM`(3)/`S-DOTE`(253 DOTE)/`S-FLOOR_*`/`S-COLU_NUM`(7)/`S-REIN`(1)/`S-TAB_TEXT` 全命中；**模板有/技能无 51 个**（`BASE-CT/BEAM-JZ-*/BEAM-REINDJ/FLOOR_UP_*/S-BEAM_DE_*/S-BOLT/S-COLU-CON/S-DOTE_AI/S-HATH（LIGHT）/S-LOCATION/S-NODE_OVER/S-PPOU/S-SHEET TITLE` 等），属该工程私有命名，**不并入技能通用图层**（避免污染可移植标准）。
- 天正自定义实体（TCH_WALL/TCH_COLUMN/TCH_TEXT…）无标准 `layer`，仅标准实体（LINE/LWPOLYLINE/TEXT/DIM/INSERT/HATCH）进入模板提取；天正私有几何以原始 `.dxf` 副本保留。
- 文字样式 `TSSD_Rein`(font=tssdeng.shx, big=tssdchn.shx) 与技能既有 `TSSD_Rein` 约定一致，印证配筋行必须用 TSSD 字体渲染 `%%132` 三级钢符号。

