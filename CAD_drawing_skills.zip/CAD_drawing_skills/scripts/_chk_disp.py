# -*- coding: utf-8 -*-
import ezdxf, io, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
def typ(e):
    v = getattr(e, 'dxftype', None); return v() if callable(v) else v
p = r"J:/测试结果文件/2026.9.16/楼板配筋平面图_slab_4500x3_5000x3_r2000.dxf"
doc = ezdxf.readfile(p); msp = doc.modelspace()
txts = [e for e in msp if typ(e)=='TEXT' and e.dxf.layer=='S-FLOOR_UP_TEXT']
# 负筋 SOLID 半宽30 沿各横向梁(ys=0,5000,10000?) 轴
sols = [e for e in msp if typ(e)=='SOLID']
# 负筋y系：横向梁位于 ys 处
# 横向长度标：横排(rot0)文字(数值1125)，位于筋下方, 现ym下移200
# 纵向长度标：竖排(rot90)数值，位于筋右侧, 现xm+330
# 先找D轴(最上横向梁)对应筋和配筋标
print("=== 全部长度标与配筋标(样本) ===")
for t in txts[:14]:
    print("  id h=%.0f insert=(%.1f,%.1f) rot=%s text=%r" % (t.dxf.height, t.dxf.insert.x, t.dxf.insert.y, getattr(t.dxf,'rotation',0), t.dxf.text))
print("=== SOLID 负筋(样本) ===")
for s in sols[:6]:
    p0=s.dxf.vtx0;p1=s.dxf.vtx1;p2=s.dxf.vtx2;p3=s.dxf.vtx3
    print("  pts: (%s,%s)(%s,%s)(%s,%s)(%s,%s)" % tuple(round(v,1) for v in (p0[0],p0[1],p1[0],p1[1],p2[0],p2[1],p3[0],p3[1])))
