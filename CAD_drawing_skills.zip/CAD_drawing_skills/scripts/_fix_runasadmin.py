# -*- coding: utf-8 -*-
"""移除 acad.exe 的 RUNASADMIN 兼容性标记，使 AutoCAD 以普通权限启动。
仅操作 HKCU，可逆：重新在 acad.exe 属性→兼容性 勾选即可恢复。
"""
import winreg

KEY = r"Software\Microsoft\Windows NT\CurrentVersion\AppCompatFlags\Layers"

h = winreg.OpenKey(winreg.HKEY_CURRENT_USER, KEY, 0, winreg.KEY_ALL_ACCESS)

# 枚举出所有 acad 相关项
targets = []
i = 0
while True:
    try:
        n, v, _ = winreg.EnumValue(h, i)
    except OSError:
        break
    if "acad" in n.lower() and "RUNASADMIN" in str(v).upper():
        targets.append((n, v))
    i += 1

if not targets:
    print("没有找到 acad 的 RUNASADMIN 标记（可能已清除）")
else:
    for n, v in targets:
        print("待处理: %s -> %s" % (n, v))
        # 保留其它兼容性标记，仅剔除 RUNASADMIN
        parts = [p for p in str(v).split() if p.upper() != "RUNASADMIN"]
        if parts:
            winreg.SetValueEx(h, n, 0, winreg.REG_SZ, " ".join(parts))
            print("  已改为: %s" % " ".join(parts))
        else:
            winreg.DeleteValue(h, n)
            print("  已整条删除")

# 复查
i = 0
left = []
while True:
    try:
        n, v, _ = winreg.EnumValue(h, i)
    except OSError:
        break
    if "acad" in n.lower():
        left.append((n, v))
    i += 1
print("复查剩余 acad 项:", left if left else "无")
print("FIX_DONE")
