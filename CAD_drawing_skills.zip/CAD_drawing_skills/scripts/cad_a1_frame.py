# -*- coding: utf-8 -*-
"""给当前结构平面图套一个 A1 图框（含标题栏）。

实时连接已打开的 AutoCAD，在模型空间按 1:scale 绘制 A1 图框：
  - 外框 + 内框（留装订边 25/10mm）
  - 右下角标题栏（图名 / 比例 / 图号 / 日期 / 设计）
  - 文字与表格线使用标准图层 S-PUB_TITLE / S-TAB / S-TAB_TEXT / S-DRAWING_NUMBER

图框居中于平面内容（默认轴线网格中心 12000,8000），不会压到构件。
重跑本脚本会先清空旧图框再重画（图框独占图层，不影响结构实体）。

用法：
  python cad_a1_frame.py [--scale 100] [--cx 12000] [--cy 8000] [--title 结构平面布置图]
"""
import os
import sys
import array
import time
import comtypes.client as cc
from comtypes.automation import VARIANT

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cad_live as L
import cad_standards as STD

# A1 图纸尺寸（mm）
A1_W_MM = 841.0
A1_H_MM = 594.0
# 内框留边（mm）：左/上 25，右/下 10（国标装订边）
MARGIN_LT_MM = 25.0
MARGIN_RB_MM = 10.0
# 标题栏尺寸（mm）
TB_W_MM = 240.0
TB_H_MM = 60.0

FRAME_LAYERS = ["S-PUB_TITLE", "S-TAB", "S-TAB_TEXT", "S-DRAWING_NUMBER"]


def add_text(msp, txt, x, y, h, layer, align="left", style="Standard"):
    t = msp.AddText(str(txt), L.P(x, y), h)
    try:
        t.Layer = layer
    except Exception:
        pass
    try:
        t.StyleName = style
    except Exception:
        pass
    try:
        t.Height = h
    except Exception:
        pass
    if align == "center":
        try:
            t.Alignment = 4           # acAlignmentMiddleCenter
            t.TextAlignmentPoint = L.P(x, y)
        except Exception:
            pass
    return t


def add_line_h(msp, x0, x1, y, layer):
    ln = msp.AddLine(L.P(x0, y, 0.0), L.P(x1, y, 0.0))
    try:
        ln.Layer = layer
    except Exception:
        pass
    return ln


def add_line_v(msp, x, y0, y1, layer):
    ln = msp.AddLine(L.P(x, y0, 0.0), L.P(x, y1, 0.0))
    try:
        ln.Layer = layer
    except Exception:
        pass
    return ln


def main():
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--scale", type=float, default=100.0, help="出图比例分母，1:scale")
    ap.add_argument("--cx", type=float, default=12000.0, help="平面内容中心 X")
    ap.add_argument("--cy", type=float, default=8000.0, help="平面内容中心 Y")
    ap.add_argument("--title", default="结构平面布置图", help="图名")
    ap.add_argument("--drawno", default="结施-01", help="图号")
    ap.add_argument("--date", default="2026.08.05", help="日期")
    ap.add_argument("--designer", default="王工", help="设计")
    a = ap.parse_args()

    s = a.scale
    FW = A1_W_MM * s
    FH = A1_H_MM * s
    cx, cy = a.cx, a.cy

    acad = L.connect()
    doc = acad.ActiveDocument
    msp = doc.ModelSpace
    print("已连接 ->", doc.Name)
    L.ensure_standards(doc, verbose=True)

    # 清理旧图框（独占图层，不影响结构实体）
    n0 = L.clear_layers(msp, FRAME_LAYERS)
    print("已清理旧图框实体 %d 个" % n0)

    # 外框（居中于内容）
    L.add_rect(msp, cx, cy, FW, FH, layer="S-PUB_TITLE")
    # 内框（留装订边）
    ix = cx - (FW / 2.0 - MARGIN_LT_MM * s)
    iy = cy - (FH / 2.0 - MARGIN_LT_MM * s)
    iw = FW - (MARGIN_LT_MM + MARGIN_RB_MM) * s
    ih = FH - (MARGIN_LT_MM + MARGIN_RB_MM) * s
    L.add_rect(msp, ix + iw / 2.0, iy + ih / 2.0, iw, ih, layer="S-PUB_TITLE")

    # 标题栏（右下角，贴内框右下角外侧？放在内框内右下）
    tbw = TB_W_MM * s
    tbh = TB_H_MM * s
    # 内框右下角
    irx = ix + iw
    iry = iy
    # 标题栏左下角
    tbx0 = irx - tbw
    tby0 = iry
    tbx1 = irx
    tby1 = iry + tbh
    # 标题栏外框
    L.add_rect(msp, (tbx0 + tbx1) / 2.0, (tby0 + tby1) / 2.0,
               tbw, tbh, layer="S-TAB")
    # 分隔线：图名行 / 信息行
    name_h = tbh * 0.45
    y_split1 = tby0 + name_h
    add_line_h(msp, tbx0, tbx1, y_split1, "S-TAB")
    # 信息行再分 4 列
    col_w = tbw / 4.0
    for k in range(1, 4):
        xv = tbx0 + col_w * k
        add_line_v(msp, xv, y_split1, tby1, "S-TAB")

    th_big = 3.5 * s          # 图名字高 ~ 3.5mm 打印
    th_sm = 2.5 * s           # 信息字高 ~ 2.5mm 打印
    # 图名
    add_text(msp, a.title, (tbx0 + tbx1) / 2.0, y_split1 - name_h / 2.0,
             th_big, "S-TAB_TEXT", align="center")
    # 信息行四格
    cells = ["比例 1:%d" % int(s), "图号 %s" % a.drawno,
             "日期 %s" % a.date, "设计 %s" % a.designer]
    for k, c in enumerate(cells):
        xc = tbx0 + col_w * (k + 0.5)
        add_text(msp, c, xc, (y_split1 + tby1) / 2.0, th_sm,
                 "S-TAB_TEXT", align="center")

    L.zoom_extents(doc)
    print("A1 图框已套好：比例 1:%d  外框 %.0f x %.0f  中心 (%g,%g)"
          % (int(s), FW, FH, cx, cy))
    print("COM_LIVE_DRAW=OK")


if __name__ == "__main__":
    main()
