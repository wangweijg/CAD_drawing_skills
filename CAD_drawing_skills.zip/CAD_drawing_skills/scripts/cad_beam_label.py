# -*- coding: utf-8 -*-
"""梁集中标注模版（22G101-1 §4.2.3），实时 CAD (comtypes) 用。

两套样式，用 `style=` 切换；默认直径符号 `%%132`（三级钢 HRB400），配筋行用 TSSD_Rein
字体渲染（2026-08-12 王工规则：未注明钢筋均为三级钢）。

────────────────────────────────────────────────────────────
style="today"  （默认）—— 王工 2026-08-06 在 CAD 里逐条确认的样式
────────────────────────────────────────────────────────────
    第①行  梁号+截面   S-BEAM_ID  (ACI 6 磁红)   例：KL1(5) 250×400
    第②行  箍筋         S-STIRRUP (ACI 2 黄)     例：%%1328@200(2)
    第③行  受力筋       S-STIRRUP (ACI 2 黄)     例：2%%13214; 3%%13218
    第④行  侧面筋(可选) S-STIRRUP (ACI 2 黄)     例：N4%%13212

────────────────────────────────────────────────────────────
style="real" —— 真实工程标准（2026-08-06 从模板库实测反推）
────────────────────────────────────────────────────────────
样本：模板库 `梁_平面配筋`（`template_library.py --beam-format` 实测 5 组梁标注）。

    ⚠️ 真实工程 **没有** S-BEAM_ID / S-STIRRUP 这两层。
       全部 4 行统统落在 S-BEAM_TEXT（ACI 40），靠**实体级颜色覆盖**做区分。
       （王工样图里的磁红/黄，是实体色，不是图层色。）

    行①  KL1(2) 300x600        梁号(跨数) 宽x高      ← 乘号是小写 x，不是 ×
    行②  φ8@100/200(2)         箍筋（加密/非加密(肢数)）
    行③  2φ22;3φ18             上部通长;下部通长（只有上部时省略分号段）
    行④  N4φ12 / G4φ12         侧面筋，N=抗扭 G=构造（可选）
    行⑤  梁顶标高-0.200         （罕见，本模版不做）

    实测参数：字高 300.0、行距 312.5（系数 1.0417）、文字样式 TSSD_Rein。

────────────────────────────────────────────────────────────
方向（两种样式一致，与王工确认的阅读习惯相同）
────────────────────────────────────────────────────────────
    dir='h'  X 向梁（文字 r=0）  ：各行【自上而下】= 梁号 → 箍筋 → 受力筋 → 侧面筋
    dir='v'  Y 向梁（文字 r=90） ：各行【自左而右】= 梁号 → 箍筋 → 受力筋 → 侧面筋
        ⚠️ 早期版本 Y 向用 offset=(2-i)*gap 导致顺序反了，已修正为 offset=i*gap。
           真实模板实测同样是自左而右，已交叉验证。

直径符号：默认 `%%132`（HRB400 三级钢符号 —— 王工 2026-08-12：未注明钢筋均为三级钢），
    配筋行（②③④）用 TSSD_Rein 字体渲染；`%%c`（一级钢 φ）仅作 phi_char/兼容用。
    模板库里存的是真字符 φ(U+03C6)；需要完全对齐时用 phi_char=True。

引出线（with_leader）：本模块默认 False；`cad_draw_beams.py` 默认 True
    （2026-08-12 王工要求补充梁配筋引出线），--no-leader 关闭；仅平面模式（无配筋行）不画。
"""
import sys
import os
import math

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cad_live import P

# ── 直径符号 ──────────────────────────────────────────────
PCT_C = "%%c"         # 一级钢（HPB300）控制序列；仅 phi_char/兼容旧字符串用
PCT_HRB400 = "%%132"  # 三级钢（HRB400）钢筋符号（默认 —— 王工 2026-08-12）
PHI = "\u03c6"        # 真字符 φ，与模板库存储一致

# 梁号行乘号
MUL_TODAY = "\u00d7"   # ×  今天用的
MUL_REAL = "x"      # x  真实工程模板用的

# 模版默认配筋（示例值；符号用 %%132 三级钢，与"未注明钢筋均为三级钢"规则一致）
DEFAULT_STIRRUP = "%%1328@200(2)"
DEFAULT_REINF = "2%%13214; 3%%13218"

# style="today"：王工已确认
BEAM_LABEL_H = 260.0
LINE_GAP = 1.15               # 260×1.15 ≈ 299

# style="real"：模板库实测
REAL_TEXT_H = 300.0
REAL_LINE_GAP = 1.0417     # 300×1.0417 ≈ 312.5
REAL_LAYER = "S-BEAM_TEXT"
REAL_STYLE = "TSSD_Rein"

# 各样式的图层/实体色方案
#   layers : 行①②③④ 各自的图层
#   colors : 行①②③④ 的实体色覆盖（None = 随层）
STYLES = {
    "today": {
        "layers": ["S-BEAM_ID", "S-STIRRUP", "S-STIRRUP", "S-STIRRUP"],
        "colors": [None, None, None, None],
        "text_h": BEAM_LABEL_H,
        "line_gap": LINE_GAP,
        "mul": MUL_TODAY,
        "text_style": "Standard",
        # ①行梁号保持 Standard；②③④配筋行用 TSSD_Rein（支持 %%132 三级钢符号）
        "text_styles": ["Standard", REAL_STYLE, REAL_STYLE, REAL_STYLE],
    },
    "real": {
        "layers": [REAL_LAYER] * 4,
        "colors": [6, 2, 2, 2],          # 实体色覆盖：磁红 / 黄 / 黄 / 黄
        "text_h": REAL_TEXT_H,
        "line_gap": REAL_LINE_GAP,
        "mul": MUL_REAL,
        "text_style": REAL_STYLE,
    },
    # 真实工程原样：单层单色，不做任何颜色覆盖
    "real_flat": {
        "layers": [REAL_LAYER] * 4,
        "colors": [None, None, None, None],
        "text_h": REAL_TEXT_H,
        "line_gap": REAL_LINE_GAP,
        "mul": MUL_REAL,
        "text_style": REAL_STYLE,
    },
}


def _add_text(msp, txt, x, y, layer, text_h, rot=0.0,
              color=None, text_style="Standard", align="center"):
    """在 (x,y) 处写一段居中文字。返回 (ok, fail)。"""
    try:
        t = msp.AddText(str(txt), P(x, y), float(text_h))
        t.Layer = layer
        try:
            t.StyleName = text_style
        except Exception:
            # 样式不存在（如未加载 TSSD 字体）时退回 Standard，不让整行失败
            try:
                t.StyleName = "Standard"
            except Exception:
                pass
        try:
            t.Height = float(text_h)
        except Exception:
            pass
        if rot:
            try:
                t.Rotation = float(rot)
            except Exception:
                pass
        if color is not None:
            try:
                t.color = int(color)      # 实体级 ACI 颜色覆盖
            except Exception:
                try:
                    t.Color = int(color)
                except Exception:
                    pass
        try:
            if align == "left":
                t.Alignment = 0               # 0 = Left（插入点即左缘）
            else:
                t.Alignment = 1               # 1 = Center
                t.TextAlignmentPoint = P(x, y)
        except Exception:
            pass
        return 1, 0
    except Exception:
        return 0, 1


def fmt_stirrup(d=8, dense=100, normal=200, legs=2, phi_char=False):
    """箍筋文本：φ8@100/200(2)；normal=None → φ8@200(2)。"""
    f = PHI if phi_char else PCT_HRB400
    s = "%s%g@%g" % (f, d, dense)
    if normal:
        s += "/%g" % normal
    return s + "(%d)" % legs


def fmt_rebar(top, bottom=None, phi_char=False):
    """纵筋文本：top/bottom 传 [(cnt,d), ...] 或现成字符串。

    例：fmt_rebar([(2,22)], [(3,18)]) -> '2%%13222;3%%13218'
    """
    f = PHI if phi_char else PCT_HRB400

    def one(spec):
        if spec is None:
            return None
        if isinstance(spec, str):
            return spec
        return "+".join("%d%s%g" % (c, f, d) for c, d in spec)

    a, b = one(top), one(bottom)
    return a if not b else "%s;%s" % (a, b)


def fmt_side(cnt, d, kind="N", phi_char=False):
    """侧面筋文本：N=抗扭、G=构造。例 fmt_side(4,12) -> 'N4%%13212'。"""
    f = PHI if phi_char else PCT_HRB400
    return "%s%d%s%g" % (kind, cnt, f, d)


def label_anchor_y(bottom_edge_y, n_lines, text_h, line_gap):
    """多行集中标注：给定「最下面一行」下缘 y，反推基准点（第②行插入点）y。

    行高 th、行距 gap=th*line_gap；基准点对齐第②行（base_i=1，n>1 时）。
    最下面一行 i=n-1 的中心 y_i = y + (base_i-(n-1))*gap，下缘 = y_i - th/2。
    """
    th = float(text_h)
    gap = th * float(line_gap)
    base_i = 1 if n_lines > 1 else 0
    return float(bottom_edge_y) + th / 2.0 - (base_i - (n_lines - 1)) * gap


def draw_beam_label(msp, *, beam_id, spans, bw, bh,
                    stirrup=None, reinf=None, side=None,
                    x, y, dir="h",
                    style="today",
                    text_h=None, line_gap=None,
                    simple=False, id_only=False, phi_char=False,
                    with_leader=False, leader_len=900.0, beam_axis=None,
                    align="center",
                    layer_id=None, layer_reinf=None):
    """画梁集中标注。返回 (ok, fail)。

    参数
    ----
    beam_id   : 梁编号，如 "KL1" / "WKL3"
    spans     : 跨数，如 5
    bw, bh    : 梁宽、梁高（mm）
    stirrup   : 箍筋文本（缺省 DEFAULT_STIRRUP），可用 fmt_stirrup() 生成
    reinf     : 纵筋文本（缺省 DEFAULT_REINF），可用 fmt_rebar() 生成
    side      : 侧面筋文本（第④行，可选），可用 fmt_side() 生成
    x, y      : 标注基准点 = 第②行（箍筋行）的插入点
    dir       : 'h' X向梁（文字水平）/ 'v' Y向梁（文字旋转 90°）
    style     : 'today'(默认,分层磁红+黄) / 'real'(单层实体色) / 'real_flat'
    simple    : True 则只写第①行且省略截面（如 "WKL1(2)"）。
                22G101 惯例：同编号梁只详注一处，其余简注。
    id_only   : True 则只写第①行【含截面】（如 "KL1(4) 250x500"），
                用于没给配筋时只标编号+截面。
    phi_char  : True 用真字符 φ，False（默认）用 %%132 三级钢符号
    text_h / line_gap : 覆盖样式默认值
    with_leader / leader_len / beam_axis : 引出线（默认关）
    layer_id / layer_reinf : 单独覆盖第①行 / 第②③④行的图层
    """
    st = STYLES.get(style)
    if st is None:
        raise ValueError("未知 style=%r，可选：%s" % (style, list(STYLES)))

    th = float(text_h if text_h is not None else st["text_h"])
    lg = float(line_gap if line_gap is not None else st["line_gap"])
    mul = st["mul"]
    tstyle = st["text_style"]
    tstyles = st.get("text_styles") or [tstyle] * 4   # 按行字体（配筋行 TSSD_Rein）

    lay = list(st["layers"])
    if layer_id:
        lay[0] = layer_id
    if layer_reinf:
        lay[1] = lay[2] = lay[3] = layer_reinf
    col = list(st["colors"])

    # ── 组装各行 ──
    if id_only:
        lines = ["%s(%d) %g%s%g" % (beam_id, spans, bw, mul, bh)]
    elif simple:
        lines = ["%s(%d)" % (beam_id, spans)]
    else:
        lines = [
            "%s(%d) %g%s%g" % (beam_id, spans, bw, mul, bh),
            stirrup or DEFAULT_STIRRUP,
            reinf or DEFAULT_REINF,
        ]
        if side:
            lines.append(side)

    if phi_char:
        lines = [str(s).replace(PCT_C, PHI) for s in lines]

    rot = math.pi / 2.0 if dir == "v" else 0.0
    gap = th * lg
    n = len(lines)

    # 基准点 y/x 对齐第②行（箍筋行）；简注时基准点即该行
    base_i = 1 if n > 1 else 0

    # 估算最大文字宽度（%%c/φ 按 1 字计）：居中标注取半宽，左对齐取整宽
    def _wchars(t):
        return len(str(t).replace(PCT_C, "X").replace(PCT_HRB400, "X").replace(PHI, "X"))
    max_w = max(_wchars(t) for t in lines) * 0.72 * th
    left_align = (align == "left" and n > 1)

    ok, fail = 0, 0
    for i, txt in enumerate(lines):
        if dir == "v":
            # 自左而右：i=0 梁号(最左) → i=n-1 侧面筋(最右)
            ox, oy = (i - base_i) * gap, 0.0
            tx = x + ox
        else:
            # 自上而下：i=0 梁号(最上) → i=n-1 侧面筋(最下)
            ox, oy = 0.0, (base_i - i) * gap
            # 左对齐：各行统一从标注块左缘（x - max_w/2）起笔
            tx = x - max_w / 2.0 if left_align else x + ox
        a, b = _add_text(msp, txt, tx, y + oy,
                         lay[min(i, 3)], th, rot,
                         color=col[min(i, 3)], text_style=tstyles[min(i, 3)],
                         align=align if left_align else "center")
        ok += a
        fail += b

    # ── 引出线（本模块默认关；cad_draw_beams 默认开，2026-08-12 王工确认）──
    if with_leader:
        _add_leader(msp, dir, x, y, gap, max_w, th,
                    float(leader_len), beam_axis, n=n, align=align)
    return ok, fail


def label_layers(style="today"):
    """返回该样式用到的图层名集合 —— 供绘制脚本清理旧标注时使用。

    ⚠️ 踩过的坑：清理列表漏了标注层会导致旧文本残留、与新文本叠加，
       进而触发大量"文字重叠"告警。绘制脚本务必用这个函数取层名。
    """
    st = STYLES.get(style) or STYLES["today"]
    return sorted(set(st["layers"]))


def _add_leader(msp, dir, x, y, gap, max_w, text_h, leader_len,
                beam_axis, n=3, align="center"):
    """画左侧/侧方引出线（S-BEAM_ID / 实线）。

    标注基准点 (x,y) = 第②行(箍筋行)插入点（与 draw_beam_label 对齐）。
    dir='h'（X 向梁，标注在梁上方）：从梁截面中心 (x, beam_axis) 起竖向上引，
        在标注块下缘之下横向左引到标注左缘，再沿左缘竖向上引到梁名称行（第①行）
        —— 即「梁中心 → 梁名称左上角」的三段折线（实线、同标注层同色）。
    dir='v'（Y 向梁，标注在梁侧方）：从标注近梁侧边水平引到梁轴线
             （梁在左/右都能指对：取近梁侧边为起点，终点为梁轴线）。
    beam_axis=None 时不画（避免无的放矢）。

    ⚠️ 王工 2026-08-06 实测旧版「引出线画得不好」→ 默认 with_leader=False；
        2026-08-10 按「梁中心 → 梁名称」重做，仍仅在显式开启时使用。
    """
    if beam_axis is None:
        return
    th = float(text_h)
    segs = []  # list of (x1, y1, x2, y2)
    if dir == "h":
        x_left = x - max_w / 2.0
        # 第①行（梁名称）插入点：n>1 时基准为第②行，行距 gap
        y_row0 = y + (1 if n > 1 else 0) * gap
        y_name = y_row0 + th / 2.0           # 第①行上缘（引出线到名称左上角）
        # 最下面一行（第③行，i=n-1）下缘；再往下留 1/4 字高避开文字
        y_bottom = y - (n - 2) * gap - th / 2.0
        y_stub = y_bottom - th * 0.25
        segs.append((x, float(beam_axis), x, y_stub))     # ① 梁中心竖向上引
        segs.append((x, y_stub, x_left, y_stub))          # ② 横向左引
        segs.append((x_left, y_stub, x_left, y_name))     # ③ 沿左缘上引到梁名称
    else:
        y_mid = y
        ba = float(beam_axis)
        # 标注块左缘（第①行梁号行所在侧）：多行左对齐时第①行插入点即块左缘；
        # 居中时再向左让出半字宽，避免引出线插入文字内部。
        base_i = 1 if n > 1 else 0
        block_left = x + (0 - base_i) * gap
        if align != "left" or n <= 1:
            block_left -= max_w / 2.0
        if ba < x:                      # 梁在标注左侧
            start_x = block_left
        else:                           # 梁在标注右侧
            start_x = x + 2.0 * gap + 0.5 * text_h
        segs.append((start_x, y_mid, ba, y_mid))

    for (x1, y1, x2, y2) in segs:
        try:
            ln = msp.AddLine(P(x1, y1), P(x2, y2))
            ln.Layer = "S-BEAM_ID"           # 与梁配筋标注（梁号行）同层同色
            # 实线：不设线型（默认 Continuous）
        except Exception:
            pass


def beam_label_box(beam_id, spans, bw, bh,
                   stirrup=None, reinf=None, side=None,
                   x=0.0, y=0.0, dir="h", style="today",
                   text_h=None, line_gap=None, simple=False):
    """返回梁标注的预估包围盒（世界坐标），用于绘制前重叠/碰撞预检。

    无需真连 CAD，直接按样式常量估算。基准点 (x,y) = 第②行(箍筋行)插入点，
    与 draw_beam_label 对齐。dir='v' 时已按旋转后的实际占据范围展开。

    返回 (x_min, y_min, x_max, y_max)。
    """
    st = STYLES.get(style) or STYLES["today"]
    th = float(text_h if text_h is not None else st["text_h"])
    lg = float(line_gap if line_gap is not None else st["line_gap"])
    mul = st["mul"]
    gap = th * lg

    # 组装各行（与 draw_beam_label 保持一致）
    if simple:
        lines = ["%s(%d)" % (beam_id, spans)]
    else:
        lines = [
            "%s(%d) %g%s%g" % (beam_id, spans, bw, mul, bh),
            stirrup or DEFAULT_STIRRUP,
            reinf or DEFAULT_REINF,
        ]
        if side:
            lines.append(side)

    # 估字宽：SHX 等宽约 0.72×字高；中文 1.0×字高，这里取保守 0.7
    width_per_char = 0.7 * th
    max_w = max(len(str(s)) for s in lines) * width_per_char
    n = len(lines)

    # 基准点对齐第②行（base_i）；各行相对基准点的偏移
    base_i = 1 if n > 1 else 0
    if dir == "v":
        rel_xs = [(i - base_i) * gap for i in range(n)]
        rel_ys = [0.0] * n
    else:
        rel_ys = [(base_i - i) * gap for i in range(n)]
        rel_xs = [0.0] * n

    xs = [x + rx for rx in rel_xs]
    ys = [y + ry for ry in rel_ys]
    x_min = min(xs) - max_w / 2.0
    x_max = max(xs) + max_w / 2.0
    y_min = min(ys) - th / 2.0
    y_max = max(ys) + th / 2.0
    return (x_min, y_min, x_max, y_max)


# CLI 自检：打印各样式的包围盒 + 默认/格式化文本，便于快速核对
if __name__ == "__main__":
    print("=== cad_beam_label 自检 ===")
    for st in ("today", "real", "real_flat"):
        box = beam_label_box("KL1", 2, 250, 500, x=0, y=0, style=st)
        print("  style=%-12s 包围盒=(%.0f,%.0f,%.0f,%.0f)"
              % (st, box[0], box[1], box[2], box[3]))
    print("  默认第②行(箍筋) =", DEFAULT_STIRRUP)
    print("  默认第③行(受力) =", DEFAULT_REINF)
    print("  fmt_stirrup ->", fmt_stirrup(8, 100, 200, 2))
    print("  fmt_rebar    ->", fmt_rebar([(2, 22)], [(3, 18)]))
    print("  fmt_side     ->", fmt_side(4, 12))
    print("  real 第④行(侧面) 示例 = N4%%c12 / G4%%c12")
    print("DONE")
