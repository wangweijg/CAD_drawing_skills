# -*- coding: utf-8 -*-
"""给已画好的梁添加平法集中标注，并绘制放大 4 倍的梁剖面详图。

示例：
  python cad_beam_rebar.py --beam KL5 --spans 3 --section 200x400 \
      --stirrup "8@100/200(2)" --top "2%%c18" --bottom "2%%c20" \
      --x-spans 6 --x-gap 4000 --y-spans 2 --y-gap 8000 --col-size 500

说明：
  - 集中标注放在梁的左侧（Y 向梁）或下侧（X 向梁），带 45° 折线引线。
  - 详图自动放在结构平面图右下角空白处，放大 4 倍绘制。
  - 钢筋直径符号用 %%c，在 CAD 中自动显示为 φ。
"""
import sys
import os
import math
import traceback
import argparse

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cad_standards as STD
from cad_live import connect, P, Pn, ensure_standards, clear_layers, zoom_extents

LOG_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                        "cad_beam_rebar.log")

# 本脚本涉及的图层（重绘时一并清理）
REBAR_LAYERS = ["S-BEAM_REBAR", "S-REIN", "S-STIRRUP", "S-DETAIL", "S-DETAIL_TEXT"]

TXT_H = 260.0              # 集中标注字高
DETAIL_TXT_H = 220.0       # 详图文字字高
DETAIL_SCALE = 4.0         # 详图放大倍数
COVER = 25.0               # 混凝土保护层厚度（mm）
BAR_DIA = 20.0             # 详图中纵筋示意圆直径（放大前）

log_lines = []


def log(msg):
    log_lines.append(str(msg))
    print(msg)
    sys.stdout.flush()


def parse_section(s):
    """解析 '200x400' -> (200.0, 400.0)。"""
    t = str(s).lower().replace("*", "x").replace("×", "x")
    parts = [p for p in t.split("x") if p.strip()]
    if len(parts) != 2:
        raise ValueError("截面格式应为 bxh，如 200x400，收到: %r" % s)
    return (float(parts[0]), float(parts[1]))


def parse_stirrup(s):
    """检查箍筋字符串格式，返回原串。"""
    s = str(s).strip()
    if not s:
        raise ValueError("箍筋不能为空")
    return s


def locate_beam(beam, x_spans, x_gap, y_spans, y_gap, col_size, prefix="KL"):
    """根据梁名和轴网参数，返回梁的几何信息。

    返回 dict：
      direction: 'X' 或 'Y'
      axis: 梁所在轴线坐标
      start, end: 梁起点/终点坐标（沿梁方向）
      mid: 梁中点 (x, y)
      is_edge: 是否边跨梁
    """
    if not beam.startswith(prefix):
        raise ValueError("梁名 %r 不以 %r 开头" % (beam, prefix))
    try:
        n = int(beam[len(prefix):])
    except ValueError:
        raise ValueError("无法从梁名 %r 解析序号" % beam)

    xs = [i * x_gap for i in range(x_spans + 1)]
    ys = [j * y_gap for j in range(y_spans + 1)]

    x_count = len(ys)   # X 向梁数量
    y_count = len(xs)   # Y 向梁数量
    total = x_count + y_count

    if n < 1 or n > total:
        raise ValueError("梁名 %r 超出范围 1~%d" % (beam, total))

    col_hw = col_size / 2.0

    if n <= x_count:
        # X 向梁：沿 y 轴，自下而上
        jy = n - 1
        y = ys[jy]
        direction = "X"
        is_edge = (jy == 0 or jy == len(ys) - 1)
        start = (xs[0] + col_hw, y)
        end = (xs[-1] - col_hw, y)
        mid = ((xs[0] + xs[-1]) / 2.0, y)
    else:
        # Y 向梁：沿 x 轴，自左而右
        ix = n - x_count - 1
        x = xs[ix]
        direction = "Y"
        is_edge = (ix == 0 or ix == len(xs) - 1)
        start = (x, ys[0] + col_hw)
        end = (x, ys[-1] - col_hw)
        mid = (x, (ys[0] + ys[-1]) / 2.0)

    return {
        "direction": direction,
        "axis": x if direction == "Y" else y,
        "start": start,
        "end": end,
        "mid": mid,
        "is_edge": is_edge,
    }


def draw_detail(msp, cx, cy, bw, bh, stirrup, top, bottom, scale=DETAIL_SCALE):
    """在 (cx, cy) 绘制放大 scale 倍的梁剖面详图。"""
    w = bw * scale
    h = bh * scale
    cover = COVER * scale

    # 1) 外框（红色，S-REIN）
    rect = msp.AddLightWeightPolyline(Pn([
        cx - w/2, cy - h/2,
        cx + w/2, cy - h/2,
        cx + w/2, cy + h/2,
        cx - w/2, cy + h/2,
    ]))
    rect.Closed = True
    rect.Layer = "S-REIN"
    try:
        rect.Color = 1
    except Exception:
        pass

    # 2) 箍筋（绿色，S-STIRRUP）
    sw = w - 2 * cover
    sh = h - 2 * cover
    stir = msp.AddLightWeightPolyline(Pn([
        cx - sw/2, cy - sh/2,
        cx + sw/2, cy - sh/2,
        cx + sw/2, cy + sh/2,
        cx - sw/2, cy + sh/2,
    ]))
    stir.Closed = True
    stir.Layer = "S-STIRRUP"
    try:
        stir.Color = 3
    except Exception:
        pass

    # 3) 纵筋（黄色圆点，S-REIN）
    bar_r = (BAR_DIA * scale) / 2.0
    bar_positions = [
        (cx - sw/4, cy + sh/2 - cover/2),   # 左上
        (cx + sw/4, cy + sh/2 - cover/2),   # 右上
        (cx - sw/4, cy - sh/2 + cover/2),   # 左下
        (cx + sw/4, cy - sh/2 + cover/2),   # 右下
    ]
    for bx, by in bar_positions:
        c = msp.AddCircle(P(bx, by), bar_r)
        c.Layer = "S-REIN"
        try:
            c.Color = 2
        except Exception:
            pass

    # 4) 尺寸标注（S-DETAIL）
    off = 600.0
    # 宽度标注
    dim_w = msp.AddDimAligned(
        P(cx - w/2, cy + h/2 + off),
        P(cx + w/2, cy + h/2 + off),
        P(cx - w/2, cy + h/2 + off)
    )
    dim_w.Layer = "S-DETAIL"
    try:
        dim_w.StyleName = STD.DIMSTYLE_NAME
    except Exception:
        pass
    try:
        dim_w.TextOverride = str(int(bw))
    except Exception:
        pass

    # 高度标注
    dim_h = msp.AddDimAligned(
        P(cx - w/2 - off, cy - h/2),
        P(cx - w/2 - off, cy + h/2),
        P(cx - w/2 - off, cy - h/2)
    )
    dim_h.Layer = "S-DETAIL"
    try:
        dim_h.StyleName = STD.DIMSTYLE_NAME
    except Exception:
        pass
    try:
        dim_h.TextOverride = str(int(bh))
    except Exception:
        pass

    # 5) 纵筋引线标注
    lead_len = 800.0
    # 上筋
    tx = cx + w/2 + lead_len
    ty = cy + sh/2 - cover/2 + 200
    msp.AddLine(P(cx + w/2 + 100, cy + sh/2 - cover/2), P(tx - 100, ty)).Layer = "S-DETAIL"
    t1 = msp.AddText(top, P(tx, ty), DETAIL_TXT_H)
    t1.Layer = "S-DETAIL_TEXT"
    try:
        t1.StyleName = "Standard"
        t1.Height = DETAIL_TXT_H
    except Exception:
        pass

    # 下筋
    ty2 = cy - sh/2 + cover/2 - 200
    msp.AddLine(P(cx + w/2 + 100, cy - sh/2 + cover/2), P(tx - 100, ty2)).Layer = "S-DETAIL"
    t2 = msp.AddText(bottom, P(tx, ty2), DETAIL_TXT_H)
    t2.Layer = "S-DETAIL_TEXT"
    try:
        t2.StyleName = "Standard"
        t2.Height = DETAIL_TXT_H
    except Exception:
        pass

    # 6) 箍筋标注
    stir_text = "%%c%s" % stirrup
    t3 = msp.AddText(stir_text, P(cx + w/2 + 300, cy), DETAIL_TXT_H)
    t3.Layer = "S-DETAIL_TEXT"
    try:
        t3.StyleName = "Standard"
        t3.Height = DETAIL_TXT_H
    except Exception:
        pass


def add_center_label(msp, beam_info, beam, spans, bw, bh, stirrup, top, bottom):
    """添加梁平法集中标注（引线 + MText）。"""
    direction = beam_info["direction"]
    mx, my = beam_info["mid"]

    # 文字内容（三行）
    text = "%s(%d) %gx%g\\P%%c%s\\P%s; %s" % (
        beam, spans, bw, bh, stirrup, top, bottom)

    if direction == "Y":
        # Y 向梁：引线从梁左侧引出，文字在梁左侧
        lead_x = mx - 250.0          # 梁左侧边缘外（边线约在 mx-125）
        bend_x = mx - 900.0
        text_x = mx - 950.0
        # 引线
        msp.AddLine(P(lead_x, my), P(bend_x, my)).Layer = "S-BEAM_REBAR"
        msp.AddLine(P(bend_x, my), P(text_x + 50, my)).Layer = "S-BEAM_REBAR"
        # MText
        mt = msp.AddMText(P(text_x, my + 300), 2000.0, text)
        mt.Layer = "S-BEAM_REBAR"
        try:
            mt.StyleName = "Standard"
            mt.Height = TXT_H
            mt.AttachmentPoint = 5   # 5 = MiddleRight
            mt.InsertionPoint = P(text_x, my)
        except Exception:
            pass
    else:
        # X 向梁：引线从梁下侧引出，文字在梁下侧
        lead_y = my - 250.0
        bend_y = my - 900.0
        text_y = my - 950.0
        msp.AddLine(P(mx, lead_y), P(mx, bend_y)).Layer = "S-BEAM_REBAR"
        msp.AddLine(P(mx, bend_y), P(mx, text_y + 50)).Layer = "S-BEAM_REBAR"
        mt = msp.AddMText(P(mx - 1000, text_y), 2000.0, text)
        mt.Layer = "S-BEAM_REBAR"
        try:
            mt.StyleName = "Standard"
            mt.Height = TXT_H
            mt.AttachmentPoint = 4   # 4 = MiddleCenter
            mt.InsertionPoint = P(mx, text_y)
        except Exception:
            pass


def find_detail_position(x_spans, x_gap, y_spans, y_gap):
    """在平面图右下角找一块空白处放详图。"""
    max_x = x_spans * x_gap
    min_y = 0.0
    # 右下角，往右下偏移一定距离
    cx = max_x + 8000.0
    cy = min_y + 3000.0
    return cx, cy


def draw_rebar(app, *, beam, spans, section, stirrup, top, bottom,
               x_spans, x_gap, y_spans, y_gap, col_size,
               prefix="KL", clear_old=True):
    doc = app.ActiveDocument
    msp = doc.ModelSpace

    bw, bh = parse_section(section)
    stirrup = parse_stirrup(stirrup)

    # 1) 同步制图标准
    info = ensure_standards(doc)
    log("  标准同步：图层 %d 个，线型 %s，文字样式 %s"
        % (info["layers"], info["linetypes"], info["styles"]))
    for e in info["errors"][:8]:
        log("    [warn] %s" % e)

    # 2) 清掉上次的配筋标注/详图
    if clear_old:
        try:
            old = clear_layers(msp, REBAR_LAYERS)
            if old:
                log("  已清理旧配筋实体 %d 个" % old)
        except Exception as e:
            log("  [warn] 清理旧实体跳过: %s" % e)

    # 3) 定位梁
    beam_info = locate_beam(beam, x_spans, x_gap, y_spans, y_gap, col_size, prefix)
    log("  定位 %s: %s向 轴线=%g 中点=(%g, %g) %s" % (
        beam, beam_info["direction"], beam_info["axis"],
        beam_info["mid"][0], beam_info["mid"][1],
        "边跨" if beam_info["is_edge"] else "中跨"))

    # 4) 集中标注
    add_center_label(msp, beam_info, beam, spans, bw, bh, stirrup, top, bottom)
    log("  已添加集中标注")

    # 5) 详图
    dcx, dcy = find_detail_position(x_spans, x_gap, y_spans, y_gap)
    draw_detail(msp, dcx, dcy, bw, bh, stirrup, top, bottom)
    log("  已绘制详图 @(%g, %g) 放大 %.1f 倍" % (dcx, dcy, DETAIL_SCALE))

    zoom_extents(doc)
    log("COM_LIVE_DRAW=OK")


def main():
    ap = argparse.ArgumentParser(
        description="给已画好的梁添加平法集中标注并绘制剖面详图")
    # 梁信息
    ap.add_argument("--beam", required=True, help="梁名，如 KL5")
    ap.add_argument("--spans", type=int, required=True, help="跨数，如 3")
    ap.add_argument("--section", required=True, help="截面 bxh，如 200x400")
    ap.add_argument("--stirrup", required=True, help="箍筋，如 8@100/200(2)")
    ap.add_argument("--top", required=True, help="上部纵筋，如 2%%c18")
    ap.add_argument("--bottom", required=True, help="下部纵筋，如 2%%c20")
    # 轴网/柱（需与 cad_draw_axis/columns/beams 一致）
    ap.add_argument("--x-spans", type=int, default=6)
    ap.add_argument("--x-gap", type=float, default=4000)
    ap.add_argument("--y-spans", type=int, default=2)
    ap.add_argument("--y-gap", type=float, default=8000)
    ap.add_argument("--col-size", type=float, default=500)
    ap.add_argument("--prefix", default="KL")
    ap.add_argument("--keep", action="store_true", help="保留旧配筋，叠加绘制")
    args = ap.parse_args()

    try:
        log("连接 AutoCAD ...")
        app = connect()
        log("  已连接 -> %s %s" % (app.Application.Name, app.Version))
    except Exception as e:
        log("FAILED: 无法连接 AutoCAD: %s" % e)
        return

    try:
        draw_rebar(app,
                   beam=args.beam, spans=args.spans,
                   section=args.section, stirrup=args.stirrup,
                   top=args.top, bottom=args.bottom,
                   x_spans=args.x_spans, x_gap=args.x_gap,
                   y_spans=args.y_spans, y_gap=args.y_gap,
                   col_size=args.col_size, prefix=args.prefix,
                   clear_old=not args.keep)
    except Exception:
        log("FAILED: 绘制异常")
        log(traceback.format_exc())
    finally:
        try:
            with open(LOG_PATH, "w", encoding="utf-8") as f:
                f.write("\n".join(log_lines))
        except Exception:
            pass
    log("DONE")


if __name__ == "__main__":
    main()
