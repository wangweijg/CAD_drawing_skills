# -*- coding: utf-8 -*-
"""清空当前模型空间（用于重画整张图前）。

实时连接已打开的 AutoCAD，用原生 _ERASE _all 删除全部实体。
破坏性操作，默认 dry-run（只报告数量），必须显式 --yes 才真正清空。

用法：
  python cad_clear_all.py              # 只报告当前实体数，不删
  python cad_clear_all.py --yes        # 确认清空全部实体
"""
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cad_live as L


def main():
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--yes", action="store_true",
                    help="确认清空（不加则只报告数量不删）")
    a = ap.parse_args()

    acad = L.connect()
    doc = acad.ActiveDocument
    msp = doc.ModelSpace
    before = int(msp.Count)
    print("当前模型空间实体数: %d" % before)
    if before == 0:
        print("已为空，无需清空")
        return
    if not a.yes:
        print("[dry-run] 未清空。加 --yes 确认清空全部实体。")
        return

    # 原生命令清空全部；末尾 \n 收尾，避免 CAD 卡在命令提示符
    doc.SendCommand("_ERASE\n_all\n\n")
    time.sleep(2)
    try:
        doc.Regen(True)
    except Exception:
        pass
    after = int(msp.Count)
    L.zoom_extents(doc)
    print("已清空：%d -> %d" % (before, after))
    print("COM_LIVE_DRAW=OK")


if __name__ == "__main__":
    main()
