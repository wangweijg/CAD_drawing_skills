# -*- coding: utf-8 -*-
"""柱表式柱配筋详图实时绘制 —— 自动读取模板「柱子_详图_600x600」几何并逐点重放。

与旧版 cad_column_rebar.py（近似参数、外框 7700x10700、带实心填充）不同：
本脚本的几何全部来自 templates/<模板名>.template.json 的 geometry 段
（无 geometry 段时回退到内置默认值，保证任何环境可跑）。

模板实测几何（柱子_详图_600x600）：
    外框 7700x10000（上 800 标题行 + 6000 截面区 + 底部 3200 四行柱表）
    截面放大 10/3，保护层 30 -> 截面内缩 100
    纵筋 12 根外圈布置（每侧 4 根、角部重合；纵筋为实心圆点），
    距柱边 165.05，间距 556.63；左右侧面短段竖直（模板段样式）
    箍筋 3 道 12 点多段线（135° 弯钩在右下角），线宽 40
    内箍宽/高 671.07（含 57.215 校正项，与模板逐点一致）
    尺寸线距截面 666.7，DIM100 建筑斜线样式
    仅一条角部引出线 + 顶部/左侧两个边部文字（无引出线），无实心填充

用法示例（在已打开的 AutoCAD 中实时绘制）：
    python cad_column_detail.py --name KZ-1 --section 600x600 \
        --rebar "12%%13222" --stirrup "%%1328@100/200" \
        --level "基础顶~-3.470" --x 0 --y 0
    python cad_column_detail.py --info          # 只看解析到的模板与几何，不连 CAD
"""
import os
import re
import sys
import json
import math
import argparse
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# ---------------- 内置默认几何（模板 JSON 无 geometry 段时的回退）----------------
DEF = dict(
    frame_w=7700.0, frame_h=10000.0, scale=10.0 / 3.0, cover_mm=30.0,
    bar_offset=165.05, bar_dot_width_base=58.33, bar_dot_style="circle",
    bar_dot_scale=1.5,
    rebar_grid=[4, 4], bar_count=12, stirrup_width=40.0, hook=100.0,
    hook_diag=177.0,
    hook_diag2=277.0, dim_offset=666.7, inner_corr=57.215,
    section_center=[4400.0, 6200.0],
    text_h={"detail": 300.0, "table": 450.0, "title": 600.0},
    title={"text": "一层框架柱表", "x": 3850.0, "y": 9600.0},
    table={"label_x": 750.0, "value_x": 4600.0, "v_line_x": 1500.0,
           "h_lines": [800.0, 1600.0, 2400.0, 3200.0, 9200.0],
           "rows": [
               {"label": "截 面", "y": 6200.0, "field": None, "h": 450.0},
               {"label": "编 号", "y": 2800.0, "field": "name", "h": 450.0},
               {"label": "标 高", "y": 2000.0, "field": "level", "h": 300.0},
               {"label": "纵 筋", "y": 1200.0, "field": "rebar", "h": 300.0},
               {"label": "箍筋、拉筋", "y": 400.0, "field": "stirrup", "h": 300.0}]},
    leader={"line_dx": 900.0, "line_dy": 900.0, "text_dx": 1000.0,
            "text_dy": 900.0, "top_dy": 200.0, "left_dx": -350.0},
)

DETAIL_LAYERS = [
    "S-COLU_DE", "S-REIN", "S-TAB", "S-TAB_TEXT",
    "S-PUB_TEXT", "S-COLU_DE_TEXT", "S-DIM",
]


class Geom(object):
    """从模板 JSON geometry 段取参数，缺键回退到 DEF。"""

    def __init__(self, data):
        g = (data or {}).get("geometry") or {}
        self._g = g
        self.frame_w = float(g.get("frame_w", DEF["frame_w"]))
        self.frame_h = float(g.get("frame_h", DEF["frame_h"]))
        self.scale = float(g.get("scale", DEF["scale"]))
        self.cover_mm = float(g.get("cover_mm", DEF["cover_mm"]))
        self.bar_offset = float(g.get("bar_offset", DEF["bar_offset"]))
        self.bar_w_base = float(g.get("bar_dot_width_base", DEF["bar_dot_width_base"]))
        self.dot_style = str(g.get("bar_dot_style", DEF["bar_dot_style"]))
        self.bar_scale = float(g.get("bar_dot_scale", DEF["bar_dot_scale"]))
        grid = g.get("rebar_grid") or DEF["rebar_grid"]
        self.grid = (int(grid[0]), int(grid[1]))
        self.bar_count = int(g.get("bar_count", DEF["bar_count"]))
        self.stirrup_w = float(g.get("stirrup_width", DEF["stirrup_width"]))
        self.hook = float(g.get("hook", DEF["hook"]))
        self.hook_diag = float(g.get("hook_diag", DEF["hook_diag"]))
        self.hook_diag2 = float(g.get("hook_diag2", DEF["hook_diag2"]))
        self.dim_offset = float(g.get("dim_offset", DEF["dim_offset"]))
        self.inner_corr = float(g.get("inner_corr", DEF["inner_corr"]))
        sc = g.get("section_center") or DEF["section_center"]
        self.cx, self.cy = float(sc[0]), float(sc[1])
        th = g.get("text_h") or DEF["text_h"]
        self.h_detail = float(th.get("detail", DEF["text_h"]["detail"]))
        self.h_table = float(th.get("table", DEF["text_h"]["table"]))
        self.h_title = float(th.get("title", DEF["text_h"]["title"]))
        self.title = g.get("title") or DEF["title"]
        self.table = g.get("table") or DEF["table"]
        self.leader = g.get("leader") or DEF["leader"]

    def summary(self):
        return {
            "frame_w": self.frame_w, "frame_h": self.frame_h,
            "scale": self.scale, "cover_mm": self.cover_mm,
            "bar_offset": self.bar_offset, "bar_dot_style": self.dot_style,
            "bar_dot_scale": self.bar_scale,
            "rebar_grid": list(self.grid), "bar_count": self.bar_count,
            "stirrup_width": self.stirrup_w,
            "hook": self.hook, "hook_diag": self.hook_diag,
            "hook_diag2": self.hook_diag2, "dim_offset": self.dim_offset,
            "inner_corr": self.inner_corr, "section_center": [self.cx, self.cy],
        }


def candidate_dirs():
    dirs = []
    env = os.environ.get("CAD_TEMPLATE_LIB")
    if env:
        dirs.append(env)
    base = os.path.dirname(os.path.abspath(__file__))
    for rel in ("templates", os.path.join("..", "templates"),
                os.path.join("..", "..", "templates")):
        dirs.append(os.path.normpath(os.path.join(base, rel)))
    return [d for d in dirs if os.path.isdir(d)]


def find_template(section, template=None):
    """定位 .template.json：返回 (路径, data)。template 可为文件名/路径关键字。"""
    hits = []
    for d in candidate_dirs():
        for name in os.listdir(d):
            if not name.lower().endswith(".template.json"):
                continue
            p = os.path.join(d, name)
            try:
                with open(p, "r", encoding="utf-8-sig") as f:
                    data = json.load(f)
            except Exception:
                continue
            tname = data.get("template_name", name)
            ttype = data.get("template_type", "")
            if template:
                key = template.lower()
                if key in name.lower() or key in tname.lower():
                    hits.append((p, data))
                continue
            if "\u67f1" not in ttype and "\u67f1" not in tname:
                continue
            score = 0
            if section and section.lower().replace("x", "").replace("*", "") in \
                    tname.lower().replace("x", "").replace("*", ""):
                score += 10
            if "600" in tname:
                score += 5
            hits.append((p, data, score))
    if not hits:
        raise SystemExit("未找到可用模板（--template 指定或 section 匹配的柱详图）。"
                         "模板目录: %s" % candidate_dirs())
    if template:
        if len(hits) == 1:
            return hits[0]
        raise SystemExit("--template 匹配到多个：%s" % [h[0] for h in hits])
    hits.sort(key=lambda h: h[2], reverse=True)
    return hits[0][0], hits[0][1]


def normalize_phi(s):
    if not s:
        return s
    return re.sub(r"[Cc\u03c6\u03a6]|%%132|%%c", "%%132", str(s))


def parse_rebar(spec):
    spec = normalize_phi(spec)
    groups = []
    for part in spec.split("+"):
        part = part.strip()
        # "12%%13222" / "12Φ22" -> (12, 22)：数量在前、直径在后
        m = re.match(r"(\d+)\s*%%132\s*(\d+)", part)
        if m:
            groups.append((int(m.group(1)), int(m.group(2))))
    return groups


def grid_positions(cx, cy, hw, hh, off, nx, ny):
    """nx x ny 满铺网格（4x4=16 点），与模板逐点一致。"""
    pts = []
    for j in range(ny):
        t_y = 0.0 if ny == 1 else j / (ny - 1.0)
        y = cy - hh + off + t_y * (2 * hh - 2 * off)
        for i in range(nx):
            t_x = 0.0 if nx == 1 else i / (nx - 1.0)
            x = cx - hw + off + t_x * (2 * hw - 2 * off)
            pts.append((x, y))
    return pts


def edge_positions(cx, cy, hw, hh, off, total):
    """4 角 + 四边均匀分布：total=12 即每侧 4 根、角部重合（模板 12Φ22 布局）。"""
    positions = [
        (cx - hw + off, cy - hh + off),
        (cx + hw - off, cy - hh + off),
        (cx + hw - off, cy + hh - off),
        (cx - hw + off, cy + hh - off),
    ]
    remain = total - 4
    if remain > 0:
        n_per = max(1, remain // 4)
        for i in range(n_per):
            t = (i + 1.0) / (n_per + 1.0)
            positions.append((cx - hw + off + t * (2 * hw - 2 * off),
                              cy - hh + off))
            positions.append((cx - hw + off + t * (2 * hw - 2 * off),
                              cy + hh - off))
            positions.append((cx - hw + off,
                              cy - hh + off + t * (2 * hh - 2 * off)))
            positions.append((cx + hw - off,
                              cy - hh + off + t * (2 * hh - 2 * off)))
    return positions[:total]


def add_text(msp, txt, x, y, h, layer, align="center", rotation=0.0,
             style="TSSD_Rein", dx=0.0, dy=0.0):
    from cad_live import P
    t = msp.AddText(str(txt), P(x + dx, y + dy), float(h))
    t.Layer = layer
    try:
        t.StyleName = style
    except Exception:
        pass
    if align == "center":
        try:
            t.Alignment = 4          # acAlignmentMiddleCenter
            t.TextAlignmentPoint = P(x + dx, y + dy)
        except Exception:
            pass
    if rotation:
        try:
            t.Rotation = math.radians(float(rotation))  # ActiveX 用弧度
        except Exception:
            pass
    return t


def add_line(msp, x1, y1, x2, y2, layer, dx=0.0, dy=0.0):
    from cad_live import P
    ln = msp.AddLine(P(x1 + dx, y1 + dy), P(x2 + dx, y2 + dy))
    ln.Layer = layer
    return ln


def add_lwpoly(msp, pts, layer, closed=False, const_width=None, bulge=None,
               dx=0.0, dy=0.0):
    from cad_live import Pn
    if bulge:
        flat = []
        for i, (x, y) in enumerate(pts):
            flat += [x + dx, y + dy, bulge[i]]
        pl = msp.AddPolyline(Pn(flat))
    else:
        flat = []
        for x, y in pts:
            flat += [x + dx, y + dy]
        pl = msp.AddLightWeightPolyline(Pn(flat))
    pl.Layer = layer
    if closed:
        try:
            pl.Closed = True
        except Exception:
            pass
    if const_width is not None:
        try:
            pl.ConstantWidth = const_width
        except Exception:
            pass
    return pl


def stirrup_pts(x0, y0, x1, y1, g):
    """12 点箍筋多段线（135° 弯钩在右下角），与模板逐点一致。"""
    return [
        (x1 - g.hook_diag2, y0 + g.hook_diag),
        (x1 - g.hook, y0),
        (x1, y0),
        (x1, y0 + g.hook),
        (x1, y0),
        (x1, y1),
        (x0, y1),
        (x0, y0),
        (x1 - g.hook, y0),
        (x1, y0),
        (x1, y0 + g.hook),
        (x1 - g.hook_diag, y0 + g.hook_diag2),
    ]


def bar_dot(msp, cx, cy, dia, layer, g, dx=0.0, dy=0.0, orientation="h"):
    """纵筋点：默认实心圆点（两段弧+线宽）；模板显式 segment 时回退 2 点宽段。
    orientation: 仅 segment 样式使用："h" 水平 / "v" 竖直。"""
    w = g.bar_w_base * dia / 20.0
    r = w / 2.0
    x, y = cx + dx, cy + dy
    if g.dot_style == "segment":
        if orientation == "v":
            pts = [x, y - r, x, y + r]
        else:
            pts = [x - r, y, x + r, y]
        pl = msp.AddLightWeightPolyline(Pn_safe(pts))
        try:
            pl.ConstantWidth = w
        except Exception:
            pass
    else:
        # 实心圆点：2 段 180° 弧闭合 + 恒定线宽 -> 半径为 R 的实心圆
        # R = 基础半径 r * 放大倍数（默认 1.5）
        R = r * g.bar_scale
        d = R / 2.0
        pl = msp.AddLightWeightPolyline(Pn_safe([x - d, y, x + d, y]))
        try:
            pl.ConstantWidth = R
        except Exception:
            pass
        try:
            pl.SetBulge(0, 1.0)
            pl.SetBulge(1, 1.0)
        except Exception:
            pass
        try:
            pl.Closed = True
        except Exception:
            pass
    pl.Layer = layer
    return pl


def Pn_safe(coords):
    from cad_live import Pn
    return Pn(coords)


def add_dim(msp, p1x, p1y, p2x, p2y, locx, locy, value, dx=0.0, dy=0.0):
    from cad_live import P
    from cad_standards import DIMSTYLE_NAME
    d = msp.AddDimAligned(P(p1x + dx, p1y + dy), P(p2x + dx, p2y + dy),
                          P(locx + dx, locy + dy))
    d.Layer = "S-DIM"
    try:
        d.StyleName = DIMSTYLE_NAME
    except Exception:
        pass
    try:
        d.TextOverride = str(value)
    except Exception:
        pass
    return d


def draw_column_detail(msp, args, g, dx=0.0, dy=0.0):
    b, h = (int(v) for v in re.match(r"(\d+)\s*[xX*]\s*(\d+)",
                                     args.section).groups())
    hw = b * g.scale / 2.0
    hh = h * g.scale / 2.0
    cov = g.cover_mm * g.scale
    cx, cy = g.cx, g.cy

    # 1) 外框 + 表格线
    add_lwpoly(msp, [(0, 0), (g.frame_w, 0), (g.frame_w, g.frame_h),
                     (0, g.frame_h)], "S-TAB", closed=True, dx=dx, dy=dy)
    for yy in g.table["h_lines"]:
        add_line(msp, 0, yy, g.frame_w, yy, "S-TAB", dx, dy)
    add_line(msp, g.table["v_line_x"], 0, g.table["v_line_x"],
             g.table["h_lines"][-1], "S-TAB", dx, dy)

    # 2) 表格文字
    add_text(msp, g.title["text"], g.title["x"], g.title["y"], g.h_title,
             "S-TAB_TEXT", dx=dx, dy=dy)
    value_map = {"name": args.name, "level": args.level,
                 "rebar": normalize_phi(args.rebar),
                 "stirrup": normalize_phi(args.stirrup)}
    for row in g.table["rows"]:
        add_text(msp, row["label"], g.table["label_x"], row["y"],
                 row.get("h", g.h_table), "S-TAB_TEXT", dx=dx, dy=dy)
        if row.get("field"):
            add_text(msp, value_map[row["field"]], g.table["value_x"],
                     row["y"], row.get("h", g.h_table),
                     "S-PUB_TEXT" if row["field"] in ("level", "rebar",
                                                      "stirrup")
                     else "S-TAB_TEXT", dx=dx, dy=dy)

    # 3) 截面轮廓
    add_lwpoly(msp, [(cx - hw, cy - hh), (cx + hw, cy - hh),
                     (cx + hw, cy + hh), (cx - hw, cy + hh)],
               "S-COLU_DE", closed=True, dx=dx, dy=dy)

    # 4) 复合箍筋（外箍 + 内箍竖 + 内箍横），几何与模板逐点一致
    sw, sh = 2 * hw - 2 * cov, 2 * hh - 2 * cov
    bar_sp_x = (2 * hw - 2 * g.bar_offset) / (g.grid[0] - 1.0)
    bar_sp_y = (2 * hh - 2 * g.bar_offset) / (g.grid[1] - 1.0)
    iw = 2 * (hw - (g.bar_offset + bar_sp_x - g.inner_corr))
    ih = 2 * (hh - (g.bar_offset + bar_sp_y - g.inner_corr))
    add_lwpoly(msp, stirrup_pts(cx - sw / 2, cy - sh / 2,
                                cx + sw / 2, cy + sh / 2, g),
               "S-REIN", const_width=g.stirrup_w, dx=dx, dy=dy)
    add_lwpoly(msp, stirrup_pts(cx - iw / 2, cy - sh / 2,
                                cx + iw / 2, cy + sh / 2, g),
               "S-REIN", const_width=g.stirrup_w, dx=dx, dy=dy)
    add_lwpoly(msp, stirrup_pts(cx - sw / 2, cy - ih / 2,
                                cx + sw / 2, cy + ih / 2, g),
               "S-REIN", const_width=g.stirrup_w, dx=dx, dy=dy)

    # 5) 纵筋点（默认 12 根外圈：每侧 4 根、角部重合；--bars 可覆盖总数）
    groups = parse_rebar(args.rebar)
    if not groups:
        raise ValueError("无法解析纵筋: %s" % args.rebar)
    dia0 = groups[0][1]
    total = args.bars if args.bars else g.bar_count
    positions = edge_positions(cx, cy, hw, hh, g.bar_offset, total)
    eps = 1e-6
    x_left = cx - hw + g.bar_offset
    x_right = cx + hw - g.bar_offset
    y_bot = cy - hh + g.bar_offset
    y_top = cy + hh - g.bar_offset
    for px, py in positions:
        # 左右侧面主筋画竖直短段；角部与上下边保持水平短段（与模板一致）
        is_corner = (abs(py - y_bot) < eps or abs(py - y_top) < eps)
        on_side = (abs(px - x_left) < eps or abs(px - x_right) < eps)
        orientation = "v" if (on_side and not is_corner) else "h"
        bar_dot(msp, px, py, dia0, "S-REIN", g, dx, dy, orientation)

    # 6) 尺寸标注（DIM100，尺寸线距截面 666.7）
    add_dim(msp, cx - hw, cy - hh, cx + hw, cy - hh,
            cx - hw, cy - hh - g.dim_offset, b, dx, dy)
    add_dim(msp, cx + hw, cy - hh, cx + hw, cy + hh,
            cx + hw + g.dim_offset, cy - hh, h, dx, dy)

    # 7) 角部引出线 + 边部文字（对齐模板：只有一条引出线）
    ld = g.leader
    add_line(msp, cx + hw, cy + hh, cx + hw + ld["line_dx"],
             cy + hh + ld["line_dy"], "S-COLU_DE_TEXT", dx, dy)
    add_text(msp, f"角部4%%132{dia0}", cx + hw + ld["text_dx"],
             cy + hh + ld["text_dy"], g.h_detail, "S-COLU_DE_TEXT",
             align="left", dx=dx, dy=dy)
    top_dia = groups[1][1] if len(groups) > 1 else groups[0][1]
    left_dia = groups[1][1] if len(groups) > 1 else groups[0][1]
    add_text(msp, f"2%%132{top_dia}", cx, cy + hh + ld["top_dy"],
             g.h_detail, "S-COLU_DE_TEXT", dx=dx, dy=dy)
    add_text(msp, f"2%%132{left_dia}", cx - hw + ld["left_dx"], cy,
             g.h_detail, "S-COLU_DE_TEXT", rotation=90.0, dx=dx, dy=dy)



def clear_detail_region(msp, layers, x0, y0, x1, y1):
    """只删除落在详图外框矩形内的指定图层旧实体。

    旧版 clear_layers() 会按图层清空整个模型空间，共享图层 S-DIM
    （平面图尺寸标注同层）会被误删。改为按外框区域过滤，平面图
    标注在框外则不受影响。
    """
    try:
        total = int(msp.Count)
    except Exception:
        return 0
    n = 0
    for i in range(total - 1, -1, -1):
        try:
            e = msp.Item(i)
            if str(e.Layer) not in layers:
                continue
            try:
                mn, mx = e.GetBoundingBox()
                ex0, ey0 = float(mn[0]), float(mn[1])
                ex1, ey1 = float(mx[0]), float(mx[1])
            except Exception:
                try:
                    sp = e.StartPoint
                    ex0 = ex1 = float(sp[0])
                    ey0 = ey1 = float(sp[1])
                except Exception:
                    continue
            if ex1 < x0 or ex0 > x1 or ey1 < y0 or ey0 > y1:
                continue
            e.Delete()
            n += 1
        except Exception:
            continue
    return n




def screenshot_cad(acad, path):
    """抓取 AutoCAD 主窗口截图到 PNG（快速人工核验用，可跳过）。"""
    try:
        import ctypes
        import ctypes.wintypes as wt
        from PIL import ImageGrab
    except Exception as e:
        print("[shot] 跳过: %s" % e)
        return False
    user32 = ctypes.windll.user32
    try:
        hwnd = int(acad.HWND)
    except Exception:
        print("[shot] 未找到 CAD 窗口")
        return False
    try:
        user32.ShowWindow(hwnd, 9)          # SW_RESTORE
        user32.SetForegroundWindow(hwnd)
        time.sleep(0.4)
        r = wt.RECT()
        user32.GetWindowRect(hwnd, ctypes.byref(r))
        if r.right <= r.left or r.bottom <= r.top:
            print("[shot] 窗口矩形无效")
            return False
        ImageGrab.grab(bbox=(r.left, r.top, r.right, r.bottom)).save(path)
        print("[shot] -> %s" % path)
        return True
    except Exception as e:
        print("[shot] 跳过: %s" % e)
        return False


def main():
    _t0 = time.time()
    ap = argparse.ArgumentParser(description="柱表式柱配筋详图（严格按模板逐点重放）")
    ap.add_argument("--name", help="柱编号，如 KZ-1")
    ap.add_argument("--section", default="600x600", help="截面，如 600x600")
    ap.add_argument("--rebar", default="12%%13222",
                    help="纵筋，如 '12%%13222' 或 '8%%13225+4%%13220'")
    ap.add_argument("--stirrup", default="%%1328@100/200",
                    help="箍筋，如 '%%1328@100/200'")
    ap.add_argument("--level", default="基础顶~-3.470", help="标高")
    ap.add_argument("--template", default=None,
                    help="模板名/路径关键字（默认自动匹配 600 柱详图）")
    ap.add_argument("--bars", type=int, default=0,
                    help="纵筋点数（默认 12 根外圈：每侧 4 根、角部重合）")
    ap.add_argument("--x", type=float, default=0.0, help="整体偏移 X")
    ap.add_argument("--y", type=float, default=0.0, help="整体偏移 Y")
    ap.add_argument("--zoom", action="store_true",
                    help="画完后缩放到图形范围")
    ap.add_argument("--shot", default=None,
                    help="画完后抓取 CAD 窗口截图保存到该 PNG 路径")
    ap.add_argument("--info", action="store_true",
                    help="只打印解析到的模板与几何，不连接 CAD")
    args = ap.parse_args()

    tpath, tdata = find_template(args.section, args.template)
    g = Geom(tdata)
    layers = [l["name"] for l in tdata.get("layers", [])
              if l.get("name") not in ("0", "Defpoints")] or DETAIL_LAYERS
    print("模板: %s" % tpath)
    print("几何: %s" % json.dumps(g.summary(), ensure_ascii=False))
    print("图层: %s" % ", ".join(layers))
    if args.info:
        return

    from cad_live import connect, ensure_standards, wait_quiescent, zoom_extents
    acad = connect()
    doc = acad.ActiveDocument
    msp = doc.ModelSpace
    print("已连接 -> %s" % acad.Caption)

    ensure_standards(doc, layers=layers, verbose=True)
    x0, y0 = args.x, args.y
    x1, y1 = x0 + g.frame_w, y0 + g.frame_h
    n = clear_detail_region(msp, layers, x0, y0, x1, y1)
    print("已清理详图区域内旧实体 %d 个" % n)

    draw_column_detail(msp, args, g, dx=args.x, dy=args.y)
    total = args.bars if args.bars else g.bar_count
    print("柱表详图 %s 已按模板「%s」重放 @(%g, %g)，纵筋 %d 根外圈"
          "（每侧 %d 根、角部重合）"
          % (args.name, tdata.get("template_name", ""), args.x, args.y,
             total, total // 4 + 1))
    print("COM_LIVE_DRAW=OK")
    wait_quiescent(acad)
    if args.zoom:
        zoom_extents(doc)
    if args.shot:
        screenshot_cad(acad, args.shot)
    print("ELAPSED_SEC=%.1f" % (time.time() - _t0))


if __name__ == "__main__":
    main()
