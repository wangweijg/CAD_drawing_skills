# -*- coding: utf-8 -*-
"""柱配筋详图（柱表截面详图）实时绘制脚本。

功能：给定一根柱的配筋信息，在已打开的 AutoCAD 中绘制「柱表样式」柱配筋
详图（参照王工 2026-08-06 模板 zhuzi.dxf）：

  - 外框 7700×10700（截面区 7500 + 4×800 表格）
  - 柱截面放大 10/3≈3.33 倍居中于截面区
  - 复合箍筋（1 外箍 + 2 内箍），12 点多段线含 135° 弯钩
  - 纵筋点用 3 点多段线 bulge=1 模拟实心圆（const_width=58.3）
  - 角部/边部引出线标注（角筋4Φ25 / 2Φ25 / 2Φ20）
  - 底部 4 行表（KZ-3 / 标高 / 纵筋 / 箍筋）
  - 直径符号用 %%132（HRB400 钢筋符号，TSSD 字体）

图层对齐模板 zhuzi.dxf：
  S-COLU_DE / S-REIN / S-TAB / S-TAB_TEXT / S-PUB_TEXT / S-COLU_DE_TEXT / S-DIM

用法示例：
    python cad_column_rebar.py --name KZ-3 --section 500x500 \\
        --rebar "8%%13225+4%%13220" --stirrup "%%1328@100/200" \\
        --level "基础顶~3.470" --frame --x 30000 --y 0
"""
import os
import re
import sys
import math
import argparse

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cad_live import connect, P, Pn, ensure_standards, clear_layers, STD

# 柱详图专用图层（对齐模板 zhuzi.dxf 7 层）
DETAIL_LAYERS = [
    "S-COLU_DE",         # 柱截面轮廓
    "S-REIN",            # 纵筋点 + 箍筋（红色）
    "S-TAB",             # 表格外框 + 分隔线
    "S-TAB_TEXT",        # 柱号（KZ-3，h=450）
    "S-PUB_TEXT",        # 表内文字（标高/纵筋/箍筋，h=300）
    "S-COLU_DE_TEXT",    # 引出线 + 引出文字
    "S-DIM",             # 尺寸标注
]
# ⚠️ 绝不可把 S-COLU_NUM（平面柱编号）放进清理列表

TXT_H = 300.0              # 详图/引出线文字字高（对齐模板）
TAB_NAME_H = 450.0         # 柱号文字字高（KZ-3，对齐模板 S-TAB_TEXT）
TAB_TXT_H = 300.0          # 表内文字字高（对齐模板 S-PUB_TEXT）
LABEL_GAP = 600.0          # 文字栏距详图右侧间距（仅 --no-frame 时生效）
DIM_OFFSET_MM = 250.0      # 尺寸线距柱边（mm，详图已放大 scale 倍）
TEXT_LINE = 350.0          # 详图文字栏行间距
BAR_DOT_W = 58.33          # 纵筋点多段线宽度（对齐模板，半径≈29）
STIRRUP_W = 40.0           # 箍筋多段线宽度（对齐模板）
BAR_INSET = 65.0           # 纵筋点中心到箍筋中心线的间距（对齐模板）
HOOK_EXT = 100.0           # 箍筋弯钩延伸量（超出角部，对齐模板）
HOOK_DIAG = 177.0          # 箍筋弯钩对角线长度（≈HOOK_EXT*√2）

# 柱表样式默认（参照模板 zhuzi.dxf：外框 7700×10700）
DEFAULT_FRAME_W = 7700.0
DEFAULT_FRAME_H = 10700.0          # 外框总高（含底部表格）
DEFAULT_SECTION_H = 7500.0         # 截面区高（上半部）
DEFAULT_ROW_H = 800.0
DEFAULT_SCALE = 10.0 / 3.0         # 截面放大比例（对齐模板 500→1667）


def normalize_phi(s):
    """把用户输入里的 φ/Φ/%%c/C/c 统一替换为 CAD 控制码 %%132。

    %%132 = HRB400 钢筋符号（TSSD 字体），对齐模板 zhuzi.dxf 用法。
    一次性 re.sub：避免双重转义 bug。
    """
    import re as _re
    if not s:
        return s
    return _re.sub(r"[CcφΦ]|%%132|%%c", "%%132", str(s))


def parse_section(section):
    """'500x500' -> (500, 500)；'500*600' 也兼容。"""
    m = re.match(r"(\d+)\s*[xX*]\s*(\d+)", section.strip())
    if not m:
        raise ValueError("截面格式应为 500x500: %s" % section)
    return int(m.group(1)), int(m.group(2))


def parse_rebar(spec):
    """解析纵筋规格：'12%%13220' / '4%%13220+4%%13218' -> [(count,dia), ...]。

    平法注写约定：第一段通常包含角部（如 '8%%13225+4%%13220' = B 边 8Φ25 +
    H 边 4Φ20），但本函数不区分边别，统一返回 (count, dia) 列表。
    """
    spec = normalize_phi(spec)
    groups = []
    for part in spec.split("+"):
        part = part.strip().replace("%%132", "")
        m = re.match(r"(\d+)\s*(\d+)", part)
        if m:
            groups.append((int(m.group(1)), int(m.group(2))))
    return groups


def add_text(msp, txt, x, y, h, layer, align="left", rotation=0.0,
             style="TSSD_Rein"):
    """添加单行文字，支持 left/center/right 对齐。

    默认用 TSSD_Rein 字体（支持 %%132 钢筋符号）。
    """
    txt = str(txt)
    align_map = {"left": 0, "center": 4, "right": 2}
    t = msp.AddText(txt, P(x, y), float(h))
    t.Layer = layer
    al = align_map.get(align, 0)
    try:
        t.Alignment = al
        t.TextAlignmentPoint = P(x, y)
    except Exception:
        pass
    try:
        t.StyleName = style
    except Exception:
        pass
    if rotation:
        try:
            t.Rotation = float(rotation)
        except Exception:
            pass
    return t


def add_rect_poly(msp, cx, cy, w, h, layer, closed=True):
    """添加矩形轻量多段线。"""
    a, b = w / 2.0, h / 2.0
    pts = [cx - a, cy - b, cx + a, cy - b, cx + a, cy + b, cx - a, cy + b]
    pl = msp.AddLightWeightPolyline(Pn(pts))
    if closed:
        try:
            pl.Closed = True
        except Exception:
            pass
    pl.Layer = layer
    return pl


def add_line(msp, x1, y1, x2, y2, layer):
    """添加直线段。"""
    line = msp.AddLine(P(x1, y1), P(x2, y2))
    line.Layer = layer
    return line


def add_stirrup_polyline(msp, cx, cy, w, h, layer, const_width=STIRRUP_W):
    """画带 135° 弯钩的箍筋（12 点开放多段线，对齐模板 zhuzi.dxf）。

    几何：外框矩形 + 右下角 135° 弯钩。
    弯钩 = 对角线向内 → 角部 → 向外延伸 HOOK_EXT → 向上 HOOK_EXT →
    返回角部 → 沿矩形逆时针走一圈 → 返回角部 → 弯钩 → 对角线向内。
    """
    a, b = w / 2.0, h / 2.0
    # 右下角
    br_x, br_y = cx + a, cy - b
    pts = [
        br_x - HOOK_DIAG, br_y + HOOK_DIAG,    # 0: 弯钩起点（对角线向内）
        br_x, br_y,                              # 1: 角部
        br_x + HOOK_EXT, br_y,                   # 2: 向外延伸
        br_x + HOOK_EXT, br_y + HOOK_EXT,        # 3: 向上
        br_x, br_y,                              # 4: 返回角部
        br_x, cy + b,                            # 5: 右上角
        cx - a, cy + b,                          # 6: 左上角
        cx - a, br_y,                            # 7: 左下角
        br_x, br_y,                              # 8: 返回右下角
        br_x + HOOK_EXT, br_y,                   # 9: 向外延伸
        br_x + HOOK_EXT, br_y + HOOK_EXT,        # 10: 向上
        br_x - HOOK_DIAG, br_y + HOOK_DIAG,      # 11: 弯钩终点（对角线向内）
    ]
    pl = msp.AddLightWeightPolyline(Pn(pts))
    pl.Layer = layer
    try:
        pl.ConstantWidth = const_width
    except Exception:
        pass
    return pl


def add_bar_dot(msp, px, py, layer, dot_w=BAR_DOT_W):
    """纵筋实心圆点（3 点开放多段线 bulge=1，对齐模板 zhuzi.dxf）。

    几何：A → B → A（B 在 A 左侧 dot_w 处），两段 bulge=1 形成完整圆。
    const_width = dot_w → 圆直径 = dot_w，半径 ≈ 29。
    """
    r = dot_w / 2.0
    pl = msp.AddLightWeightPolyline(Pn([px + r, py, px - r, py, px + r, py]))
    pl.Layer = layer
    try:
        pl.ConstantWidth = dot_w
    except Exception:
        pass
    try:
        pl.SetBulge(0, 1.0)
        pl.SetBulge(1, 1.0)
    except Exception:
        pass
    # 钢筋点设黑色(0)，与红色截面填充形成对比（对齐王工 2026-08-06 参考图）
    try:
        pl.Color = 0
    except Exception:
        pass
    return pl


def add_solid_fill(msp, left, bottom, right, top, layer):
    """截面实心填充（SOLID 矩形，红色，画在箍筋/钢筋点之下）。"""
    solid = msp.AddSolid(P(left, bottom), P(right, bottom),
                         P(left, top), P(right, top))
    solid.Layer = layer
    return solid


def add_longitudinal_bars(msp, cx, cy, bw, bh, cov, total, dia, layer,
                          diameter_list=None):
    """布置纵筋点：4 角 + 沿四边均匀分布剩余根数。

    平法总根数分配：4 角 + (总-4) 沿 B 边（顶/底）+ H 边（左/右）均匀分布。
    diameter_list: 按位置顺序的直径列表（4 角 → 顶中 → 底中 → 左中 → 右中）。
    """
    bar_in = cov + BAR_INSET
    positions = [
        (cx - bw / 2.0 + bar_in, cy - bh / 2.0 + bar_in),
        (cx + bw / 2.0 - bar_in, cy - bh / 2.0 + bar_in),
        (cx + bw / 2.0 - bar_in, cy + bh / 2.0 - bar_in),
        (cx - bw / 2.0 + bar_in, cy + bh / 2.0 - bar_in),
    ]
    remain = total - 4
    if remain > 0:
        n_per = max(1, remain // 4)
        for i in range(n_per):
            t = (i + 1.0) / (n_per + 1.0)
            positions.append((cx - bw / 2.0 + bar_in + t * (bw - 2 * bar_in),
                              cy - bh / 2.0 + bar_in))
            positions.append((cx - bw / 2.0 + bar_in + t * (bw - 2 * bar_in),
                              cy + bh / 2.0 - bar_in))
            positions.append((cx - bw / 2.0 + bar_in,
                              cy - bh / 2.0 + bar_in + t * (bh - 2 * bar_in)))
            positions.append((cx + bw / 2.0 - bar_in,
                              cy - bh / 2.0 + bar_in + t * (bh - 2 * bar_in)))
    if diameter_list is None:
        diameter_list = [dia] * total
    for i, (px, py) in enumerate(positions[:total]):
        add_bar_dot(msp, px, py, layer)
    return positions[:total]


def build_diameter_list(groups):
    """按 22G101 平法约定把纵筋组分配到位置顺序的直径列表。

    groups: [(count, dia), ...]
      groups[0] = B 边（含 4 角）
      groups[1] = H 边
    返回: 与位置 [4 角, 顶中, 底中, 左中, 右中, ...] 对应的直径列表。
    """
    if not groups:
        return []
    if len(groups) == 1:
        return [groups[0][1]] * groups[0][0]
    b_count, b_dia = groups[0]
    h_count, h_dia = groups[1]
    b_mid = max(0, (b_count - 4) // 2)
    h_mid = max(0, h_count // 2)
    n_per = max(b_mid, h_mid, 1)
    dlist = [b_dia] * 4
    for i in range(n_per):
        dlist.append(b_dia if i < b_mid else b_dia)
        dlist.append(b_dia if i < b_mid else b_dia)
        dlist.append(h_dia if i < h_mid else h_dia)
        dlist.append(h_dia if i < h_mid else h_dia)
    total = sum(c for c, _ in groups)
    return dlist[:total]


def add_dim_aligned(msp, x1, y1, x2, y2, value, layer, off, vertical=False):
    """对齐标注：参照轴网/梁的标注方式（AddDimAligned + DIM100 建筑斜线样式）。"""
    if not vertical:
        p1, p2 = P(x1, y1), P(x2, y2)
        tpos = P(x1, y1 - off)
    else:
        p1, p2 = P(x1, y1), P(x2, y2)
        tpos = P(x1 + off, y1)
    d = msp.AddDimAligned(p1, p2, tpos)
    d.Layer = layer
    try:
        d.StyleName = STD.DIMSTYLE_NAME
    except Exception:
        pass
    try:
        d.TextOverride = str(int(round(value)))
    except Exception:
        pass
    return d


def draw_frame(msp, cx, cy, fw, fh, row_h, n_rows=4):
    """画柱表外框 + 底部 n_rows 行表格分隔线。

    返回 (frame_bbox, table_top_y)。
    外框和分隔线都在 S-TAB 层（对齐模板）。
    """
    a, b = fw / 2.0, fh / 2.0
    # 外框（4 条直线）
    for (x1, y1, x2, y2) in [
        (cx - a, cy - b, cx + a, cy - b),
        (cx + a, cy - b, cx + a, cy + b),
        (cx + a, cy + b, cx - a, cy + b),
        (cx - a, cy + b, cx - a, cy - b),
    ]:
        add_line(msp, x1, y1, x2, y2, "S-TAB")
    # 底部表行分隔线
    table_top_y = cy - b + n_rows * row_h
    for i in range(1, n_rows):
        y = cy - b + i * row_h
        add_line(msp, cx - a, y, cx + a, y, "S-TAB")
    return (cx - a, cy - b, cx + a, cy + b), table_top_y


def draw_table_text(msp, cx, y_max, fw, row_h, rows):
    """在底部柱表里写 n 行居中文字。

    第 1 行（柱号 KZ-3）→ S-TAB_TEXT 层 h=450
    其余行（标高/纵筋/箍筋）→ S-PUB_TEXT 层 h=300
    """
    for i, txt in enumerate(rows):
        cy_row = y_max - (i + 0.5) * row_h
        if i == 0:
            add_text(msp, txt, cx, cy_row, TAB_NAME_H, "S-TAB_TEXT",
                     align="center")
        else:
            add_text(msp, txt, cx, cy_row, TAB_TXT_H, "S-PUB_TEXT",
                     align="center")


def draw_leader(msp, x1, y1, x2, y2, text, text_h=TXT_H,
                text_offset_x=400, text_offset_y=0):
    """画一条引出线 + 末端文字（绿色，对齐王工 2026-08-06 参考图）。

    引出线和文字都在 S-COLU_DE_TEXT 层，颜色覆盖为绿色(3)。
    """
    l1 = add_line(msp, x1, y1, x2, y2, "S-COLU_DE_TEXT")
    l2 = add_line(msp, x2, y2, x2 + text_offset_x, y2, "S-COLU_DE_TEXT")
    t = add_text(msp, text, x2 + text_offset_x + 100, y2 + text_offset_y,
                 text_h, "S-COLU_DE_TEXT", align="left")
    # 绿色覆盖（对齐参考图引出线绿色）
    for ent in (l1, l2, t):
        try:
            ent.Color = 3
        except Exception:
            pass


def draw_column_detail(msp, args):
    """按参数在 (args.x, args.y) 处绘制一个柱表样式柱配筋详图。"""
    b, h = parse_section(args.section)
    scale = args.scale
    BW, BH = b * scale, h * scale
    cov = args.cover * scale

    # ============ 决定柱中心 & 外框 ============
    use_frame = bool(getattr(args, "frame", False))
    if use_frame:
        fw = args.frame_w
        fh = args.frame_h
        row_h = args.row_h
        n_rows = args.n_rows
        table_h = n_rows * row_h
        section_h = fh - table_h
        if args.anchor == "frame":
            fcx, fcy = args.x, args.y
            cx = fcx
            cy = fcy + table_h / 2.0
        else:
            cx, cy = args.x, args.y
            fcx = cx
            fcy = cy - table_h / 2.0
    else:
        cx, cy = args.x, args.y

    # ============ 1) 外框 + 表格分隔 ============
    if use_frame:
        bbox, table_top_y = draw_frame(msp, fcx, fcy, fw, fh, row_h, n_rows)
    else:
        bbox, table_top_y = None, None

    # ============ 2) 截面轮廓（S-COLU_DE 层）============
    add_rect_poly(msp, cx, cy, BW, BH, "S-COLU_DE", closed=True)

    # ============ 2.5) 截面实心填充（S-REIN 层，红色，画在箍筋/钢筋点之下）============
    left_f, right_f = cx - BW / 2.0, cx + BW / 2.0
    bottom_f, top_f = cy - BH / 2.0, cy + BH / 2.0
    add_solid_fill(msp, left_f, bottom_f, right_f, top_f, "S-REIN")

    # ============ 3) 复合箍筋（S-REIN 层，3 组）============
    # 外箍
    sw, sh = BW - 2 * cov, BH - 2 * cov
    add_stirrup_polyline(msp, cx, cy, sw, sh, "S-REIN")
    # 内箍 1（竖向，窄）：宽度=sw/3，高度=sh
    inner_w = sw / 3.0
    add_stirrup_polyline(msp, cx, cy, inner_w, sh, "S-REIN")
    # 内箍 2（横向，矮）：宽度=sw，高度=sh/3
    inner_h = sh / 3.0
    add_stirrup_polyline(msp, cx, cy, sw, inner_h, "S-REIN")

    # ============ 4) 纵筋点（S-REIN 层，3 点多段线）============
    groups = parse_rebar(args.rebar)
    if not groups:
        raise ValueError("无法解析纵筋: %s" % args.rebar)
    total = sum(c for c, _ in groups)
    dia = groups[0][1]
    diameter_list = build_diameter_list(groups)
    add_longitudinal_bars(msp, cx, cy, BW, BH, cov, total, dia,
                          "S-REIN", diameter_list=diameter_list)

    # ============ 5) 柱尺寸标注（S-DIM 层）============
    left, right = cx - BW / 2.0, cx + BW / 2.0
    bottom, top = cy - BH / 2.0, cy + BH / 2.0
    off = DIM_OFFSET_MM * scale
    add_dim_aligned(msp, left, bottom, right, bottom, b,
                    layer="S-DIM", off=off, vertical=False)
    add_dim_aligned(msp, right, bottom, right, top, h,
                    layer="S-DIM", off=off, vertical=True)

    # ============ 6) 角部/边部引出线（S-COLU_DE_TEXT 层）============
    if use_frame and getattr(args, "leader", True) and total >= 4:
        # ⚠️ 用 f-string 保留 CAD 控制码 %%132
        if groups[0][1] == dia:
            draw_leader(msp, right, top,
                        right + off * 0.6, top + off * 0.6,
                        f"角部4%%132{dia}")
        if total >= 6:
            n_per = (total - 4) // 4 if total > 4 else 0
            if n_per > 0:
                draw_leader(msp, cx, top, cx, top + off * 0.6,
                            f"2%%132{groups[0][1]}")
        if total >= 8 and len(groups) > 1:
            draw_leader(msp, left, cy, left - off * 0.6, cy,
                        f"2%%132{groups[1][1]}")

    # ============ 7) 柱表底部文字 ============
    if use_frame:
        fcx_text = (bbox[0] + bbox[2]) / 2.0
        fy_min = bbox[1]
        stirrup_text = normalize_phi(args.stirrup)
        rows = [
            args.name,           # S-TAB_TEXT h=450
            args.level,          # S-PUB_TEXT h=300
            normalize_phi(args.rebar),
            stirrup_text,
        ]
        while len(rows) < n_rows:
            rows.append("")
        rows = rows[:n_rows]
        draw_table_text(msp, fcx_text, table_top_y, fw, row_h, rows)

        # ============ 8) 外框尺寸标注（S-DIM 层）============
        # 顶宽 7700
        add_dim_aligned(msp, bbox[0], bbox[3], bbox[2], bbox[3],
                        fw, layer="S-DIM",
                        off=DIM_OFFSET_MM * scale * 0.5, vertical=False)
        # 左侧截面区高 7500
        add_dim_aligned(msp, bbox[0], table_top_y, bbox[0], bbox[3],
                        section_h, layer="S-DIM",
                        off=DIM_OFFSET_MM * scale * 0.5, vertical=True)
        # 左侧行高 800×n_rows
        for i in range(1, n_rows + 1):
            y1 = fy_min + (i - 1) * row_h
            y2 = fy_min + i * row_h
            add_dim_aligned(msp, bbox[0] - DIM_OFFSET_MM * scale * 0.9,
                            y1, bbox[0] - DIM_OFFSET_MM * scale * 0.9, y2,
                            row_h, layer="S-DIM",
                            off=0, vertical=True)
    else:
        # 旧式：详图右侧文字栏
        tx = right + off + LABEL_GAP
        ty = top
        stirrup_text = normalize_phi(args.stirrup)
        lines = [
            ("编号", args.name),
            ("截面", "%d×%d" % (b, h)),
            ("纵筋", normalize_phi(args.rebar)),
            ("箍筋", stirrup_text),
            ("标高", args.level),
        ]
        for i, (label, value) in enumerate(lines):
            y = ty - i * TEXT_LINE
            add_text(msp, "%s  %s" % (label, value), tx, y, TXT_H,
                     "S-COLU_DE_TEXT", align="left")


def main():
    parser = argparse.ArgumentParser(description="绘制柱配筋截面详图（柱表样式，对齐模板 zhuzi.dxf）")
    parser.add_argument("--name", required=True, help="柱编号，如 KZ-3")
    parser.add_argument("--section", required=True, help="截面尺寸，如 500x500")
    parser.add_argument("--rebar", required=True,
                        help="纵筋，如 '8%%13225+4%%13220'（%%132=HRB400符号）")
    parser.add_argument("--stirrup", required=True, help="箍筋，如 '%%1328@100/200'")
    parser.add_argument("--level", required=True, help="标高范围，如 '基础顶~3.470'")
    parser.add_argument("--frame", action="store_true",
                        help="画柱表外框 + 底部 4 行参数表")
    parser.add_argument("--frame-w", type=float, default=DEFAULT_FRAME_W,
                        help="外框宽（默认 7700）")
    parser.add_argument("--frame-h", type=float, default=DEFAULT_FRAME_H,
                        help="外框总高（默认 10700）")
    parser.add_argument("--row-h", type=float, default=DEFAULT_ROW_H,
                        help="柱表行高（默认 800）")
    parser.add_argument("--n-rows", type=int, default=4,
                        help="柱表行数（默认 4）")
    parser.add_argument("--anchor", choices=["column", "frame"], default="column",
                        help="(x,y) 语义：column=柱中心（默认），frame=外框中心")
    parser.add_argument("--no-leader", action="store_true",
                        help="不画角部/边部引出线（默认画）")
    parser.add_argument("--x", type=float, default=30000.0, help="详图 X")
    parser.add_argument("--y", type=float, default=0.0, help="详图 Y")
    parser.add_argument("--scale", type=float, default=DEFAULT_SCALE,
                        help="详图放大倍数（默认 10/3≈3.33，对齐模板）")
    parser.add_argument("--cover", type=float, default=30.0,
                        help="保护层厚度 mm（默认 30，对齐模板）")
    args = parser.parse_args()
    args.leader = not args.no_leader
    args.frame = bool(getattr(args, "frame", False))

    acad = connect()
    doc = acad.ActiveDocument
    msp = doc.ModelSpace
    print("已连接 -> %s" % acad.Caption)

    ensure_standards(doc, layers=DETAIL_LAYERS, verbose=True)

    n = clear_layers(msp, DETAIL_LAYERS)
    print("已清理旧详图实体 %d 个" % n)

    draw_column_detail(msp, args)

    print("柱表详图 %s 已绘制 @(%g, %g)，放大 %.2f 倍，截面 %s"
          % (args.name, args.x, args.y, args.scale, args.section))
    print("纵筋 %s，箍筋 %s" % (normalize_phi(args.rebar), normalize_phi(args.stirrup)))
    if args.frame:
        print("外框 %.0f×%.0f，行数 %d，行高 %.0f" % (
            args.frame_w, args.frame_h, args.n_rows, args.row_h))
    print("COM_LIVE_DRAW=OK")


if __name__ == "__main__":
    main()
