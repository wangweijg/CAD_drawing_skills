# -*- coding: utf-8 -*-
"""把当前模型空间整张图（结构平面图 + 图框）复制一份，用于绘制配筋。

实时连接已打开的 AutoCAD，用 _COPY _all 把所有实体克隆到偏移位置，
新副本整体平移 (dx,dy)。原图不动，副本独立可编辑（可在副本上画配筋）。

⚠️ 不用 CopyObjects 传大对象数组：comtypes 对成百个 IDispatch 的
   SAFEARRAY marshalling 不稳，会直接让进程崩溃（无 traceback）。
   _COPY _all 是 CAD 原生命令，可靠且原子。

用法：
  python cad_copy_drawing.py [--dx 100000] [--dy 0]
"""
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cad_live as L

COPY_DX = 100000.0     # 默认向右偏移（覆盖 A1 1:100 图框 84100 + 间隙）
COPY_DY = 0.0


def main():
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--dx", type=float, default=COPY_DX, help="副本 X 偏移")
    ap.add_argument("--dy", type=float, default=COPY_DY, help="副本 Y 偏移")
    a = ap.parse_args()

    acad = L.connect()
    doc = acad.ActiveDocument
    msp = doc.ModelSpace
    print("已连接 ->", doc.Name)

    before = int(msp.Count)
    if before == 0:
        print("模型空间为空，无可复制实体")
        return

    # 用 CAD 原生 _COPY _all：选中全部 -> 基点 0,0,0 -> 相对位移
    # ⚠️ 末尾必须多一个 \n：COPY 给完第一个位移后会再次提示
    #    “指定第二个点”，不收尾会卡在命令提示符里让 CAD 变忙。
    cmd = "_COPY\n_all\n\n0,0,0\n@%.0f,%.0f,0\n\n" % (a.dx, a.dy)
    try:
        doc.SendCommand(cmd)
    except Exception as e:
        print("[error] SendCommand 失败：%s" % e)
        return

    # 等 CAD 消化命令（_COPY _all 对几百实体需要一点时间）
    time.sleep(3)
    try:
        doc.Regen(True)
    except Exception:
        pass

    after = int(msp.Count)
    copied = after - before
    L.zoom_extents(doc)
    print("复制完成：原 %d 个实体 -> 现 %d 个，新增副本 %d 个（偏移 %.0f, %.0f）"
          % (before, after, copied, a.dx, a.dy))
    print("COM_LIVE_DRAW=OK")


if __name__ == "__main__":
    main()
