# -*- coding: utf-8 -*-
"""在【已打开的 AutoCAD】里直接画规范轴网（实时 COM 制图，不生成 DXF 文件）。

严格遵循 cad_standards.py 的制图标准，与离线出 DXF 的成果完全一致：

    轴线   -> S-DOTE       253 灰 / DOT 点划线 / 0.15
    轴号圈 -> S-AXIS       3   绿 / Continuous / 0.15
    轴号字 -> S-AXIS_TEXT  7   白 / AXIS 样式(txt.shx) / 字高 280
    尺寸   -> S-DIM        3   绿 / DIM100 样式(1:100 建筑斜线)

规范画法要点：
- 轴线端点落在轴号圈【近端】，圆圈整体位于轴线外侧，轴线不穿圈；
- 两级尺寸：内排分跨尺寸(距轴线 1500)、外排总尺寸(距轴线 2250)；
- 尺寸【双侧】布置：下、上、左、右各一整排两级尺寸（施工图常规做法，
  方便现场从任一侧读数）；如只需单侧可加 --dim-single；
- 轴号字母跳过易混淆的 I、O、Z。

运行前提：CAD 已打开，且 CAD 与本脚本的进程权限级别一致
（若 CAD 被 RUNASADMIN 标记强制提权，需先移除该标记，详见 cad_live.py 头注释）。

用法示例：
  python cad_draw_axis.py                                        # 默认 6跨x4000 + 2跨x5600
  python cad_draw_axis.py --x-spans 5 --x-gap 4000 --y-spans 3 --y-gap 5700
  python cad_draw_axis.py --x-spans 5 --x-gap 3600 --y-spans 3 --y-gap 7200 --x-prefix K-
  python cad_draw_axis.py --x-labels 1,2,3,A,B --y-labels C,D,E  # 完全自定义轴号
  python cad_draw_axis.py --no-dim                               # 只画轴网不画尺寸
  python cad_draw_axis.py --dim-single                           # 尺寸只标下侧+左侧
  python cad_draw_axis.py --keep                                 # 不清除旧轴网，叠加绘制

日志写入同目录 cad_axis_draw.log，便于排查 COM 报错。
"""
import sys
import os
import traceback
import argparse

# 让脚本在任意 cwd 下都能 import 同目录的模块
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cad_standards as STD
from cad_live import connect, P, ensure_standards, clear_layers, zoom_extents

LOG_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "cad_axis_draw.log")

# 本脚本涉及的图层（重绘时一并清理）
AXIS_LAYERS = ["S-DOTE", "S-AXIS", "S-AXIS_TEXT", "S-DIM"]

log_lines = []


def log(msg):
    log_lines.append(str(msg))
    print(msg)
    sys.stdout.flush()


def parse_labels(s):
    return [x.strip() for x in s.split(",") if x.strip()] if s else None


# ============================================================
# 核心：画规范轴网
# ============================================================
def draw_axis_grid(app, *, x_spans, x_gap, y_spans, y_gap,
                   x_labels=None, y_labels=None,
                   x_prefix="", y_prefix="",
                   radius=None, text_height=None,
                   with_dim=True, dim_both=True, clear_old=True,
                   ox=0.0, oy=0.0):
    doc = app.ActiveDocument
    msp = doc.ModelSpace

    r = float(radius if radius is not None else STD.AXIS_R)
    th = float(text_height if text_height is not None else STD.AXIS_H)
    endoff = STD.AXIS_ENDOFF          # 轴线延伸终点（=2750）
    center = endoff + r               # 圈心 = 轴线终点 + 半径，保证不穿圈

    # 1) 同步制图标准（图层色/线宽/线型 + 文字样式 + DIM100）
    info = ensure_standards(doc)
    log("  标准同步：图层 %d 个，线型 %s，文字样式 %s"
        % (info["layers"], info["linetypes"], info["styles"]))
    for e in info["errors"][:8]:
        log("    [warn] %s" % e)

    # 2) 清掉上次画的轴网，避免叠加
    if clear_old:
        try:
            old = clear_layers(msp, AXIS_LAYERS)
            if old:
                log("  已清理旧轴网实体 %d 个" % old)
        except Exception as e:
            log("  [warn] 清理旧实体跳过: %s" % e)

    # 3) 轴线坐标与轴号
    xs = [i * x_gap + ox for i in range(x_spans + 1)]
    ys = [j * y_gap + oy for j in range(y_spans + 1)]
    xnum = x_labels if x_labels else STD.axis_labels(len(xs), x_prefix, "number")
    ynum = y_labels if y_labels else STD.axis_labels(len(ys), y_prefix, "letter")

    ok = 0
    fail = 0
    errs = []

    def safe(fn, label):
        nonlocal ok, fail
        try:
            fn()
            ok += 1
        except Exception as e:
            fail += 1
            errs.append("%s: %s %s" % (label, type(e).__name__, str(e)[:160]))

    # ---------- 图元构造 ----------
    def add_axis_line(p1, p2):
        """轴线：S-DOTE 灰色 DOT 点划线（颜色/线型随层）。"""
        ln = msp.AddLine(p1, p2)
        ln.Layer = "S-DOTE"
        return ln

    def add_bubble(cx, cy, text):
        """轴号圈 + 圈内文字，分属 S-AXIS / S-AXIS_TEXT 两层。"""
        c = msp.AddCircle(P(cx, cy), r)
        c.Layer = "S-AXIS"

        t = msp.AddText(str(text), P(cx, cy), th)
        t.Layer = "S-AXIS_TEXT"
        try:
            t.StyleName = "AXIS"          # txt.shx，轴号最稳
        except Exception:
            pass
        try:
            t.Height = th
            t.Alignment = 11              # acAlignmentMiddleCenter
            t.TextAlignmentPoint = P(cx, cy)
        except Exception:
            # 对齐属性不可用时退回左下角插入，手工居中
            try:
                t.InsertionPoint = P(cx - th * 0.3 * len(str(text)), cy - th * 0.5)
            except Exception:
                pass
        return c, t

    def add_dim(p1, p2, textpos, value):
        """对齐标注：DIM100 样式 + S-DIM 绿层，文字强制写实际跨距。"""
        d = msp.AddDimAligned(p1, p2, textpos)
        d.Layer = "S-DIM"
        try:
            d.StyleName = STD.DIMSTYLE_NAME
        except Exception:
            pass
        try:
            d.TextOverride = str(int(round(value)))
        except Exception:
            pass
        return d

    # ---------- 轴线 ----------
    for x in xs:                      # 竖向轴线
        safe(lambda x=x: add_axis_line(P(x, ys[0] - endoff), P(x, ys[-1] + endoff)),
             "vline x=%s" % x)
    for y in ys:                      # 横向轴线
        safe(lambda y=y: add_axis_line(P(xs[0] - endoff, y), P(xs[-1] + endoff, y)),
             "hline y=%s" % y)

    # ---------- 轴号圈（上下 / 左右各一）----------
    for i, x in enumerate(xs):
        safe(lambda x=x, i=i: add_bubble(x, ys[-1] + center, xnum[i]),
             "xbubble top %s" % xnum[i])
        safe(lambda x=x, i=i: add_bubble(x, ys[0] - center, xnum[i]),
             "xbubble bot %s" % xnum[i])
    for j, y in enumerate(ys):
        safe(lambda y=y, j=j: add_bubble(xs[0] - center, y, ynum[j]),
             "ybubble left %s" % ynum[j])
        safe(lambda y=y, j=j: add_bubble(xs[-1] + center, y, ynum[j]),
             "ybubble right %s" % ynum[j])

    # ---------- 两级尺寸标注（双侧：下+上、左+right）----------
    if with_dim:
        d1, d2 = STD.DIM1, STD.DIM2

        def dim_run_h(base_y, sign, tag):
            """水平方向一整排标注（分跨 + 总尺寸）。

            base_y : 尺寸界线起测的基准 Y（下排取 ys[0]，上排取 ys[-1]）
            sign   : -1 向下偏移，+1 向上偏移
            """
            for i in range(len(xs) - 1):
                safe(lambda i=i: add_dim(P(xs[i], base_y), P(xs[i + 1], base_y),
                                         P((xs[i] + xs[i + 1]) / 2.0, base_y + sign * d1),
                                         xs[i + 1] - xs[i]),
                     "xdim %s %d" % (tag, i))
            if len(xs) > 2:
                safe(lambda: add_dim(P(xs[0], base_y), P(xs[-1], base_y),
                                     P((xs[0] + xs[-1]) / 2.0, base_y + sign * d2),
                                     xs[-1] - xs[0]),
                     "xdim %s total" % tag)

        def dim_run_v(base_x, sign, tag):
            """竖直方向一整排标注（分跨 + 总尺寸）。

            base_x : 尺寸界线起测的基准 X（左排取 xs[0]，右排取 xs[-1]）
            sign   : -1 向左偏移，+1 向右偏移
            """
            for j in range(len(ys) - 1):
                safe(lambda j=j: add_dim(P(base_x, ys[j]), P(base_x, ys[j + 1]),
                                         P(base_x + sign * d1, (ys[j] + ys[j + 1]) / 2.0),
                                         ys[j + 1] - ys[j]),
                     "ydim %s %d" % (tag, j))
            if len(ys) > 2:
                safe(lambda: add_dim(P(base_x, ys[0]), P(base_x, ys[-1]),
                                     P(base_x + sign * d2, (ys[0] + ys[-1]) / 2.0),
                                     ys[-1] - ys[0]),
                     "ydim %s total" % tag)

        # 下排 / 左排（单侧标注时只画这两排）
        dim_run_h(ys[0], -1, "bot")
        dim_run_v(xs[0], -1, "left")
        # 上排 / 右排（双侧标注）
        if dim_both:
            dim_run_h(ys[-1], +1, "top")
            dim_run_v(xs[-1], +1, "right")

    # ---------- 刷新 ----------
    zoom_extents(doc)

    log("  轴网：X向 %d跨×%s（轴号 %s~%s）  Y向 %d跨×%s（轴号 %s~%s）"
        % (x_spans, x_gap, xnum[0], xnum[-1], y_spans, y_gap, ynum[0], ynum[-1]))
    log("  完成：成功 %d 个实体，失败 %d 个" % (ok, fail))
    if errs:
        log("  失败明细：")
        for e in errs:
            log("    - " + e)
    try:
        log("  模型空间实体总数: %s" % msp.Count)
    except Exception:
        pass
    log("COM_LIVE_DRAW=OK" if fail == 0 else "COM_LIVE_DRAW=PARTIAL")
    return ok, fail


def main():
    ap = argparse.ArgumentParser(
        description="在已打开的 AutoCAD 上实时画符合机构标准的轴网")
    ap.add_argument("--x-spans", type=int, default=6, help="X 向跨数 (默认6)")
    ap.add_argument("--x-gap", type=float, default=4000, help="X 向轴距 (默认4000)")
    ap.add_argument("--y-spans", type=int, default=2, help="Y 向跨数 (默认2)")
    ap.add_argument("--y-gap", type=float, default=5600, help="Y 向轴距 (默认5600)")
    ap.add_argument("--x-prefix", default="", help="X 轴号前缀，如 K-")
    ap.add_argument("--y-prefix", default="", help="Y 轴号前缀，如 J-")
    ap.add_argument("--x-labels", default=None, help="X 轴号显式列表(逗号分隔)，覆盖自动编号")
    ap.add_argument("--y-labels", default=None, help="Y 轴号显式列表(逗号分隔)，覆盖自动编号")
    ap.add_argument("--radius", type=float, default=None,
                    help="轴号圈半径 (默认按标准 %g)" % STD.AXIS_R)
    ap.add_argument("--text-height", type=float, default=None,
                    help="轴号字高 (默认按标准 %g)" % STD.AXIS_H)
    ap.add_argument("--no-dim", action="store_true", help="不画尺寸标注")
    ap.add_argument("--dim-single", action="store_true",
                    help="尺寸只标下侧+左侧（默认双侧：下上左右四排）")
    ap.add_argument("--keep", action="store_true", help="保留旧轴网，叠加绘制")
    ap.add_argument("--ox", type=float, default=0.0, help="X 起点偏移，默认 0")
    ap.add_argument("--oy", type=float, default=0.0, help="Y 起点偏移，默认 0")
    ap.add_argument("--layer", default=None,
                    help="[已废弃] 图层由标准自动分配(S-DOTE/S-AXIS/S-AXIS_TEXT/S-DIM)")
    args = ap.parse_args()

    if args.layer:
        log("[warn] --layer 已废弃：图层现按机构标准自动分配，忽略该参数")

    try:
        log("连接 AutoCAD ...")
        app = connect()
        log("  已连接 -> %s %s" % (app.Application.Name, app.Version))
    except Exception as e:
        log("FAILED: 无法连接 AutoCAD: %s" % e)
        log("  请确认：① CAD 已打开  ② COM 已注册(/regserver)")
        log("          ③ CAD 与本脚本权限级别一致（检查 acad.exe 的 RUNASADMIN 标记）")
        return

    draw_axis_grid(app,
                   x_spans=args.x_spans, x_gap=args.x_gap,
                   y_spans=args.y_spans, y_gap=args.y_gap,
                   x_labels=parse_labels(args.x_labels),
                   y_labels=parse_labels(args.y_labels),
                   x_prefix=args.x_prefix, y_prefix=args.y_prefix,
                   radius=args.radius, text_height=args.text_height,
                   with_dim=not args.no_dim, dim_both=not args.dim_single,
                   clear_old=not args.keep, ox=args.ox, oy=args.oy)
    log("DONE")


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        log("FAILED: %s %s" % (type(e).__name__, str(e)[:240]))
        log(traceback.format_exc())
    finally:
        try:
            with open(LOG_PATH, "w", encoding="utf-8") as f:
                f.write("\n".join(log_lines))
        except Exception:
            pass
