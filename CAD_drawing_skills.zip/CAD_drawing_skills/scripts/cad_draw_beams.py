# -*- coding: utf-8 -*-
"""在【已打开的 AutoCAD】里，沿轴网把柱与柱用框架梁连接（COM 实时制图）。

严格遵循 cad_standards.py 的制图标准，与离线出 DXF 的成果一致：

    梁双线轮廓 -> S-BEAM_CON   4  青 / Continuous / 0.20
    梁集中标注3行模版 -> S-BEAM_ID(磁红行1) + S-STIRRUP(黄行2/3)
                        / 行1 Standard(GBENOR+GBCBIG) + 配筋行 TSSD_Rein / 字高 260
                        / 配筋符号 %%132（三级钢 HRB400）
                        （模版逻辑见 cad_beam_label.py，22G101-1 §4.2.3）

规范画法要点（22G101-1 第 4 章 + 王工偏好）：
- 梁用【双线】表示梁两侧边线，柱节点内【断开】不画（结构平面图惯例）；
- 中间跨梁（内部轴线上）默认【居中】于轴线：轴线 ± b/2；
- 边跨梁（最外圈轴线上）默认【外边线与柱外边线齐平】（--align outer）：
      外边线 = 轴线 ± 柱半宽
      内边线 = 外边线 ∓ 梁宽
  当「梁宽 == 柱半宽」时内边线恰好落在轴线上，属正常的偏心边梁，
  与轴线（S-DOTE 灰点划线）视觉重合但分属不同图层；
- 梁编号 KL：先 X 向（自下而上，对应 A/B/C 轴），再 Y 向（自左而右，对应 1/2/3 轴），
  括号内为跨数，后跟截面 b×h。
- 梁标注样式（2026-08-06 王工确认）：3 行模版，磁红行1(梁号+截面)+黄色行2/3(箍筋+受力筋)；
  HRB400 三级钢以底部 S-TEXT 总说明收口（配置见 cad_standards.REBAR_GRADE_*）；
  配筋符号默认 %%132（三级钢，配筋行 TSSD_Rein 字体）；
  引出线默认画（2026-08-12 王工要求补充梁配筋引出线），--no-leader 关闭。
- ⚠️ 新规则（2026-08-12 王工）：**未明确要求画配筋时只画平面**——仅轴网+柱+梁+编号+截面，
  不画任何钢筋行/钢筋标注/HRB400 总说明/引出线；给了 --stirrup/--reinf/--side/--beam
  任一配筋参数才画配筋行（默认自动 id_only）。

轴网/柱参数需与 cad_draw_axis.py、cad_draw_columns.py 保持一致，
否则梁端断开位置会对不上柱边。

用法示例：
  python cad_draw_beams.py --x-spans 5 --x-gap 4000 --y-spans 3 --y-gap 5700
  python cad_draw_beams.py --mid 200x400 --edge 250x500      # 显式指定截面
  python cad_draw_beams.py --col-w 500 --col-h 600           # 矩形柱 500x600：按方向正确断开/外边对齐
  python cad_draw_beams.py --align center                    # 边梁也居中（不外齐）
  python cad_draw_beams.py --col-size 600                    # 柱 600 时断开位置随之变化
  python cad_draw_beams.py --no-text                         # 只画双线不标注
  python cad_draw_beams.py                                   # 默认：未给配筋参数 → 仅平面（编号+截面），不画钢筋
  python cad_draw_beams.py --id-only                         # 强制只标梁编号+截面（如 KL1(4) 250x500）
  python cad_draw_beams.py --keep                            # 保留旧梁，叠加绘制
  python cad_draw_beams.py --stirrup "%%1328@100(2)" --reinf "2%%13218; 3%%13220"   # 显式配筋（%%132=三级钢符号）
  python cad_draw_beams.py --no-leader                       # 不画引出线
  python cad_draw_beams.py --no-hrb400-note                  # 不画 HRB400 总说明

日志写入同目录 cad_beams_draw.log。
"""
import sys
import os
import math
import traceback
import argparse

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cad_standards as STD
from cad_live import connect, P, ensure_standards, clear_layers, zoom_extents
from cad_beam_label import draw_beam_label, label_anchor_y, LINE_GAP

LOG_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                        "cad_beams_draw.log")

# 重绘时一并清理：双线轮廓 + 3 行模版两层 + 引出线层 + 旧单行层
# ⚠️ 必须含 S-BEAM_ID / S-STIRRUP，否则清不掉旧图元会叠加（今日踩过的坑）
BEAM_LAYERS = ["S-BEAM_CON", "S-BEAM_ID", "S-STIRRUP", "S-BEAM", "S-BEAM_TEXT"]

BEAM_TXT_H = 260.0        # 梁标注字高（对齐离线生成器 BEAM_H）
X_TXT_OFF = 160.0         # X 向（横向）标注：原 600 下移 440，贴近梁上侧
X_TXT_CLEAR = 200.0       # 多行集中标注：最下面一行下缘距梁边线（上侧）的净距
Y_TXT_CLEAR = 250.0       # Y 向（纵向）标注：文字近梁侧边缘距梁边线的净距（2026-08-12 王工确认）
NOTE_H = 250.0            # HRB400 总说明字高
NOTE_Y = -3350.0          # 总说明落点（尺寸线之下）

log_lines = []


def log(msg):
    log_lines.append(str(msg))
    print(msg)
    sys.stdout.flush()


def parse_section(s, default):
    """解析 '200x400' / '200*400' / '200X400' -> (200.0, 400.0)。"""
    if not s:
        return default
    t = str(s).lower().replace("*", "x").replace("×", "x")
    parts = [p for p in t.split("x") if p.strip()]
    if len(parts) != 2:
        raise ValueError("截面格式应为 bxh，如 200x400，收到: %r" % s)
    return (float(parts[0]), float(parts[1]))

def parse_beam_override(s):
    """解析单梁配筋覆盖，格式：梁号:受力筋|箍筋（受力筋/箍筋可省略一个）。

    例：'KL1:2%%13222;2%%13222|%%1328@100/200(2)' -> ('KL1', '2%%13222;2%%13222',
                                                    '%%1328@100/200(2)')
    """
    if ":" not in s:
        raise ValueError("单梁配筋格式应为 梁号:受力筋|箍筋，收到: %r" % s)
    bid, rest = s.split(":", 1)
    if "|" in rest:
        reinf, stirrup = rest.split("|", 1)
    else:
        reinf, stirrup = rest, None
    return (bid.strip(),
            (reinf.strip() or None),
            (stirrup.strip() or None))



def beam_edges(axis, is_low_edge, is_high_edge, bw, col_hw, align):
    """返回梁两条边线相对坐标 (e1, e2)。

    axis        : 该梁所在轴线坐标
    is_low_edge : 是否为下/左边跨轴线
    is_high_edge: 是否为上/右边跨轴线
    bw          : 梁宽
    col_hw      : 柱半宽
    align       : 'outer' 边梁外边线与柱外边齐；'center' 一律居中
    """
    if align == "outer" and is_low_edge:
        out = axis - col_hw            # 外边线 = 柱外边线
        return (out, out + bw)
    if align == "outer" and is_high_edge:
        out = axis + col_hw
        return (out - bw, out)
    return (axis - bw / 2.0, axis + bw / 2.0)


# ============================================================
# 核心：沿轴网画框架梁
# ============================================================
def draw_beams(app, *, x_spans, x_gap, y_spans, y_gap,
               col_size=500.0, col_w=None, col_h=None,
               mid_bw=200.0, mid_bh=400.0,
               edge_bw=250.0, edge_bh=500.0,
               align="outer", with_text=True,
               txt_height=None, tag_prefix="KL",
               stirrup=None, reinf=None, side=None,
               label_style="today",
               with_leader=True, with_hrb400_note=True,
               id_only=None, clear_old=True,
               beam_overrides=None):
    doc = app.ActiveDocument
    msp = doc.ModelSpace

    # ⚠️ 王工 2026-08-12 规则：未显式给配筋参数 → 只画平面（编号+截面），不画任何钢筋
    if id_only is None:
        id_only = not (stirrup or reinf or side or bool(beam_overrides))
    log("  标注模式：%s" % ("仅平面（编号+截面，无配筋）" if id_only
                            else "3 行模版（含配筋）"))

    th = float(txt_height if txt_height is not None else BEAM_TXT_H)
    # 柱截面：col_w 沿 X 向、col_h 沿 Y 向；缺省回退方柱 col_size
    cw = float(col_w if col_w else col_size)
    ch = float(col_h if col_h else col_size)

    # 1) 同步制图标准
    info = ensure_standards(doc)
    log("  标准同步：图层 %d 个，线型 %s，文字样式 %s"
        % (info["layers"], info["linetypes"], info["styles"]))
    for e in info["errors"][:8]:
        log("    [warn] %s" % e)

    # 2) 清掉上次画的梁（含 3 行模版层，避免残留叠加）
    if clear_old:
        try:
            old = clear_layers(msp, BEAM_LAYERS)
            if old:
                log("  已清理旧梁实体 %d 个" % old)
        except Exception as e:
            log("  [warn] 清理旧实体跳过: %s" % e)

    # 3) 轴线坐标（与轴网/柱同一套原点）
    xs = [i * x_gap for i in range(x_spans + 1)]
    ys = [j * y_gap for j in range(y_spans + 1)]

    ok = 0
    fail = 0
    errs = []

    def safe(fn, label):
        nonlocal ok, fail
        try:
            fn()
            ok += 1
        except Exception as e:
            fail += 1
            errs.append("%s: %s %s" % (label, type(e).__name__, str(e)[:160]))

    def line(x1, y1, x2, y2, layer="S-BEAM_CON"):
        ln = msp.AddLine(P(x1, y1), P(x2, y2))
        ln.Layer = layer
        return ln

    # put_text 已弃用：梁标注统一走 cad_beam_label.draw_beam_label（3 行模版）
    def put_text(txt, x, y, rot=0.0, align=0):
        t = msp.AddText(str(txt), P(x, y), th)
        t.Layer = "S-BEAM_TEXT"
        try:
            t.StyleName = "Standard"
        except Exception:
            pass
        try:
            t.Height = th
        except Exception:
            pass
        if rot:
            try:
                t.Rotation = float(rot)
            except Exception:
                pass
        if align:
            try:
                t.Alignment = align          # 1=Center, 4=MiddleCenter
                t.TextAlignmentPoint = P(x, y)
            except Exception:
                pass
        return t

    def beam_label_params(tag):
        """单梁配筋覆盖优先；无覆盖时回退全局参数。

        王工 2026-08-12 规则：梁没有显式配筋时只标编号+截面（id_only），
        不画箍筋/受力筋/侧面筋任何一行。
        """
        ov = (beam_overrides or {}).get(tag)
        if ov:
            ov_reinf, ov_stirrup = ov
            return (ov_stirrup, ov_reinf, side, False, with_leader)
        # 无全局配筋参数 → 非覆盖梁一律只画平面（编号+截面）
        plan_only = id_only or not (stirrup or reinf or side)
        return (stirrup, reinf, side, plan_only, False if plan_only else with_leader)

    tags = []          # (编号, 走向, 轴线, 截面, 跨数)
    seg_count = 0
    n = 0

    # ---------- X 向框架梁（沿每条横轴，自下而上编号）----------
    for jy, y in enumerate(ys):
        is_lo = (jy == 0)
        is_hi = (jy == len(ys) - 1)
        edge = is_lo or is_hi
        bw, bh = (edge_bw, edge_bh) if edge else (mid_bw, mid_bh)
        e1, e2 = beam_edges(y, is_lo, is_hi, bw, ch / 2.0, align)

        n += 1
        tag = "%s%d" % (tag_prefix, n)
        spans = 0
        for i in range(len(xs) - 1):
            xa = xs[i] + cw / 2.0        # 柱内断开（沿 X 向，用柱 X 半宽）
            xb = xs[i + 1] - cw / 2.0
            if xb <= xa:
                continue
            safe(lambda xa=xa, xb=xb, e=e1: line(xa, e, xb, e),
                 "%s 下线 跨%d" % (tag, i + 1))
            safe(lambda xa=xa, xb=xb, e=e2: line(xa, e, xb, e),
                 "%s 上线 跨%d" % (tag, i + 1))
            spans += 1
            seg_count += 1

        if with_text and spans:
            # X向标注：梁上侧、居中于第一跨，整体抬高以避让同排柱编号
            # 3 行模版（dir='h' 自上而下：梁身份→箍筋→受力筋）
            # 多行集中标注：左对齐 + 最下面一行下缘距梁边线 X_TXT_CLEAR + 引出线
            stir, reinf_, sid, ido, ld = beam_label_params(tag)
            n_lines = 1 if ido else (4 if sid else 3)
            full = n_lines > 1
            if full:
                txt_y = label_anchor_y(e2 + X_TXT_CLEAR, n_lines, th, LINE_GAP)
                txt_align = "left"
            else:
                txt_y = e2 + X_TXT_OFF
                txt_align = "center"
            cx = (xs[0] + xs[1]) / 2.0
            axis = (e1 + e2) / 2.0
            safe(lambda tag=tag, cx=cx, y=txt_y, bw=bw, bh=bh, sp=spans, ax=axis,
                 stir=stir, reinf_=reinf_, sid=sid, ido=ido, ld=ld, al=txt_align:
                 draw_beam_label(msp, beam_id=tag, spans=sp, bw=bw, bh=bh,
                                 stirrup=stir,
                                 reinf=reinf_,
                                 side=sid,
                                 style=label_style,
                                 x=cx, y=y, dir="h", id_only=ido,
                                 with_leader=ld if full else False,
                                 beam_axis=ax,
                                 align=al),
                 "%s 标注" % tag)
        tags.append((tag, "X", y, (bw, bh), spans, (e1, e2)))

    # ---------- Y 向框架梁（沿每条竖轴，自左而右编号）----------
    for ix, x in enumerate(xs):
        is_lo = (ix == 0)
        is_hi = (ix == len(xs) - 1)
        edge = is_lo or is_hi
        bw, bh = (edge_bw, edge_bh) if edge else (mid_bw, mid_bh)
        e1, e2 = beam_edges(x, is_lo, is_hi, bw, cw / 2.0, align)

        n += 1
        tag = "%s%d" % (tag_prefix, n)
        spans = 0
        for j in range(len(ys) - 1):
            ya = ys[j] + ch / 2.0        # 柱内断开（沿 Y 向，用柱 Y 半宽）
            yb = ys[j + 1] - ch / 2.0
            if yb <= ya:
                continue
            safe(lambda ya=ya, yb=yb, e=e1: line(e, ya, e, yb),
                 "%s 左线 跨%d" % (tag, j + 1))
            safe(lambda ya=ya, yb=yb, e=e2: line(e, ya, e, yb),
                 "%s 右线 跨%d" % (tag, j + 1))
            spans += 1
            seg_count += 1

        if with_text and spans:
            # Y向标注：梁右侧、居中于第一跨；对齐方式与 X 向一致
            #（只参考对齐方式，不参考旋转角度；旋转仍为 90°）
            # 3 行模版（dir='v' 自左而右：梁身份→箍筋→受力筋）
            # 文字近梁侧边缘距梁边线 Y_TXT_CLEAR，避免文字/线型重叠
            stir, reinf_, sid, ido, ld = beam_label_params(tag)
            n_lines = 1 if ido else (4 if sid else 3)
            full = n_lines > 1
            if full:
                # 多行左对齐：块左缘（第①行梁号）距梁边线 Y_TXT_CLEAR
                txt_x = e2 + Y_TXT_CLEAR + th * LINE_GAP
                txt_align = "left"
            else:
                # 单行居中：文字近梁侧（左缘）距梁边线 Y_TXT_CLEAR
                txt_x = e2 + Y_TXT_CLEAR + th / 2.0
                txt_align = "center"
            cy = (ys[0] + ys[1]) / 2.0
            axis = (e1 + e2) / 2.0
            safe(lambda tag=tag, x=txt_x, cy=cy, bw=bw, bh=bh, sp=spans, ax=axis,
                 stir=stir, reinf_=reinf_, sid=sid, ido=ido, ld=ld, al=txt_align:
                 draw_beam_label(msp, beam_id=tag, spans=sp, bw=bw, bh=bh,
                                 stirrup=stir,
                                 reinf=reinf_,
                                 side=sid,
                                 style=label_style,
                                 x=x, y=cy, dir="v", id_only=ido,
                                 with_leader=ld if full else False,
                                 beam_axis=ax,
                                 align=al),
                 "%s 标注" % tag)
        tags.append((tag, "Y", x, (bw, bh), spans, (e1, e2)))

    # HRB400 三级钢总说明（未逐根写等级，依 22G101 惯例以总说明收口；文案见 cad_standards）
    if with_hrb400_note and (not id_only or bool(beam_overrides)):
        try:
            note = msp.AddText(STD.REBAR_GRADE_NOTE,
                               P(0.0, NOTE_Y), NOTE_H)
            note.Layer = "S-TEXT"
            try:
                note.StyleName = "Standard"
            except Exception:
                pass
        except Exception:
            pass

    zoom_extents(doc)

    # ---------- 汇总 ----------
    log("  柱截面 %gx%g（X/Y 半宽 %g/%g）；对齐方式：%s"
        % (cw, ch, cw / 2.0, ch / 2.0,
           "边梁外边线与柱外边齐" if align == "outer" else "全部居中于轴线"))
    log("  中跨梁 %gx%g   边跨梁 %gx%g" % (mid_bw, mid_bh, edge_bw, edge_bh))
    log("  梁道数 %d（X向 %d + Y向 %d），梁段 %d 段"
        % (len(tags), len(ys), len(xs), seg_count))
    for tag, d, axis, sec, spans, (e1, e2) in tags:
        log("    %-6s %s向 轴线=%-8g 截面=%gx%g 跨数=%d 边线=%g / %g"
            % (tag, d, axis, sec[0], sec[1], spans, e1, e2))
    log("  完成：成功 %d 个操作，失败 %d 个" % (ok, fail))
    if errs:
        log("  失败明细：")
        for e in errs:
            log("    - " + e)
    try:
        log("  模型空间实体总数: %s" % msp.Count)
    except Exception:
        pass
    log("COM_LIVE_DRAW=OK" if fail == 0 else "COM_LIVE_DRAW=PARTIAL")
    return ok, fail


def main():
    ap = argparse.ArgumentParser(
        description="在已打开的 AutoCAD 上沿轴网把柱与柱用框架梁连接")
    # 轴网（需与 cad_draw_axis.py / cad_draw_columns.py 一致）
    ap.add_argument("--x-spans", type=int, default=6, help="X 向跨数 (默认6)")
    ap.add_argument("--x-gap", type=float, default=4000, help="X 向轴距 (默认4000)")
    ap.add_argument("--y-spans", type=int, default=2, help="Y 向跨数 (默认2)")
    ap.add_argument("--y-gap", type=float, default=5600, help="Y 向轴距 (默认5600)")
    # 柱（决定梁在节点处的断开位置）
    ap.add_argument("--col-size", type=float, default=500,
                    help="柱截面边长，用于柱内断开 (默认500)")
    ap.add_argument("--col-w", type=float, default=None,
                    help="柱截面沿 X 向尺寸，覆盖 --col-size（矩形柱）")
    ap.add_argument("--col-h", type=float, default=None,
                    help="柱截面沿 Y 向尺寸，覆盖 --col-size（矩形柱）")
    # 梁截面
    ap.add_argument("--mid", default="200x400",
                    help="中间跨梁截面 bxh (默认 200x400)")
    ap.add_argument("--edge", default="250x500",
                    help="边跨梁截面 bxh (默认 250x500)")
    ap.add_argument("--align", choices=("outer", "center"), default="outer",
                    help="边跨梁定位：outer=外边线与柱外边齐(默认)，center=居中于轴线")
    # 表现
    ap.add_argument("--prefix", default="KL", help="梁编号前缀 (默认 KL)")
    ap.add_argument("--txt-height", type=float, default=None,
                    help="梁标注字高 (默认 %g)" % BEAM_TXT_H)
    ap.add_argument("--no-text", action="store_true", help="不画梁平法标注")
    ap.add_argument("--id-only", action="store_true", default=None,  # None=未指定→自动（无配筋参数时仅平面）
                    help="只标梁编号+跨数+截面（如 KL1(4) 250x500），不画箍筋/受力筋；"
                         "默认：未给配筋参数时自动生效，本开关用于强制")
    ap.add_argument("--keep", action="store_true", help="保留旧梁，叠加绘制")
    ap.add_argument("--beam", action="append", default=None,
                    help="单梁配筋覆盖，格式 梁号:受力筋|箍筋（可多次使用）；"
                         "例 --beam \"KL1:2%%13222;2%%13222|%%1328@100/200(2)\"；"
                         "给了即视为要求画配筋")
    ap.add_argument("--stirrup", default=None,
                    help="箍筋标注（给了才画配筋行；%%132=三级钢符号，如 %%1328@200(2)）")
    ap.add_argument("--reinf", default=None,
                    help="受力筋标注（给了才画配筋行；如 2%%13214; 3%%13218）")
    ap.add_argument("--side", default=None,
                    help="侧面筋第④行，如 N4%%13212（抗扭）/ G4%%13212（构造）；给了才画")
    ap.add_argument("--label-style", default="today",
                    choices=("today", "real", "real_flat"),
                    help="梁标注样式：today=分层磁红+黄(默认,王工08-06确认) / "
                         "real=真实工程标准(单层S-BEAM_TEXT+实体色) / "
                         "real_flat=真实工程原样(单层单色)")
    ap.add_argument("--leader", action="store_true",
                    help="[兼容保留] 画引出线；2026-08-12 起默认画，本开关无效果")
    ap.add_argument("--no-leader", action="store_true",
                    help="不画引出线（覆盖默认）")
    ap.add_argument("--no-hrb400-note", action="store_true",
                    help="不画 HRB400 三级钢总说明")
    args = ap.parse_args()

    mid = parse_section(args.mid, (200.0, 400.0))
    beam_overrides = {}
    if args.beam:
        for b in args.beam:
            bid, br, bs = parse_beam_override(b)
            beam_overrides[bid] = (br, bs)
    edge = parse_section(args.edge, (250.0, 500.0))

    try:
        log("连接 AutoCAD ...")
        app = connect()
        log("  已连接 -> %s %s" % (app.Application.Name, app.Version))
    except Exception as e:
        log("FAILED: 无法连接 AutoCAD: %s" % e)
        log("  请确认：① CAD 已打开  ② COM 已注册(/regserver)")
        log("          ③ CAD 与本脚本权限级别一致（检查 acad.exe 的 RUNASADMIN 标记）")
        return

    try:
        draw_beams(app,
                   x_spans=args.x_spans, x_gap=args.x_gap,
                   y_spans=args.y_spans, y_gap=args.y_gap,
                   col_size=args.col_size,
                   col_w=args.col_w, col_h=args.col_h,
                   mid_bw=mid[0], mid_bh=mid[1],
                   edge_bw=edge[0], edge_bh=edge[1],
                   align=args.align,
                   with_text=not args.no_text,
                   txt_height=args.txt_height,
                   tag_prefix=args.prefix,
                   stirrup=args.stirrup,
                   reinf=args.reinf,
                   side=args.side,
                   label_style=args.label_style,
                   # 引出线默认画（2026-08-12 王工要求补充）；--no-leader 关闭
                   with_leader=not args.no_leader,
                   with_hrb400_note=not args.no_hrb400_note,
                   id_only=args.id_only,
                   clear_old=not args.keep,
                   beam_overrides=beam_overrides)
    except Exception:
        log("FAILED: 绘制异常")
        log(traceback.format_exc())
    finally:
        try:
            with open(LOG_PATH, "w", encoding="utf-8") as f:
                f.write("\n".join(log_lines))
        except Exception:
            pass
    log("DONE")


if __name__ == "__main__":
    main()

