# -*- coding: utf-8 -*-
"""在【已打开的 AutoCAD】里，于轴网节点位置实时绘制框架柱（COM 实时制图）。

严格遵循 cad_standards.py 的制图标准，与离线出 DXF 的成果一致：

    柱轮廓 -> S-COLU        6   洋红 / Continuous / 0.30
    柱填充 -> S-COLU_HATCH  254 深灰 / 实心涂黑（2D SOLID）
    柱编号 -> S-COLU_NUM    7   白  / AXIS 样式(txt.shx) / 字高 220

规范画法要点：
- 柱形心对准轴线交点（默认），符合中柱居中的常规做法；
- 柱截面涂黑（结构平面图惯例），用 2D SOLID 而非 HATCH（见 cad_live.add_solid_fill）；
- 柱编号 KZ-n 自左下角起、按行从下往上编（与轴号 A/B/C 顺序一致）。

轴网参数需与 cad_draw_axis.py 保持一致，才能让柱准确落在节点上。

用法示例：
  python cad_draw_columns.py                                     # 默认 6跨x4000 + 2跨x5600，柱 500x500
  python cad_draw_columns.py --x-spans 5 --x-gap 4000 --y-spans 3 --y-gap 5700
  python cad_draw_columns.py --size 600                          # 600x600 方柱
  python cad_draw_columns.py --width 500 --height 700            # 500x700 矩形柱
  python cad_draw_columns.py --no-num                            # 不标柱号
  python cad_draw_columns.py --no-fill                           # 只画轮廓不涂黑
  python cad_draw_columns.py --corner-only                       # 只在四个角点布柱
  python cad_draw_columns.py --keep                              # 保留旧柱，叠加绘制

日志写入同目录 cad_columns_draw.log。
"""
import sys
import os
import traceback
import argparse

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cad_standards as STD
from cad_live import (connect, P, ensure_standards, clear_layers,
                      zoom_extents, add_rect, add_solid_fill)

LOG_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                        "cad_columns_draw.log")

# 本脚本涉及的图层（重绘时一并清理）
COLUMN_LAYERS = ["S-COLU", "S-COLU_HATCH", "S-COLU_NUM"]

COLU_NUM_H = 220.0        # 柱编号字高（对齐离线生成器）

log_lines = []


def log(msg):
    log_lines.append(str(msg))
    print(msg)
    sys.stdout.flush()


# ============================================================
# 核心：在轴网节点画柱
# ============================================================
def draw_columns(app, *, x_spans, x_gap, y_spans, y_gap,
                 col_w=500.0, col_h=500.0,
                 with_num=True, with_fill=True,
                 tag_prefix="KZ-", corner_only=False,
                 num_height=None, clear_old=True):
    doc = app.ActiveDocument
    msp = doc.ModelSpace

    nh = float(num_height if num_height is not None else COLU_NUM_H)

    # 1) 同步制图标准
    info = ensure_standards(doc)
    log("  标准同步：图层 %d 个，线型 %s，文字样式 %s"
        % (info["layers"], info["linetypes"], info["styles"]))
    for e in info["errors"][:8]:
        log("    [warn] %s" % e)

    # 2) 清掉上次画的柱
    if clear_old:
        try:
            old = clear_layers(msp, COLUMN_LAYERS)
            if old:
                log("  已清理旧柱实体 %d 个" % old)
        except Exception as e:
            log("  [warn] 清理旧实体跳过: %s" % e)

    # 3) 节点坐标（与 cad_draw_axis.py 同一套原点，保证柱落在轴线交点上）
    xs = [i * x_gap for i in range(x_spans + 1)]
    ys = [j * y_gap for j in range(y_spans + 1)]

    if corner_only:
        nodes = [(x, y) for x in (xs[0], xs[-1]) for y in (ys[0], ys[-1])]
    else:
        # 按行从下往上、每行从左到右编号，与轴号 A/B/C… 的顺序一致
        nodes = [(x, y) for y in ys for x in xs]

    ok = 0
    fail = 0
    errs = []

    def safe(fn, label):
        nonlocal ok, fail
        try:
            fn()
            ok += 1
        except Exception as e:
            fail += 1
            errs.append("%s: %s %s" % (label, type(e).__name__, str(e)[:160]))

    def add_column(cx, cy, tag=None):
        """一根柱 = 轮廓多段线 + 实心涂黑 + 可选编号（引线+下划线+文字）。"""
        add_rect(msp, cx, cy, col_w, col_h, layer="S-COLU")
        if with_fill:
            add_solid_fill(msp, cx, cy, col_w, col_h, layer="S-COLU_HATCH")
        if tag:
            # ---- 编号样式：45°引线 + 水平下划线 + 文字居下划线上方 ----
            tag_str = str(tag)
            # 柱右上角
            corner_x = cx + col_w / 2.0
            corner_y = cy + col_h / 2.0
            # 引线长度与文字高度成比例
            lead_len = nh * 0.8
            dx = lead_len * 0.70710678   # cos45
            dy = lead_len * 0.70710678   # sin45
            # 下划线左端（引线终点）
            ul_x1 = corner_x + dx
            ul_y = corner_y + dy
            # 估算文字宽度，下划线略宽于文字
            text_width = max(len(tag_str) * nh * 0.72, nh * 1.5)
            ul_x2 = ul_x1 + text_width
            # 文字中心：位于下划线中点上方
            text_cx = (ul_x1 + ul_x2) / 2.0
            text_cy = ul_y + nh * 0.55

            # 引线
            ln = msp.AddLine(P(corner_x, corner_y), P(ul_x1, ul_y))
            ln.Layer = "S-COLU_NUM"
            # 水平下划线
            ul = msp.AddLine(P(ul_x1, ul_y), P(ul_x2, ul_y))
            ul.Layer = "S-COLU_NUM"
            # 文字（中中对齐，对齐点即文字中心）
            t = msp.AddText(tag_str, P(text_cx, text_cy), nh)
            t.Layer = "S-COLU_NUM"
            try:
                t.Alignment = 4          # acAlignmentMiddleCenter
            except Exception:
                pass
            try:
                t.TextAlignmentPoint = P(text_cx, text_cy)
            except Exception:
                pass
            try:
                t.StyleName = "AXIS"
            except Exception:
                pass
            try:
                t.Height = nh
            except Exception:
                pass

    # ---------- 逐个节点画柱 ----------
    for idx, (cx, cy) in enumerate(nodes, start=1):
        tag = ("%s%d" % (tag_prefix, idx)) if with_num else None
        safe(lambda cx=cx, cy=cy, tag=tag: add_column(cx, cy, tag),
             "column @(%.0f,%.0f)" % (cx, cy))

    zoom_extents(doc)

    log("  柱截面 %gx%g，共 %d 根（%s）"
        % (col_w, col_h, len(nodes),
           "仅四角" if corner_only else "全部 %dx%d 节点" % (len(xs), len(ys))))
    log("  填充：%s   编号：%s"
        % ("实心涂黑" if with_fill else "无",
           "%s1~%s%d" % (tag_prefix, tag_prefix, len(nodes)) if with_num else "无"))
    log("  完成：成功 %d 根，失败 %d 根" % (ok, fail))
    if errs:
        log("  失败明细：")
        for e in errs:
            log("    - " + e)
    try:
        log("  模型空间实体总数: %s" % msp.Count)
    except Exception:
        pass
    log("COM_LIVE_DRAW=OK" if fail == 0 else "COM_LIVE_DRAW=PARTIAL")
    return ok, fail


def main():
    ap = argparse.ArgumentParser(
        description="在已打开的 AutoCAD 上于轴网节点实时绘制框架柱")
    # 轴网（需与 cad_draw_axis.py 一致）
    ap.add_argument("--x-spans", type=int, default=6, help="X 向跨数 (默认6)")
    ap.add_argument("--x-gap", type=float, default=4000, help="X 向轴距 (默认4000)")
    ap.add_argument("--y-spans", type=int, default=2, help="Y 向跨数 (默认2)")
    ap.add_argument("--y-gap", type=float, default=5600, help="Y 向轴距 (默认5600)")
    # 柱截面
    ap.add_argument("--size", type=float, default=500,
                    help="方柱边长 (默认500，等价于 --width=--height)")
    ap.add_argument("--width", type=float, default=None, help="柱截面宽 b，覆盖 --size")
    ap.add_argument("--height", type=float, default=None, help="柱截面高 h，覆盖 --size")
    # 表现
    ap.add_argument("--prefix", default="KZ-", help="柱编号前缀 (默认 KZ-)")
    ap.add_argument("--num-height", type=float, default=None,
                    help="柱编号字高 (默认 %g)" % COLU_NUM_H)
    ap.add_argument("--no-num", action="store_true", help="不标柱编号")
    ap.add_argument("--no-fill", action="store_true", help="不涂黑，只画轮廓")
    ap.add_argument("--corner-only", action="store_true", help="只在四个角点布柱")
    ap.add_argument("--keep", action="store_true", help="保留旧柱，叠加绘制")
    args = ap.parse_args()

    cw = args.width if args.width is not None else args.size
    ch = args.height if args.height is not None else args.size

    try:
        log("连接 AutoCAD ...")
        app = connect()
        log("  已连接 -> %s %s" % (app.Application.Name, app.Version))
    except Exception as e:
        log("FAILED: 无法连接 AutoCAD: %s" % e)
        log("  请确认：① CAD 已打开  ② COM 已注册(/regserver)")
        log("          ③ CAD 与本脚本权限级别一致（检查 acad.exe 的 RUNASADMIN 标记）")
        return

    draw_columns(app,
                 x_spans=args.x_spans, x_gap=args.x_gap,
                 y_spans=args.y_spans, y_gap=args.y_gap,
                 col_w=cw, col_h=ch,
                 with_num=not args.no_num, with_fill=not args.no_fill,
                 tag_prefix=args.prefix, corner_only=args.corner_only,
                 num_height=args.num_height, clear_old=not args.keep)
    log("DONE")


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        log("FAILED: %s %s" % (type(e).__name__, str(e)[:240]))
        log(traceback.format_exc())
    finally:
        try:
            with open(LOG_PATH, "w", encoding="utf-8") as f:
                f.write("\n".join(log_lines))
        except Exception:
            pass
