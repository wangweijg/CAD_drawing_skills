﻿# -*- coding: utf-8 -*-
"""一键绘制框架平面：轴网 + 柱 + 梁（单次连接 AutoCAD，实时 COM 制图）。

把 cad_draw_axis / cad_draw_columns / cad_draw_beams 三个脚本合并为一次运行：
只连接一次 CAD、只同步一次制图标准、只缩放到全图一次，大幅减少耗时。

用法示例：
  python cad_draw_frame.py --x-spans 4 --x-gap 5000 --y-spans 2 --y-gap 7000 \
      --col 500x600 --mid 200x400 --edge 300x500 --align outer --id-only

运行前提：CAD 已打开，且 CAD 与本脚本进程权限级别一致（同管理员/同普通）。
日志写入同目录 cad_frame_draw.log。
"""
import sys
import os
import traceback
import argparse

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cad_live import connect, zoom_extents, wait_quiescent
import cad_draw_axis as AX
import cad_draw_columns as COL
import cad_draw_beams as BM

LOG_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "cad_frame_draw.log")
log_lines = []


def log(msg):
    log_lines.append(str(msg))
    print(msg)
    sys.stdout.flush()


def parse_section(s, default):
    if not s:
        return default
    try:
        w, h = s.lower().replace("x", "*").split("*")
        return float(w), float(h)
    except Exception:
        return default


def main():
    ap = argparse.ArgumentParser(
        description="One-shot frame plan: axis grid + columns + beams (single COM session)")
    ap.add_argument("--x-spans", type=int, default=6, help="X-direction spans count")
    ap.add_argument("--x-gap", type=float, default=4000.0, help="X-direction span length")
    ap.add_argument("--y-spans", type=int, default=2, help="Y-direction spans count")
    ap.add_argument("--y-gap", type=float, default=5600.0, help="Y-direction span length")
    ap.add_argument("--col", default=None, help="column section WxH, e.g. 500x600")
    ap.add_argument("--col-w", type=float, default=None, help="column width (X)")
    ap.add_argument("--col-h", type=float, default=None, help="column height (Y)")
    ap.add_argument("--mid", default="200x400", help="mid-span beam section, e.g. 200x400")
    ap.add_argument("--edge", default="250x500", help="edge beam section, e.g. 300x500")
    ap.add_argument("--align", default="outer", choices=("outer", "center"),
                    help="beam align: outer (edge beams flush to column outer face) or center")
    ap.add_argument("--id-only", action="store_true",
                    help="beam label: id + section only (skip rebar annotation)")
    ap.add_argument("--no-dim", action="store_true", help="skip dimension lines in axis grid")
    ap.add_argument("--keep", action="store_true", help="keep old entities, draw on top")
    # --- passthrough extras (beam label / column tags) ---
    ap.add_argument("--prefix", default=None, help="tag prefix override (column/beam)")
    ap.add_argument("--label-style", default="today",
                    choices=("today", "real", "real_flat"))
    ap.add_argument("--stirrup", default=None, help="stirrup annotation override")
    ap.add_argument("--reinf", default=None, help="main rebar annotation override")
    ap.add_argument("--side", default=None, help="side rebar annotation override")
    ap.add_argument("--leader", action="store_true", help="draw leader lines for beam labels")
    ap.add_argument("--no-hrb400-note", action="store_true",
                    help="skip HRB400 general note")
    args = ap.parse_args()

    if args.col:
        cw, ch = parse_section(args.col, (500.0, 500.0))
    else:
        cw = float(args.col_w if args.col_w is not None else 500.0)
        ch = float(args.col_h if args.col_h is not None else 500.0)
    mid_bw, mid_bh = parse_section(args.mid, (200.0, 400.0))
    edge_bw, edge_bh = parse_section(args.edge, (250.0, 500.0))

    try:
        log("连接 AutoCAD ...")
        app = connect()
        log("  已连接 -> %s %s" % (app.Application.Name, app.Version))
    except Exception as e:
        log("FAILED: 无法连接 AutoCAD: %s" % e)
        log("  请确认：1) CAD 已打开  2) COM 已注册(/regserver)")
        log("          3) CAD 与本脚本进程权限级别一致（检查 RUNASADMIN 标记）")
        return

    try:
        AX.draw_axis_grid(app,
                          x_spans=args.x_spans, x_gap=args.x_gap,
                          y_spans=args.y_spans, y_gap=args.y_gap,
                          with_dim=not args.no_dim, clear_old=not args.keep)
        wait_quiescent(app)
        COL.draw_columns(app,
                         x_spans=args.x_spans, x_gap=args.x_gap,
                         y_spans=args.y_spans, y_gap=args.y_gap,
                         col_w=cw, col_h=ch,
                         tag_prefix=args.prefix or "KZ-",
                         clear_old=not args.keep)
        wait_quiescent(app)
        BM.draw_beams(app,
                      x_spans=args.x_spans, x_gap=args.x_gap,
                      y_spans=args.y_spans, y_gap=args.y_gap,
                      col_w=cw, col_h=ch,
                      mid_bw=mid_bw, mid_bh=mid_bh,
                      edge_bw=edge_bw, edge_bh=edge_bh,
                      align=args.align,
                      tag_prefix=args.prefix or "KL",
                      label_style=args.label_style,
                      stirrup=args.stirrup, reinf=args.reinf, side=args.side,
                      with_leader=args.leader,
                      with_hrb400_note=not args.no_hrb400_note,
                      id_only=args.id_only,
                      clear_old=not args.keep)
        wait_quiescent(app)
        zoom_extents(app.ActiveDocument)
        log("DONE")
    except Exception as e:
        log("FAILED: %s %s" % (type(e).__name__, str(e)[:240]))
        log(traceback.format_exc())
    finally:
        try:
            with open(LOG_PATH, "w", encoding="utf-8") as f:
                f.write("\n".join(log_lines))
        except Exception:
            pass


if __name__ == "__main__":
    main()
