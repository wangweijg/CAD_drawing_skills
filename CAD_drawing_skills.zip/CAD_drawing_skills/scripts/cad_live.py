# -*- coding: utf-8 -*-
"""AutoCAD 实时制图基础库（基于 comtypes COM）。

供「轴网」「梁板平法」等实时画脚本复用，避免在多个脚本里重复写
连接、坐标包装、图层初始化等易错代码。

制图标准统一从 cad_standards.py 读取，保证【实时画】与【离线出 DXF】
两条链路的图层颜色/线宽/线型/字体/标注样式完全一致。

────────────────── 三个必踩的坑（已解决，勿回退）──────────────────
1. 【点坐标格式】所有几何点必须用 P() 包装成 VARIANT(double SAFEARRAY)。
   普通 Python 元组会被 comtypes 转成 VT_VARIANT 数组，AutoCAD 一律
   报「参数错误」(E_INVALIDARG)。

2. 【权限必须同级】CAD 与本脚本的进程完整性级别(IL)必须一致，否则
   GetActiveObject 报 0x800401E3「操作无法使用」。
   常见陷阱：注册表 HKCU\\...\\AppCompatFlags\\Layers 里 acad.exe 被打了
   RUNASADMIN 标记（多为当初跑 /regserver 留下），导致 CAD 总是偷偷提权。
   日常用 CAD 并不需要管理员，删掉该标记即可两边对齐。

3. 【清理要单实体隔离】遍历删除时，个别实体（如中文注写）可能触发
   comtypes 的 mbcs 解码异常；若整个循环共用一个 try，会中途崩掉导致
   新旧图元叠加。见 clear_layer()。
──────────────────────────────────────────────────────────────
"""
import os
import sys
import time
import array
import comtypes.client as cc
from comtypes.automation import VARIANT

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cad_standards as STD

# 绿色版 AutoCAD 只注册了版本化 ProgID，这里按优先级依次尝试
PROGIDS = [
    "AutoCAD.Application.22",                       # 版本化名称（本机实际注册）
    "AutoCAD.Application",                          # 通用名称
    "{9AAF0EB6-42D8-46C1-A2EF-679511B37A0D}",       # 直接用 CLSID
]


def wait_quiescent(app, timeout=15.0):
    """等待 AutoCAD 空闲（命令队列执行完），避免紧接的 COM 调用被拒绝。"""
    end = time.time() + timeout
    try:
        st = app.GetAcadState()
    except Exception:
        time.sleep(1.0)
        return
    while time.time() < end:
        try:
            if bool(st.IsQuiescent):
                return
        except Exception:
            pass
        time.sleep(0.2)


def connect():
    """连接【已打开】的 AutoCAD，返回 Application 对象。失败抛最后一个异常。

    若报 0x800401E3，多半是权限不同级，见文件头注释第 2 条。
    """
    last = None
    for progid in PROGIDS:
        try:
            return cc.GetActiveObject(progid)
        except Exception as e:
            last = e
    raise last


def P(x, y, z=0.0):
    """将点 (x,y[,z]) 包装为 AutoCAD COM 需要的 VARIANT(double SAFEARRAY)。"""
    v = VARIANT()
    v.value = array.array("d", [float(x), float(y), float(z)])
    return v


def Pn(coords):
    """将一串坐标包装成 VARIANT(double SAFEARRAY)。

    用于 AddLightWeightPolyline（要求扁平的 2D 序列 x1,y1,x2,y2,...）
    与 Add3DPoly（3D 序列）。
    """
    v = VARIANT()
    v.value = array.array("d", [float(c) for c in coords])
    return v


def add_rect(msp, cx, cy, w, h, layer=None, closed=True):
    """以 (cx,cy) 为中心画矩形闭合多段线，返回多段线对象。"""
    a, b = w / 2.0, h / 2.0
    coords = [cx - a, cy - b, cx + a, cy - b, cx + a, cy + b, cx - a, cy + b]
    pl = msp.AddLightWeightPolyline(Pn(coords))
    if closed:
        try:
            pl.Closed = True
        except Exception:
            pass
    if layer:
        pl.Layer = layer
    return pl


def add_solid_fill(msp, cx, cy, w, h, layer=None):
    """矩形实心填充，返回 2D SOLID 实体（AcDbSolid）。

    ⚠️ 不要用 AddHatch + AppendOuterLoop：AutoCAD 要求 VT_ARRAY|VT_DISPATCH
       的实体数组，comtypes 无论传 list / tuple / VARIANT / _midlSAFEARRAY
       都会被 CAD 判为「对象数组无效」(-2145320837)。实测四种写法全部失败。
       2D SOLID 是结构图柱截面涂黑的经典做法，更轻量且 COM 调用稳定。

    AddSolid 的点序是【Z 字形】：p1=左下 p2=右下 p3=左上 p4=右上
    （即 p1-p2 一条边、p3-p4 一条边，若按顺时针传会画出蝴蝶结形状）。
    """
    a, b = w / 2.0, h / 2.0
    s = msp.AddSolid(P(cx - a, cy - b), P(cx + a, cy - b),
                     P(cx - a, cy + b), P(cx + a, cy + b))
    if layer:
        s.Layer = layer
    return s


# ============================================================
# 标准同步：把 cad_standards 的图层/字体/标注样式建进实时 CAD
# ============================================================
_LIN_CACHE = None
_STD_SYNCED = {}  # id(doc) -> True: 同一进程内已全量同步过的文档（合并脚本只同步一次）


def find_lin_files(doc=None):
    """定位可用的线型定义文件 acad.lin / acadiso.lin，返回候选路径列表。

    ⚠️ 绿色版 AutoCAD 的「支持文件搜索路径」常是坏的，直接用裸文件名
       Load("DOT", "acad.lin") 会报「文件系统错误」，必须给完整路径。
    """
    global _LIN_CACHE
    if _LIN_CACHE is not None:
        return _LIN_CACHE

    cands = ["acad.lin", "acadiso.lin"]      # 正常安装时裸名可用，优先试
    dirs = []

    # ① CAD 自身声明的支持文件搜索路径
    if doc is not None:
        try:
            sp = str(doc.Application.Preferences.Files.SupportPath)
            dirs += [p.strip() for p in sp.split(";") if p.strip()]
        except Exception:
            pass
        # ② CAD 安装目录
        try:
            dirs.append(os.path.dirname(str(doc.Application.FullName)))
        except Exception:
            pass

    # ③ 用户漫游配置目录（绿色版实际存放位置）
    roam = os.environ.get("APPDATA")
    if roam:
        import glob
        dirs += glob.glob(os.path.join(roam, "Autodesk", "AutoCAD*",
                                       "*", "*", "Support"))

    seen = set()
    for d in dirs:
        for fn in ("acad.lin", "acadiso.lin"):
            p = os.path.join(d, fn)
            key = p.lower()
            if key not in seen and os.path.isfile(p):
                seen.add(key)
                cands.append(p)

    _LIN_CACHE = cands
    return cands


def load_linetypes(doc, names=None):
    """从 acad.lin 载入所需线型。返回成功可用的线型名列表。

    线型未载入时给图层赋 Linetype 会失败（图层静默退化成实线），
    所以必须在建图层【之前】先载入。
    """
    names = names or STD.REQUIRED_LINETYPES
    sources = find_lin_files(doc)
    done = []
    for lt in names:
        try:
            doc.Linetypes.Item(lt)      # 已存在，无需加载
            done.append(lt)
            continue
        except Exception:
            pass
        for src in sources:
            try:
                doc.Linetypes.Load(lt, src)
                done.append(lt)
                break
            except Exception:
                continue
    return done


def ensure_layers(doc, only=None):
    """按标准建立图层并设置 颜色 / 线宽 / 线型。

    only: 只处理指定图层名集合（None = 全部 27 层）。
    返回 (处理数, 失败明细list)。
    """
    load_linetypes(doc)
    names = list(STD.LAYERS.keys()) if only is None else list(only)
    n, errs = 0, []
    for name in names:
        color, lw, lt = STD.layer_props(name)
        try:
            try:
                lay = doc.Layers.Add(name)
            except Exception:
                lay = doc.Layers.Item(name)
            try:
                lay.Color = int(color)
            except Exception as e:
                errs.append("%s.Color: %s" % (name, e))
            # AutoCAD 的 acLineWeight 枚举值恰好等于 0.01mm 数值(15/20/30/40)
            try:
                lay.Lineweight = int(lw)
            except Exception as e:
                errs.append("%s.Lineweight: %s" % (name, e))
            try:
                lay.Linetype = lt
            except Exception as e:
                errs.append("%s.Linetype(%s): %s" % (name, lt, e))
            n += 1
        except Exception as e:
            errs.append("%s: %s" % (name, e))
    return n, errs


def ensure_text_styles(doc):
    """按标准建立文字样式（Standard=GBENOR+GBCBIG，AXIS=txt.shx）。"""
    done, errs = [], []
    for sname, (font, bigfont, _d) in STD.TEXT_STYLES.items():
        try:
            try:
                st = doc.TextStyles.Item(sname)
            except Exception:
                st = doc.TextStyles.Add(sname)
            for attr in ("fontFile", "FontFile"):
                try:
                    setattr(st, attr, font)
                    break
                except Exception:
                    continue
            if bigfont:
                for attr in ("BigFontFile", "bigFontFile"):
                    try:
                        setattr(st, attr, bigfont)
                        break
                    except Exception:
                        continue
            # 高度必须为 0，否则 AddText 的 height 参数会被样式固定高度覆盖
            try:
                st.Height = 0
            except Exception:
                pass
            done.append(sname)
        except Exception as e:
            errs.append("%s: %s" % (sname, e))
    return done, errs


def ensure_dimstyle(doc, activate=True):
    """建立 DIM100 标注样式（1:100 建筑斜线 + 绿线白字）。

    COM 无法逐项设置 DimStyle 的变量，只能先把系统变量写进【当前文档】，
    再用 DimStyle.CopyFrom(doc) 固化成样式——这是官方推荐做法。
    """
    errs = []
    varmap = {
        "DIMSCALE": STD.DIMSTYLE["dimscale"],
        "DIMTXT": STD.DIMSTYLE["dimtxt"],
        "DIMASZ": STD.DIMSTYLE["dimasz"],
        "DIMTSZ": STD.DIMSTYLE["dimtsz"],
        "DIMEXE": STD.DIMSTYLE["dimexe"],
        "DIMEXO": STD.DIMSTYLE["dimexo"],
        "DIMTAD": STD.DIMSTYLE["dimtad"],
        "DIMLFAC": STD.DIMSTYLE["dimlfac"],
        "DIMCLRD": STD.DIMSTYLE["dimclrd"],
        "DIMCLRE": STD.DIMSTYLE["dimclre"],
        "DIMCLRT": STD.DIMSTYLE["dimclrt"],
        "DIMTXSTY": STD.DIMSTYLE["dimtxsty"],
    }
    for k, v in varmap.items():
        try:
            doc.SetVariable(k, v)
        except Exception as e:
            errs.append("SetVariable %s: %s" % (k, e))
    try:
        try:
            ds = doc.DimStyles.Item(STD.DIMSTYLE_NAME)
        except Exception:
            ds = doc.DimStyles.Add(STD.DIMSTYLE_NAME)
        try:
            ds.CopyFrom(doc)        # 把当前 DIM* 变量固化进样式
        except Exception as e:
            errs.append("CopyFrom: %s" % e)
        if activate:
            try:
                doc.ActiveDimStyle = ds
            except Exception as e:
                errs.append("ActiveDimStyle: %s" % e)
        return ds, errs
    except Exception as e:
        errs.append("DimStyles: %s" % e)
        return None, errs


def ensure_standards(doc, layers=None, verbose=False):
    """一次性把全套制图标准同步进实时 CAD。

    幂等，可反复调用。返回汇总 dict，便于脚本打印/记日志。
    """
    # 合并脚本优化：同一进程内已全量同步过的文档，直接返回快速结果
    if layers is None and _STD_SYNCED.get(id(doc)):
        return {"linetypes": list(STD.REQUIRED_LINETYPES),
                "layers": len(STD.LAYERS),
                "styles": list(STD.TEXT_STYLES.keys()),
                "errors": []}
    try:
        doc.SetVariable("LTSCALE", STD.HEADER_VARS["$LTSCALE"])
    except Exception:
        pass
    try:
        doc.SetVariable("INSUNITS", STD.HEADER_VARS["$INSUNITS"])
    except Exception:
        pass

    lts = load_linetypes(doc)
    nlay, lerrs = ensure_layers(doc, only=layers)
    styles, serrs = ensure_text_styles(doc)
    _ds, derrs = ensure_dimstyle(doc)

    info = {
        "linetypes": lts,
        "layers": nlay,
        "styles": styles,
        "errors": lerrs + serrs + derrs,
    }
    if layers is None and not info["errors"]:
        _STD_SYNCED[id(doc)] = True
    if verbose:
        print("  标准同步：线型%s 图层%d 文字样式%s 标注样式%s"
              % (lts, nlay, styles, STD.DIMSTYLE_NAME))
        for e in info["errors"][:10]:
            print("    [warn] " + str(e))
    return info


# 向后兼容：老脚本里的 setup_layer(doc, name, color)
def setup_layer(doc, name, color=None):
    """[兼容保留] 建单个图层。color=None 时按标准取色，否则用显式色号。

    新代码请直接用 ensure_standards() / ensure_layers()。
    """
    if color is None:
        ensure_layers(doc, only=[name])
    else:
        load_linetypes(doc)
        try:
            lay = doc.Layers.Add(name)
        except Exception:
            lay = doc.Layers.Item(name)
        try:
            lay.Color = int(color)
        except Exception:
            pass
    try:
        return doc.Layers.Item(name)
    except Exception:
        return None


# ============================================================
# 清理
# ============================================================
def clear_layer(msp, name):
    """删除指定图层上的所有实体，避免重跑脚本时实体叠加。返回删除数量。

    优先用 AutoCAD 原生选择集按图层过滤（快且稳）；失败则退回按索引逐个
    遍历。**每个实体单独 try**，避免个别实体（如中文注写）触发 comtypes
    的 mbcs 解码异常时，整个清理流程被中断导致新旧图元叠加。
    """
    # --- 方案一：原生选择集按图层过滤 ---
    try:
        doc = msp.Document
        ss_name = "PY_CLEAR_SS"
        try:
            doc.SelectionSets.Item(ss_name).Delete()
        except Exception:
            pass
        ss = doc.SelectionSets.Add(ss_name)
        ftype = VARIANT()
        ftype.value = array.array("h", [8])       # DXF 组码 8 = 图层
        fdata = VARIANT()
        fdata.value = [str(name)]
        ss.Select(5, None, None, ftype, fdata)    # 5 = acSelectionSetAll
        n = int(ss.Count)
        if n:
            ss.Erase()
        ss.Delete()
        return n
    except Exception:
        pass

    # --- 方案二：按索引逐个遍历，单实体隔离 ---
    n = 0
    try:
        total = int(msp.Count)
    except Exception:
        return n
    for i in range(total - 1, -1, -1):            # 倒序删，避免索引位移
        try:
            e = msp.Item(i)
            if e.Layer == name:
                e.Delete()
                n += 1
        except Exception:
            continue
    return n


def clear_layers(msp, names):
    """批量清理多个图层，返回总删除数。"""
    total = 0
    for nm in names:
        try:
            total += clear_layer(msp, nm)
        except Exception:
            continue
    return total


# ============================================================
# 视图
# ============================================================
def zoom_extents(doc):
    """缩放到图形范围。优先用命令，失败则退回 Application.ZoomExtents。"""
    try:
        doc.Regen(True)
    except Exception:
        pass
    try:
        doc.SendCommand("_ZOOM _E\n")
        return True
    except Exception:
        pass
    try:
        doc.Application.ZoomExtents()
        return True
    except Exception:
        return False
