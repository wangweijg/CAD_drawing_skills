# -*- coding: utf-8 -*-
"""在【已打开的 AutoCAD】里绘制楼板钢筋（实时 COM 制图）。

严格遵循 cad_standards.py：
    板底筋     -> S-FLOOR_DOWN_REIN   1   红 / 0.40 / Continuous
    板底筋注写 -> S-FLOOR_DOWN_TEXT   100 / 0.15 / Continuous
    板面筋     -> S-FLOOR_UP_REIN     13  青 / 0.15 / Continuous
    板上筋文字 -> S-FLOOR_UP_TEXT     7   白 / 0.15 / Continuous

默认在原点绘制；用 --offset-x / --offset-y 把板筋画到“副本”上
（与 cad_copy_drawing.py 配合出两张图：图1 梁平法 / 图2 板配筋）。

两种配筋模式（--mode）：
- mesh（默认，向后兼容）：底筋满布双向 @space，覆盖每个板跨（连续式）。
- separated（分离式配筋，22G101-1 有梁楼盖板构造）：
    * 底筋按板跨独立成段，两端停在梁内边面，中间支座处断开（不贯通邻跨）；
    * 在每条梁（支座）上方补画“支座负筋（面筋）”，向跨内延伸 --neg-ratio
      倍净跨（默认 ln/4）；端支座仅向跨内单侧延伸。

典型流程（分离式）：
  1) 画轴网+柱+梁(带编号)+A1图框          -> 图1（梁平法施工图）
  2) cad_copy_drawing.py --dx 100000       -> 复制出图2骨架
  3) cad_slab_rebar.py --mode separated --offset-x 100000
                                          -> 图2：删梁编号 + 分离式板配筋

用法：
  python cad_slab_rebar.py --x-spans 6 --x-gap 4000 --y-spans 2 --y-gap 7500
  python cad_slab_rebar.py --mode separated --offset-x 100000
  python cad_slab_rebar.py --mode separated --dia 8 --space 200 --top-dia 8 --top-space 200 --neg-ratio 0.25
"""
import os
import sys
import array
import traceback
import argparse

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cad_standards as STD
from cad_live import (connect, P, ensure_standards, zoom_extents)

SLAB_BAR_LAYER = "S-FLOOR_DOWN_REIN"
SLAB_TXT_LAYER = "S-FLOOR_DOWN_TEXT"
SLAB_TOP_LAYER = "S-FLOOR_UP_REIN"
SLAB_TOP_TXT_LAYER = "S-FLOOR_UP_TEXT"
BEAM_TEXT_LAYER = "S-BEAM_TEXT"

log_lines = []


def log(msg):
    log_lines.append(str(msg))
    print(msg)
    sys.stdout.flush()


def beam_edges(axis, is_lo, is_hi, bw, col_hw, align):
    """返回梁两条边线（沿其横截面方向）相对坐标 (e1, e2)，e1 < e2。

    与 cad_draw_beams.beam_edges 同义：align=outer 时边梁外边线与柱外边齐。
    """
    if align == "outer" and is_lo:
        out = axis - col_hw
        return (out, out + bw)
    if align == "outer" and is_hi:
        out = axis + col_hw
        return (out - bw, out)
    return (axis - bw / 2.0, axis + bw / 2.0)


def add_line(msp, x1, y1, x2, y2, layer):
    ln = msp.AddLine(P(x1, y1, 0.0), P(x2, y2, 0.0))
    try:
        ln.Layer = layer
    except Exception:
        pass
    return ln


def add_text(msp, txt, x, y, h, layer, align="left"):
    t = msp.AddText(str(txt), P(x, y, 0.0), h)
    try:
        t.Layer = layer
    except Exception:
        pass
    try:
        t.StyleName = "Standard"
    except Exception:
        pass
    try:
        t.Height = h
    except Exception:
        pass
    if align == "center":
        try:
            t.Alignment = 4           # acAlignmentMiddleCenter
            t.TextAlignmentPoint = P(x, y, 0.0)
        except Exception:
            pass
    return t


def erase_beam_text_in_region(doc, msp, x0, y0, x1, y1):
    """用选择集（窗交 + 图层过滤）删除区域内 S-BEAM_TEXT 实体，返回删除数。"""
    try:
        ss_name = "PY_SLAB_ERASE"
        try:
            doc.SelectionSets.Item(ss_name).Delete()
        except Exception:
            pass
        ss = doc.SelectionSets.Add(ss_name)
        ftype = array.array("h", [8])          # DXF 组码 8 = 图层
        fdata = [str(BEAM_TEXT_LAYER)]
        # 1 = acSelectionSetCrossing（窗交，覆盖区域内及压线实体）
        ss.Select(1, P(x0, y0, 0.0), P(x1, y1, 0.0),
                  ftype, fdata)
        n = int(ss.Count)
        if n:
            ss.Erase()
        ss.Delete()
        return n
    except Exception as e:
        log("  [warn] 区域删梁编号跳过: %s" % e)
        return 0


def clear_rebar_in_region(doc, msp, layers, x0, y0, x1, y1):
    """窗交 + 多图层过滤，删除副本地区旧板筋（重画分离式前用）。返回删除数。"""
    total = 0
    for idx, layer in enumerate(layers):
        try:
            ss_name = "PY_SLAB_CLR_%d" % idx
            try:
                doc.SelectionSets.Item(ss_name).Delete()
            except Exception:
                pass
            ss = doc.SelectionSets.Add(ss_name)
            ftype = array.array("h", [8])
            fdata = [str(layer)]
            ss.Select(1, P(x0, y0, 0.0), P(x1, y1, 0.0), ftype, fdata)
            n = int(ss.Count)
            if n:
                ss.Erase()
            ss.Delete()
            total += n
        except Exception as e:
            log("  [warn] 清层 %s 跳过: %s" % (layer, e))
    return total


def in_column(x, y, xs, ys, col_hw, ox, oy):
    """判断点 (x,y) 是否落在某根柱范围内（负筋在此处应断开）。"""
    for xc in xs:
        if abs(x - (xc + ox)) <= col_hw:
            for yc in ys:
                if abs(y - (yc + oy)) <= col_hw:
                    return True
    return False


def draw_slab_rebar(app, *, x_spans, x_gap, y_spans, y_gap,
                    col_size=500.0, beam_b=250.0,
                    dia=8.0, space=200.0, grade="三级(HRB400)", thick=120.0,
                    mode="mesh",
                    top_dia=8.0, top_space=200.0, top_grade="三级(HRB400)",
                    neg_ratio=0.25, edge_top=True,
                    offset_x=0.0, offset_y=0.0,
                    erase_beam_text=True, clear_old=True):
    doc = app.ActiveDocument
    msp = doc.ModelSpace
    ox, oy = offset_x, offset_y

    info = ensure_standards(doc, verbose=True)
    for e in info["errors"][:8]:
        log("    [warn] %s" % e)

    ok = 0
    fail = 0
    errs = []

    def safe(fn, label):
        nonlocal ok, fail
        try:
            fn()
            ok += 1
        except Exception as e:
            fail += 1
            errs.append("%s: %s %s" % (label, type(e).__name__, str(e)[:160]))

    # ---------- 轴网坐标 & 板范围 ----------
    col_hw = float(col_size) / 2.0
    bw = float(beam_b)
    xs = [i * x_gap for i in range(x_spans + 1)]
    ys = [j * y_gap for j in range(y_spans + 1)]

    xedges = [beam_edges(x, i == 0, i == len(xs) - 1, bw, col_hw, "outer")
              for i, x in enumerate(xs)]
    yedges = [beam_edges(y, j == 0, j == len(ys) - 1, bw, col_hw, "outer")
              for j, y in enumerate(ys)]

    fx0 = (xs[0] - col_hw) + ox
    fx1 = (xs[-1] + col_hw) + ox
    fy0 = (ys[0] - col_hw) + oy
    fy1 = (ys[-1] + col_hw) + oy

    # 板净区边界（梁内边面围成，底筋/负筋分布用）
    def bx(i):
        return (xedges[i][1] + ox, xedges[i + 1][0] + ox)

    def by_(j):
        return (yedges[j][1] + oy, yedges[j + 1][0] + oy)

    # ---------- 删副本地区梁编号 ----------
    if erase_beam_text and (abs(ox) > 1 or abs(oy) > 1):
        x0, y0 = fx0 - 3000.0, fy0 - 3000.0
        x1, y1 = fx1 + 3000.0, fy1 + 3000.0
        n = erase_beam_text_in_region(doc, msp, x0, y0, x1, y1)
        if n:
            log("  已删除副本梁编号 %d 个（S-BEAM_TEXT）" % n)

    eps = 1e-6
    bars = 0
    neg = 0

    if mode == "mesh":
        # ---------- mesh 模式：满布双向底筋（连续式）----------
        for i in range(x_spans):
            lx = xedges[i][1] if i > 0 else (xs[0] - col_hw)
            rx = xedges[i + 1][0] if i < x_spans - 1 else (xs[-1] + col_hw)
            lx += ox
            rx += ox
            for j in range(y_spans):
                by = yedges[j][1] if j > 0 else (ys[0] - col_hw)
                ty = yedges[j + 1][0] if j < y_spans - 1 else (ys[-1] + col_hw)
                by += oy
                ty += oy
                if rx - lx < space or ty - by < space:
                    continue
                y = by + space
                while y <= ty - eps:
                    safe(lambda x1=lx, x2=rx, y=y: add_line(msp, x1, y, x2, y,
                                                            SLAB_BAR_LAYER),
                         "Xbar")
                    bars += 1
                    y += space
                x = lx + space
                while x <= rx - eps:
                    safe(lambda y1=by, y2=ty, x=x: add_line(msp, x, y1, x, y2,
                                                            SLAB_BAR_LAYER),
                         "Ybar")
                    bars += 1
                    x += space
    else:
        # ---------- separated 模式：分离式配筋（22G101）----------
        # 0) 清副本旧板筋（避免与 mesh 旧图叠加）
        if clear_old and (abs(ox) > 1 or abs(oy) > 1):
            x0, y0 = fx0 - 3000.0, fy0 - 3000.0
            x1, y1 = fx1 + 3000.0, fy1 + 3000.0
            cl = clear_rebar_in_region(
                doc, msp,
                [SLAB_BAR_LAYER, SLAB_TXT_LAYER, SLAB_TOP_LAYER,
                 SLAB_TOP_TXT_LAYER],
                x0, y0, x1, y1)
            if cl:
                log("  已清理副本旧板筋 %d 个" % cl)

        # 1) 底筋：每跨独立，两端停在梁内边面，中间支座断开
        for i in range(x_spans):
            lx, rx = bx(i)
            for j in range(y_spans):
                by, ty = by_(j)
                if rx - lx < space or ty - by < space:
                    continue
                y = by + space
                while y <= ty - eps:
                    safe(lambda x1=lx, x2=rx, y=y: add_line(msp, x1, y, x2, y,
                                                            SLAB_BAR_LAYER),
                         "Xbar")
                    bars += 1
                    y += space
                x = lx + space
                while x <= rx - eps:
                    safe(lambda y1=by, y2=ty, x=x: add_line(msp, x, y1, x, y2,
                                                            SLAB_BAR_LAYER),
                         "Ybar")
                    bars += 1
                    x += space

        # 2) 支座负筋（面筋）：梁上方，向跨内延伸 neg_ratio*ln
        # 2a) 水平梁 y=ys[j] -> 竖向短筋（沿 Y）
        for j in range(y_spans + 1):
            yc = ys[j] + oy
            down = neg_ratio * y_gap if j < y_spans else 0.0
            up = neg_ratio * y_gap if j > 0 else 0.0
            if down == 0.0 and up == 0.0:
                continue
            for i in range(x_spans):
                lx, rx = bx(i)
                x = lx + space
                while x <= rx - eps:
                    if in_column(x, yc, xs, ys, col_hw, ox, oy):
                        x += space
                        continue
                    safe(lambda xx=x, a=yc - down, b=yc + up:
                         add_line(msp, xx, a, xx, b, SLAB_TOP_LAYER), "negH")
                    neg += 1
                    x += space
        # 2b) 竖直梁 x=xs[i] -> 水平短筋（沿 X）
        for i in range(x_spans + 1):
            xc = xs[i] + ox
            right = neg_ratio * x_gap if i < x_spans else 0.0
            left = neg_ratio * x_gap if i > 0 else 0.0
            if left == 0.0 and right == 0.0:
                continue
            for j in range(y_spans):
                by, ty = by_(j)
                y = by + space
                while y <= ty - eps:
                    if in_column(xc, y, xs, ys, col_hw, ox, oy):
                        y += space
                        continue
                    safe(lambda yy=y, a=xc - left, b=xc + right:
                         add_line(msp, a, yy, b, yy, SLAB_TOP_LAYER), "negV")
                    neg += 1
                    y += space

    # ---------- 注写 ----------
    th = 260.0
    note_x = (fx0 + fx1) / 2.0
    note_y = fy0 - 1500.0
    if mode == "mesh":
        label_main = "板底筋(双向): %s \u03c6%g@%g" % (grade, dia, space)
        label_thick = "板厚 h=%g" % thick
        safe(lambda: add_text(msp, label_main, note_x, note_y + th * 1.4,
                              th, SLAB_TXT_LAYER, align="center"), "note-main")
        safe(lambda: add_text(msp, label_thick, note_x, note_y,
                              th, SLAB_TXT_LAYER, align="center"), "note-thick")
    else:
        label_down = "板底筋(分离式,双向): %s \u03c6%g@%g" % (grade, dia, space)
        label_up = "支座负筋(双向): %s \u03c6%g@%g  延伸 ln/4" % (
            top_grade, top_dia, top_space)
        label_thick = "板厚 h=%g  （22G101 分离式配筋）" % thick
        safe(lambda: add_text(msp, label_down, note_x, note_y + th * 2.8,
                              th, SLAB_TXT_LAYER, align="center"), "note-down")
        safe(lambda: add_text(msp, label_up, note_x, note_y + th * 1.4,
                              th, SLAB_TOP_TXT_LAYER, align="center"), "note-up")
        safe(lambda: add_text(msp, label_thick, note_x, note_y,
                              th, SLAB_TXT_LAYER, align="center"), "note-thick")

    zoom_extents(doc)

    log("  板范围 X[%.0f, %.0f] Y[%.0f, %.0f]  mode=%s" %
        (fx0, fx1, fy0, fy1, mode))
    if mode == "mesh":
        log("  底筋 %s \u03c6%g@%g 双向；板跨 %dx%d" %
            (grade, dia, space, x_spans, y_spans))
        log("  底筋线段 %d 段，成功 %d，失败 %d" % (bars, ok, fail))
    else:
        log("  底筋(分离式) \u03c6%g@%g 双向；支座负筋 \u03c6%g@%g 延伸%.0f%%ln" %
            (dia, space, top_dia, top_space, neg_ratio * 100))
        log("  底筋线段 %d + 支座负筋 %d，成功 %d，失败 %d" %
            (bars, neg, ok, fail))
    if errs:
        log("  失败明细：")
        for e in errs[:10]:
            log("    - " + e)
    try:
        log("  模型空间实体总数: %s" % msp.Count)
    except Exception:
        pass
    log("COM_LIVE_DRAW=OK" if fail == 0 else "COM_LIVE_DRAW=PARTIAL")
    return ok, fail


def main():
    ap = argparse.ArgumentParser(
        description="在已打开的 AutoCAD 上绘制楼板钢筋（mesh / separated）")
    ap.add_argument("--x-spans", type=int, default=6, help="X 向跨数")
    ap.add_argument("--x-gap", type=float, default=4000, help="X 向轴距")
    ap.add_argument("--y-spans", type=int, default=2, help="Y 向跨数")
    ap.add_argument("--y-gap", type=float, default=7500, help="Y 向轴距")
    ap.add_argument("--col-size", type=float, default=500, help="柱边长")
    ap.add_argument("--beam-b", type=float, default=250, help="梁宽 b")
    ap.add_argument("--mode", default="mesh", choices=["mesh", "separated"],
                    help="配筋模式: mesh=满布双向; separated=分离式(22G101)")
    ap.add_argument("--dia", type=float, default=8, help="底筋直径")
    ap.add_argument("--space", type=float, default=200, help="底筋间距")
    ap.add_argument("--grade", default="三级(HRB400)", help="底筋级别文字")
    ap.add_argument("--thick", type=float, default=120, help="板厚注写(mm)")
    ap.add_argument("--top-dia", type=float, default=8, help="面筋(负筋)直径")
    ap.add_argument("--top-space", type=float, default=200, help="面筋(负筋)间距")
    ap.add_argument("--top-grade", default="三级(HRB400)", help="面筋级别文字")
    ap.add_argument("--neg-ratio", type=float, default=0.25,
                    help="支座负筋跨内延伸比(默认0.25=ln/4)")
    ap.add_argument("--no-edge-top", dest="edge_top", action="store_false",
                    help="端支座不画负筋")
    ap.add_argument("--offset-x", type=float, default=0.0, help="整体X偏移(画到副本)")
    ap.add_argument("--offset-y", type=float, default=0.0, help="整体Y偏移")
    ap.add_argument("--erase-beam-text", action="store_true", default=True,
                    help="删副本地区梁编号(默认开)")
    ap.add_argument("--no-erase-beam-text", dest="erase_beam_text",
                    action="store_false", help="保留梁编号")
    args = ap.parse_args()

    try:
        log("连接 AutoCAD ...")
        app = connect()
        log("  已连接 -> %s %s" % (app.Application.Name, app.Version))
    except Exception as e:
        log("FAILED: 无法连接 AutoCAD: %s" % e)
        return

    try:
        draw_slab_rebar(app,
                        x_spans=args.x_spans, x_gap=args.x_gap,
                        y_spans=args.y_spans, y_gap=args.y_gap,
                        col_size=args.col_size, beam_b=args.beam_b,
                        mode=args.mode,
                        dia=args.dia, space=args.space, grade=args.grade,
                        thick=args.thick,
                        top_dia=args.top_dia, top_space=args.top_space,
                        top_grade=args.top_grade, neg_ratio=args.neg_ratio,
                        offset_x=args.offset_x, offset_y=args.offset_y,
                        erase_beam_text=args.erase_beam_text)
    except Exception:
        log("FAILED: 绘制异常")
        log(traceback.format_exc())
    finally:
        try:
            with open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                   "cad_slab_rebar.log"), "w",
                      encoding="utf-8") as f:
                f.write("\n".join(log_lines))
        except Exception:
            pass
    log("DONE")


if __name__ == "__main__":
    main()
