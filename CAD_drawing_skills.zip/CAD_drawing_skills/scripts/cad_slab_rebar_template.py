# -*- coding: utf-8 -*-
"""在已打开的 AutoCAD 里按 22G101 + 楼板_平面配筋 模板绘制楼板配筋。

模板式画法（对齐模板 楼板_平面配筋.dxf）：
  1) 板底筋【不画网格线】，只在板内注写：
       B1 h=120
       B:X%%1328@200
       Y%%1328@200
  2) 支座负筋（S-FLOOR_UP_REIN）：在每条梁支座的【每个板跨跨中】
     画一根短符号（4 顶点 POLYLINE：端点、端点、终点、终点），
     垂直于梁跨过梁中线：
       - 端支座：向跨内延伸 L（L=短跨/4 向上取整到毫米），梁外边面内侧收 30；
       - 中间支座：向两侧跨内各延伸 L（同 L）。
  3) 负筋注写（S-FLOOR_UP_TEXT，字高 300，TSSD_Rein 字体）：
       - 伸出长度数字放在符号端部外侧（竖直符号 r=90，水平符号 r=0）；
       - 配筋值放在符号起点内侧（仅中间水平梁支座注写，其余靠总说明
         「未注明板钢筋均为%%1328@200」收口）。
  4) 总说明（S-TEXT，字高 400）：未注明板钢筋均为%%1328@200,未注明板编号均为B1
  5) 轴网尺寸（S-DIM，仅副本区 offset 非零时画）：水平下/上排、竖直左/右排各两级
     尺寸（分跨 DIM1=1500 + 总尺寸 DIM2=2250），与 cad_draw_axis.py 同规格。

用法（副本 +100000，5x4500 + 2x6000，柱500 梁200）：
  python cad_slab_rebar_template.py --x-spans 5 --x-gap 4500 --y-spans 2 --y-gap 6000 --beam-b 200 --offset-x 100000
"""
import os
import sys
import array
import traceback
import argparse
import math

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cad_standards as STD
from cad_live import (connect, P, Pn, ensure_standards, zoom_extents)

SLAB_BAR_LAYER = "S-FLOOR_DOWN_REIN"
SLAB_TXT_LAYER = "S-FLOOR_DOWN_TEXT"
SLAB_TOP_LAYER = "S-FLOOR_UP_REIN"
SLAB_TOP_TXT_LAYER = "S-FLOOR_UP_TEXT"
NOTE_LAYER = "S-TEXT"
TXT_STYLE = "TSSD_Rein"          # tssdeng.shx 支持 %%132（HRB400 三级钢符号）
DIA = "%%1328"                    # 三级钢(HRB400) Φ8，不用 %%c

log_lines = []


def log(msg):
    log_lines.append(str(msg))
    print(msg)
    sys.stdout.flush()


def beam_edges(axis, is_lo, is_hi, bw, col_hw, align="outer"):
    """梁两条边线相对坐标 (e1,e2)，e1<e2；边梁外边与柱外边齐。"""
    if align == "outer" and is_lo:
        out = axis - col_hw
        return (out, out + bw)
    if align == "outer" and is_hi:
        out = axis + col_hw
        return (out - bw, out)
    return (axis - bw / 2.0, axis + bw / 2.0)


def add_text(msp, txt, x, y, h, layer, rotation=0.0, style=TXT_STYLE):
    t = msp.AddText(str(txt), P(x, y, 0.0), h)
    try:
        t.Layer = layer
    except Exception:
        pass
    try:
        t.StyleName = style
    except Exception:
        pass
    try:
        t.Height = h
    except Exception:
        pass
    if rotation:
        try:
            t.Rotation = rotation * 3.14159265 / 180.0
        except Exception:
            pass
    return t


def add_neg_symbol(msp, x1, y1, x2, y2):
    """负筋短符号：4 顶点 LWPolyline（P1,P1,P2,P2），对齐模板 POLYLINE。"""
    pl = msp.AddLightWeightPolyline(
        Pn([x1, y1, x1, y1, x2, y2, x2, y2]))
    try:
        pl.Layer = SLAB_TOP_LAYER
    except Exception:
        pass
    return pl


def clear_rebar_in_region(doc, msp, layers, x0, y0, x1, y1):
    """窗交 + 多图层过滤，删除区域内旧板筋/旧注写。返回删除数。"""
    total = 0
    for idx, layer in enumerate(layers):
        try:
            ss_name = "PY_SLAB_TMPL_%d" % idx
            try:
                doc.SelectionSets.Item(ss_name).Delete()
            except Exception:
                pass
            ss = doc.SelectionSets.Add(ss_name)
            ftype = array.array("h", [8])
            fdata = [str(layer)]
            ss.Select(1, P(x0, y0, 0.0), P(x1, y1, 0.0), ftype, fdata)
            n = int(ss.Count)
            if n:
                ss.Erase()
            ss.Delete()
            total += n
        except Exception as e:
            log("  [warn] 清层 %s 跳过: %s" % (layer, e))
    return total


def draw_slab_rebar_template(app, *, x_spans, x_gap, y_spans, y_gap,
                             col_size=500.0, beam_b=200.0,
                             dia=8.0, space=200.0, thick=120.0,
                             offset_x=0.0, offset_y=0.0,
                             clear_old=True, erase_beam_text=False,
                             dim_spans=True):
    doc = app.ActiveDocument
    msp = doc.ModelSpace
    ox, oy = offset_x, offset_y

    info = ensure_standards(doc, verbose=True)
    for e in info["errors"][:8]:
        log("    [warn] %s" % e)

    ok, fail = 0, 0
    errs = []

    def safe(fn, label):
        nonlocal ok, fail
        try:
            fn()
            ok += 1
        except Exception as e:
            fail += 1
            errs.append("%s: %s %s" % (label, type(e).__name__, str(e)[:160]))

    col_hw = float(col_size) / 2.0
    bw = float(beam_b)
    xs = [i * x_gap for i in range(x_spans + 1)]
    ys = [j * y_gap for j in range(y_spans + 1)]

    xedges = [beam_edges(x, i == 0, i == len(xs) - 1, bw, col_hw, "outer")
              for i, x in enumerate(xs)]
    yedges = [beam_edges(y, j == 0, j == len(ys) - 1, bw, col_hw, "outer")
              for j, y in enumerate(ys)]

    fx0 = (xs[0] - col_hw) + ox
    fx1 = (xs[-1] + col_hw) + ox
    fy0 = (ys[0] - col_hw) + oy
    fy1 = (ys[-1] + col_hw) + oy

    # ---------- 清旧板筋 ----------
    if clear_old:
        # y0 向下多留 7000：总说明 note 在板底边下方约 6230 处，需一并清理
        x0, y0 = fx0 - 3000.0, fy0 - 7000.0
        x1, y1 = fx1 + 3000.0, fy1 + 3000.0
        cl = clear_rebar_in_region(
            doc, msp,
            [SLAB_BAR_LAYER, SLAB_TXT_LAYER, SLAB_TOP_LAYER,
             SLAB_TOP_TXT_LAYER, NOTE_LAYER],
            x0, y0, x1, y1)
        if cl:
            log("  已清理副本旧板筋/注写 %d 个" % cl)

    # ---------- 支座负筋符号 + 注写 ----------
    # 负筋伸出长度 = 板短跨 1/4，向上取整到毫米整数（22G101 板支座负筋构造）
    # 从梁边（梁内边面）起算；本图短跨 4500 -> L = ceil(4500/4) = 1125
    short_span = min(x_gap, y_gap)
    L_EXT = float(math.ceil(short_span / 4.0))
    L_TOP = L_EXT                 # 上侧/中间跨负筋延伸长度
    L_BOT = L_EXT                 # 下侧负筋延伸长度（与上侧统一）
    L_LAB = "%d" % int(L_EXT)
    TX_H = 300.0
    n_sym = 0
    n_txt = 0

    # 1a) 水平梁 y=ys[j] -> 竖直符号（沿 Y 跨过梁）
    for j in range(y_spans + 1):
        e1, e2 = yedges[j]
        if j == 0:                       # 下边梁：跨内延伸 L_BOT，外边面收 30
            a = e1 + 30.0
            b = e2 + L_BOT
            lab = L_LAB
        elif j == y_spans:               # 上边梁：跨内延伸 L_TOP，外边面收 30
            a = e1 - L_TOP
            b = e2 - 30.0
            lab = L_LAB
        else:                            # 中间梁：两侧各延伸 L_TOP
            a = e1 - L_TOP
            b = e2 + L_TOP
            lab = L_LAB
        for i in range(x_spans):
            xc = (xs[i] + xs[i + 1]) / 2.0 + ox
            safe(lambda xc=xc, a=a + oy, b=b + oy:
                 add_neg_symbol(msp, xc, a, xc, b), "negH%d" % j)
            n_sym += 1
            mid = (a + b) / 2.0 + oy
            safe(lambda xc=xc, mid=mid, lab=lab:
                 add_text(msp, lab, xc + 388.0, mid, TX_H,
                          SLAB_TOP_TXT_LAYER, rotation=90.0), "lenH%d" % j)
            n_txt += 1
            if j != 0 and j != y_spans:  # 中间梁支座注写配筋值（内侧）
                spec = "%s@%g" % (DIA, space)
                safe(lambda xc=xc, mid=mid, spec=spec:
                     add_text(msp, spec, xc - 102.0, mid, TX_H,
                              SLAB_TOP_TXT_LAYER, rotation=90.0), "specH%d" % j)
                n_txt += 1

    # 1b) 竖直梁 x=xs[i] -> 水平符号（沿 X 跨过梁）
    for i in range(x_spans + 1):
        e1, e2 = xedges[i]
        for j in range(y_spans):
            yc = (ys[j] + ys[j + 1]) / 2.0 + oy
            if j == 0:
                L = L_BOT
                lab = L_LAB
            else:
                L = L_TOP
                lab = L_LAB
            if i == 0:                   # 左边梁
                a = e1 + 30.0
                b = e2 + L
            elif i == x_spans:           # 右边梁
                a = e1 - L
                b = e2 - 30.0
            else:                        # 中间梁
                a = e1 - L
                b = e2 + L
            safe(lambda a=a + ox, b=b + ox, yc=yc:
                 add_neg_symbol(msp, a, yc, b, yc), "negV%d" % i)
            n_sym += 1
            midx = (a + b) / 2.0 + ox
            safe(lambda midx=midx, yc=yc, lab=lab:
                 add_text(msp, lab, midx - 60.0, yc - 388.0, TX_H,
                          SLAB_TOP_TXT_LAYER, rotation=0.0), "lenV%d" % i)
            n_txt += 1

    # ---------- 板底筋注写（不画网格线，对齐模板） ----------
    # 模板：B1 h=120 / B:X%%1328@200 / Y%%1328@200，字高 300，
    #       放左下第一板跨内（距梁内边面 dx=1243, dy=1766，行距 350）
    x_panel0 = (xs[0] + col_hw) + ox        # 梁内边面 = 柱外边
    y_beam_inner0 = yedges[0][1] + oy       # 下边梁内边面
    tx = x_panel0 + 1243.0
    ty = y_beam_inner0 + 1766.0
    safe(lambda: add_text(msp, "B1 h=120", tx, ty, TX_H,
                          SLAB_TXT_LAYER), "down-wb")
    safe(lambda: add_text(msp, "B:X%s@%g" % (DIA, space), tx, ty - 350.0,
                          TX_H, SLAB_TXT_LAYER), "down-x")
    safe(lambda: add_text(msp, "Y%s@%g" % (DIA, space), tx + 287.0,
                          ty - 698.0, TX_H, SLAB_TXT_LAYER), "down-y")
    n_txt += 3

    # ---------- 总说明（对齐模板 S-TEXT，h=400） ----------
    note_x = (xs[0] - col_hw) + ox + 2859.0
    note_y = (ys[0] - col_hw) + oy - 6230.0
    note = "未注明板钢筋均为%s@%g,未注明板编号均为B1" % (DIA, space)
    safe(lambda: add_text(msp, note, note_x, note_y, 400.0, NOTE_LAYER),
         "note")
    n_txt += 1

    # ---------- 轴网尺寸标注（仅副本区 offset 非零时画，避免主图重复） ----------
    if dim_spans and (ox != 0.0 or oy != 0.0):
        d1, d2 = STD.DIM1, STD.DIM2
        xs_abs = [x + ox for x in xs]
        ys_abs = [y + oy for y in ys]

        # 先清副本区内旧尺寸：窗口按四排尺寸范围外扩（不碰主图 S-DIM）
        clear_rebar_in_region(doc, msp, ["S-DIM"],
                              xs_abs[0] - 4500.0, ys_abs[0] - 4500.0,
                              xs_abs[-1] + 4500.0, ys_abs[-1] + 4500.0)

        def add_dim(p1, p2, textpos, value):
            d = msp.AddDimAligned(p1, p2, textpos)
            d.Layer = "S-DIM"
            try:
                d.StyleName = STD.DIMSTYLE_NAME
            except Exception:
                pass
            try:
                d.TextOverride = str(int(round(value)))
            except Exception:
                pass
            return d

        def dim_run_h(base_y, sign, tag):
            for i in range(len(xs_abs) - 1):
                safe(lambda i=i: add_dim(P(xs_abs[i], base_y), P(xs_abs[i + 1], base_y),
                                         P((xs_abs[i] + xs_abs[i + 1]) / 2.0, base_y + sign * d1),
                                         xs_abs[i + 1] - xs_abs[i]),
                     "xdim %s %d" % (tag, i))
            if len(xs_abs) > 2:
                safe(lambda: add_dim(P(xs_abs[0], base_y), P(xs_abs[-1], base_y),
                                     P((xs_abs[0] + xs_abs[-1]) / 2.0, base_y + sign * d2),
                                     xs_abs[-1] - xs_abs[0]),
                     "xdim %s total" % tag)

        def dim_run_v(base_x, sign, tag):
            for j in range(len(ys_abs) - 1):
                safe(lambda j=j: add_dim(P(base_x, ys_abs[j]), P(base_x, ys_abs[j + 1]),
                                         P(base_x + sign * d1, (ys_abs[j] + ys_abs[j + 1]) / 2.0),
                                         ys_abs[j + 1] - ys_abs[j]),
                     "ydim %s %d" % (tag, j))
            if len(ys_abs) > 2:
                safe(lambda: add_dim(P(base_x, ys_abs[0]), P(base_x, ys_abs[-1]),
                                     P(base_x + sign * d2, (ys_abs[0] + ys_abs[-1]) / 2.0),
                                     ys_abs[-1] - ys_abs[0]),
                     "ydim %s total" % tag)

        dim_run_h(ys_abs[0], -1.0, "bot")
        dim_run_h(ys_abs[-1], +1.0, "top")
        dim_run_v(xs_abs[0], -1.0, "left")
        dim_run_v(xs_abs[-1], +1.0, "right")
        log("  轴网尺寸标注：水平下/上排各 %d 分跨+总尺寸，竖直左/右排各 %d 分跨+总尺寸" % (x_spans, y_spans))

    zoom_extents(doc)

    log("  板范围 X[%.0f, %.0f] Y[%.0f, %.0f]" % (fx0, fx1, fy0, fy1))
    log("  支座负筋符号 %d 个；注写 %d 条（底筋注写3 + 总说明1）" %
        (n_sym, n_txt))
    log("  负筋延伸：短跨 %g -> L=%g（短跨/4 向上取整，从梁边起算）" % (short_span, L_EXT))
    if errs:
        log("  失败明细：")
        for e in errs[:10]:
            log("    - " + e)
    try:
        log("  模型空间实体总数: %s" % msp.Count)
    except Exception:
        pass
    log("COM_LIVE_DRAW=OK" if fail == 0 else "COM_LIVE_DRAW=PARTIAL")
    return ok, fail


def main():
    ap = argparse.ArgumentParser(
        description="模板式楼板配筋（22G101 + 楼板_平面配筋 模板）")
    ap.add_argument("--x-spans", type=int, default=5, help="X 向跨数")
    ap.add_argument("--x-gap", type=float, default=4500, help="X 向轴距")
    ap.add_argument("--y-spans", type=int, default=2, help="Y 向跨数")
    ap.add_argument("--y-gap", type=float, default=6000, help="Y 向轴距")
    ap.add_argument("--col-size", type=float, default=500, help="柱边长")
    ap.add_argument("--beam-b", type=float, default=200, help="梁宽 b")
    ap.add_argument("--dia", type=float, default=8, help="钢筋直径")
    ap.add_argument("--space", type=float, default=200, help="钢筋间距")
    ap.add_argument("--thick", type=float, default=120, help="板厚注写")
    ap.add_argument("--offset-x", type=float, default=0.0, help="整体X偏移")
    ap.add_argument("--offset-y", type=float, default=0.0, help="整体Y偏移")
    ap.add_argument("--no-dim-spans", action="store_false", dest="dim_spans",
                    default=True, help="不画轴网尺寸（副本区默认画）")
    args = ap.parse_args()

    try:
        log("连接 AutoCAD ...")
        app = connect()
        log("  已连接 -> %s %s" % (app.Application.Name, app.Version))
    except Exception as e:
        log("FAILED: 无法连接 AutoCAD: %s" % e)
        return

    try:
        draw_slab_rebar_template(
            app,
            x_spans=args.x_spans, x_gap=args.x_gap,
            y_spans=args.y_spans, y_gap=args.y_gap,
            col_size=args.col_size, beam_b=args.beam_b,
            dia=args.dia, space=args.space, thick=args.thick,
            offset_x=args.offset_x, offset_y=args.offset_y,
            dim_spans=args.dim_spans)
    except Exception:
        log("FAILED: 绘制异常")
        log(traceback.format_exc())
    finally:
        try:
            with open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                   "cad_slab_rebar_template.log"), "w",
                      encoding="utf-8") as f:
                f.write("\n".join(log_lines))
        except Exception:
            pass
    log("DONE")


if __name__ == "__main__":
    main()
