﻿# -*- coding: utf-8 -*-
"""结构制图标准：唯一权威配置源（Single Source of Truth）。

本模块只放【数据 + 纯函数】，不 import ezdxf / comtypes，
因此可被两条链路同时复用而互不污染：

    离线链路  gen_dxf_*.py      --(apply_to_ezdxf)-->  DXF 文件
    实时链路  cad_live.py       --(ensure_standards)->  已打开的 AutoCAD

标准来源（交叉校验，见 SKILL.md「标准来源」）：
  1. 22G101-1/2/3 图集平法注写规则
  2. 真实 DXF 模板（图层/字体/标注）
  3. 王工项目偏好（明确要求时覆盖机构标准）

⚠️ 改标准只改这里。任何脚本里再写死一份图层色号/线宽，都会造成
   离线出图与实时出图不一致，属于必须避免的漂移。
"""

# ============================================================
# 钢筋默认等级（无特殊说明一律三级钢 HRB400 —— 王工 2026-08-12 确认）
# ------------------------------------------------------------
# 22G101 惯例：平面配筋不逐根写等级，图面以总说明收口；
# 配筋标注里的直径符号统一用 %%132（HRB400 三级钢符号，TSSD_Rein 字体渲染），
# 不用 %%c（一级钢 φ）；梁配筋标注见 cad_beam_label.py，柱详图见 cad_column_rebar.py。
REBAR_GRADE = "HRB400"
REBAR_GRADE_CN = "三级钢（HRB400）"
REBAR_GRADE_NOTE = "注：未注明钢筋均采用三级钢（HRB400）。"

# ============================================================
# 图层表
# ------------------------------------------------------------
# 字段：名称 -> (颜色ACI, 线宽, 线型, 用途)
# 线宽单位为 0.01mm（AutoCAD/ezdxf 约定）：15=0.15mm  20=0.20mm
#                                          30=0.30mm  40=0.40mm
# 线型优先用 AutoCAD 标准名（Continuous/DOT/DASHED/CENTER/...）；
# DOTE（天正点划线）非纯标准名，但已在本文件 apply_to_ezdxf 里显式注册定义，可安全使用。
# ============================================================
LAYERS = {
    # --- 轴网 ---
    "S-DOTE":             (253, 15, "DOTE",       "轴线点划线(真实模板 DOTE)"),
    "S-AXIS":             (3,   15, "Continuous", "轴号圆圈"),
    "S-AXIS_TEXT":        (7,   15, "Continuous", "轴号文字"),
    "AXIS":               (3,   15, "Continuous", "轴号圆圈（天正TCH/模板）"),
    "AXIS_TEXT":          (7,   15, "Continuous", "轴号文字（天正TCH/模板）"),
    # --- 尺寸 ---
    "S-DIM":              (3,   15, "Continuous", "尺寸标注线/界线"),
    "S-DIM_SYMB":         (3,   15, "Continuous", "尺寸符号"),
    # 以下对齐真实样图「图面必备元素」标注层（R2018 样图实测）
    "S-DIM_ELEV":         (3,   15, "Continuous", "标高标注"),
    "S-DIM_COOR":         (3,   15, "Continuous", "坐标标注"),
    "S-DIM_IDEN":         (3,   15, "Continuous", "索引符号标注"),
    "S-DIM_LEAD":         (3,   15, "Continuous", "引线标注"),
    # --- 柱 ---
    "S-COLU":             (6,   30, "Continuous", "柱轮廓"),
    "S-COLU_HATCH":       (254, 15, "Continuous", "柱实心填充"),
    "S-COLU_NUM":         (7,   15, "Continuous", "柱编号"),
    "S-COLU_TEXT":        (7,   15, "Continuous", "柱文字说明"),
    "S-COLU_DIM":         (7,   15, "Continuous", "柱尺寸标注（平面柱截面尺寸）"),
    "S-COLU_TH":          (6,   15, "Continuous", "柱截面细线（梁板平面图/模板）"),
    # --- 柱详图（柱表）专用层，对齐王工 2026-08-06 模板 zhuzi.dxf ---
    # 模板 7 层：S-COLU_DE / S-REIN / S-TAB / S-TAB_TEXT / S-PUB_TEXT / S-COLU_DE_TEXT / S-DIM
    "S-COLU_DE":          (7,    0, "Continuous", "柱截面详图轮廓（闭合多段线，无宽度）"),
    "S-COLU_DE_TEXT":     (7,   15, "Continuous", "柱详图引出线+引出文字（角筋/边筋标注）"),
    "S-PUB_TEXT":         (7,   15, "Continuous", "表内公共文字（标高/纵筋/箍筋，h=300）"),
    # --- 梁 ---
    # ⚠️ SKILL.md 旧表把此层线型记作 "DASH"，但 acad.lin 中【没有】该名称
    #    （标准名是 DASHED）。引用未定义线型会让 CAD 拒绝加载整个图形，已修正。
    "S-BEAM":             (4,   15, "DASHED",     "梁中心线/示意（机构模板）"),
    "S-BEAM_CON":         (4,   20, "Continuous", "梁双线轮廓（王工偏好，实际出图用）"),
    "S-BEAM_ID":          (6,   15, "Continuous", "梁集中标注-梁号行（磁红，一眼定位该梁）"),
    "S-BEAM_TEXT":        (40,  15, "Continuous", "梁平法标注（旧单行，备用）"),
    "S-BEAM_REBAR":       (4,   15, "Continuous", "梁平法配筋集中标注（独立层，不与截面标注冲突）"),
    "S_BEAM":             (4,   15, "Continuous", "梁边线（天正TCH/模板）"),
    "S_SUBBEAMHOOP":      (1,   15, "Continuous", "次梁箍筋（天正TCH/模板）"),
    # --- 板 ---
    "S-FLOOR":            (191, 15, "Continuous", "板轮廓/洞口"),
    "S-FLOOR_NUM":        (7,   15, "Continuous", "板块编号"),
    "S-FLOOR_REIN":       (1,   30, "Continuous", "板支座上部非贯通纵筋"),
    "S-FLOOR_DOWN_REIN":  (1,   40, "Continuous", "板底筋"),
    "S-FLOOR_DOWN_TEXT":  (100, 15, "Continuous", "板贯通纵筋注写"),
    "S-FLOOR_UP_REIN":    (1,   30, "Continuous", "板面附加负筋（红色实心钢筋，对齐真实模板）"),
    "S-FLOOR_UP_TEXT":     (7,   15, "Continuous", "板上筋文字"),
    "S-FLOOR_TEXT":       (30,  15, "Continuous", "板支座钢筋注写"),
    # --- 填充（SKILL.md 记为 S-HATH(DEEP)/S-HATH(LIGHT)）---
    "S-HATH":             (254, 15, "Continuous", "深填充（降板/洞口）"),
    "S-HATH_LIGHT":       (252, 15, "Continuous", "浅填充"),
    # --- 配筋详图 ---
    "S-REIN":             (1,   30, "Continuous", "纵筋"),
    "S-STIRRUP":          (2,   15, "Continuous", "箍筋"),
    "S-DETAIL":           (7,   15, "Continuous", "详图轮廓/尺寸"),
    "S-DETAIL_TEXT":      (7,   15, "Continuous", "详图文字"),
    # --- 通用 ---
    "S-TEXT":             (7,   15, "Continuous", "文字说明"),
    "S-TAB":              (7,   15, "Continuous", "表格线"),
    "S-TAB_TEXT":         (7,   15, "Continuous", "表格文字"),
    "S-PUB_TITLE":        (4,   15, "Continuous", "图框线"),
    "S-FRAME":            (7,  100, "Continuous", "图框粗线（外框，实线加粗，GB/T 50001 粗实线）"),
    "S-DRAWING_NUMBER":   (6,   30, "Continuous", "图号"),
    # --- 剪力墙（22G101-1 第 10~12 章 / 3.2 剪力墙平法）---
    # 颜色对齐真实剪力墙图 Z-1101：S-WALL 黄色2（墙轮廓）、S-WALL_NUM 220（编号）
    "S-WALL":             (2,   30, "Continuous", "剪力墙墙身轮廓（双线，间距=墙厚）"),
    "S-WALL_HATCH":       (253, 15, "Continuous", "剪力墙实心填充"),
    "S-WALL_NUM":         (220, 15, "Continuous", "剪力墙编号/墙身节点编号"),
    "S-WALL_REIN":        (1,   30, "Continuous", "剪力墙身分布筋配筋（水平/竖向）"),
    "S-WALL_TEXT":        (40,  15, "Continuous", "剪力墙身配筋注写"),
    "S-WALL_EDGE":        (6,   15, "Continuous", "边缘构件（约束/构造边缘，暗柱/端柱）"),
    "S-COUP":             (4,   20, "Continuous", "连梁 LL 轮廓"),
    "S-COUP_TEXT":        (6,   15, "Continuous", "连梁平法注写"),
    # --- 基础/桩基（22G101-3）---
    "S-FOUND":            (3,   30, "Continuous", "基础轮廓（独立基础/条形基础/承台）"),
    "S-FOUND_HATCH":      (253, 15, "Continuous", "基础填充"),
    "S-FOUND_INNER":      (7,   15, "Continuous", "基础内柱位/变阶细线"),
    "S-FOUND_REIN":       (1,   30, "Continuous", "基础底板/承台配筋"),
    "S-FOUND_TEXT":       (7,   15, "Continuous", "基础编号注写（DJ/TJ/CT）"),
    "S-FOUND_DIM":        (7,   15, "Continuous", "基础尺寸标注"),
    "S-PILE":             (191, 15, "Continuous", "桩（桩位圆圈/桩身）"),
    "S-PILE_TEXT":        (7,   15, "Continuous", "桩位编号"),
    # --- 建筑（建施平面，对齐 TEST 样图）---
    "A-WALL":             (5,   25, "Continuous", "建筑墙身轮廓"),
    "A-WALL_HATCH":       (253, 15, "Continuous", "墙体填充"),
    "A-DOOR":             (2,   15, "Continuous", "门"),
    "A-WINDOW":           (2,   15, "Continuous", "窗"),
    "A-OPEN":             (4,   15, "Continuous", "洞口/楼梯/扶梯示意"),
    "A-TEXT":             (7,   15, "Continuous", "房间名称/建筑文字"),
    "A-FURN":             (8,   15, "Continuous", "家具/洁具布置"),
    # --- 真实工程补充层（模板反向校准 2026-09-04，取自 TEST 真实图用层）---
    "S-HOLE":             (11,  15, "Continuous", "洞口轮廓（真实工程）"),
    "S-HOLE_SHADE":       (254, 15, "Continuous", "洞口填充（真实工程）"),
    "S-PUB_DIM":          (3,   15, "Continuous", "公共尺寸标注（真实工程）"),
    "S-COM_DIM":          (212, 15, "Continuous", "综合尺寸标注（真实工程）"),
    "S-THIN":             (7,   15, "Continuous", "细线（真实工程）"),
    "S-SIGN":             (10,  15, "Continuous", "批注/签字标识（真实工程）"),
    "S-BEAM_WA":          (124, 15, "DASHED",     "梁中心/墙虚线（真实工程；线型用 DASHED 保证 CAD 可载）"),
    "PUB_TEXT":           (7,   15, "Continuous", "公共文字（真实工程）"),
    "H-图框":             (4,   15, "Continuous", "图框线（真实工程）"),
}

# 需要从 acad.lin 载入的非默认线型（Continuous 是内置的，无需加载）
REQUIRED_LINETYPES = sorted({v[2] for v in LAYERS.values()} - {"Continuous"})

# AutoCAD acad.lin 中确实存在的标准线型名。图层线型必须落在这个集合里，
# 否则 CAD 会因「线型未定义」拒绝加载整个 DXF。
VALID_LINETYPES = {
    "Continuous", "CENTER", "CENTER2", "CENTERX2",
    "DASHED", "DASHED2", "DASHEDX2", "DASHDOT", "DASHDOT2", "DASHDOTX2",
    "DIVIDE", "DIVIDE2", "DIVIDEX2", "DOT", "DOT2", "DOTX2",
    "PHANTOM", "PHANTOM2", "PHANTOMX2", "HIDDEN", "BORDER",
    "DOTE",  # 天正点划线：在 apply_to_ezdxf 里显式注册定义，非标准但有效
}


def validate():
    """自检图层表：线型名是否合法、线宽是否为 AutoCAD 允许值。

    返回问题列表，空列表 = 全部合规。CI/自测里可直接断言。
    """
    ok_lw = {0, 5, 9, 13, 15, 18, 20, 25, 30, 35, 40, 50, 53, 60,
             70, 80, 90, 100, 106, 120, 140, 158, 200, 211, -1, -2, -3}
    problems = []
    for name, (color, lw, lt, _d) in LAYERS.items():
        if lt not in VALID_LINETYPES:
            problems.append("%s: 线型 %r 非 AutoCAD 标准名" % (name, lt))
        if lw not in ok_lw:
            problems.append("%s: 线宽 %r 非法" % (name, lw))
        if not (0 <= color <= 256):
            problems.append("%s: 颜色 %r 越界" % (name, color))
    return problems


# ============================================================
# 文字样式
# ------------------------------------------------------------
# 只用 AutoCAD 自带国标 SHX，禁止第三方插件字体（天正/TSSD 等），
# 否则在别人机器上中文会显示成 ?。
# ============================================================
TEXT_STYLES = {
    # 样式名  -> (主字体, 大字体, 用途)
    "Standard": ("GBENOR", "GBCBIG", "通用国标 SHX（英文/数字/中文）"),
    "AXIS":     ("txt.shx", "",      "轴号数字/字母（纯 ASCII，最稳定）"),
    # TSSD 字体：支持 %%132（HRB400 钢筋符号 Φ）、%%130（HPB300 Ⅰ）、%%131（HRB335 Ⅱ）
    # 对齐模板 zhuzi.dxf，王工 2026-08-06 新增
    "TSSD_Dimension": ("tssdeng.shx", "gbcbig.shx", "TSSD 标注字体（含钢筋等级符号）"),
    "TSSD_Rein":      ("tssdeng.shx", "gbcbig.shx", "TSSD 配筋字体（含钢筋等级符号）"),
}


# ============================================================
# 标注样式 DIM100：1:100 建筑斜线
# ------------------------------------------------------------
# dimtsz=0.5 用建筑斜线代替箭头块，绕开绿色版 CAD 对 _ArchTick
# 内置块解析不稳定的问题。
# ============================================================
DIMSTYLE_NAME = "DIM100"
DIMSTYLE = {
    "dimscale": 100.0,   # 1:100 出图
    "dimtxt": 2.5,       # 打印字高 2.5mm
    "dimasz": 2.5,       # 箭头/斜线 2.5mm
    "dimtsz": 0.5,       # 建筑斜线端点（不依赖 _ArchTick 块）
    "dimblk": "",
    "dimblk1": "",
    "dimblk2": "",
    "dimexe": 1.5,       # 尺寸界线超出量
    "dimexo": 1.5,       # 尺寸界线偏移量
    "dimtad": 1,         # 文字位于尺寸线上方
    "dimlfac": 1.0,
    "dimclrd": 3,        # 尺寸线绿
    "dimclre": 3,        # 尺寸界线绿
    "dimclrt": 7,        # 尺寸文字白
    "dimtxsty": "Standard",
}


# ============================================================
# 图头变量
# ============================================================
HEADER_VARS = {
    "$DIMSCALE": 100.0,
    "$LTSCALE": 100.0,
    "$TEXTSIZE": 200.0,
    "$INSUNITS": 4,      # 毫米。ezdxf 默认 6(米)，会导致插图缩放错 1000 倍
}

DXF_VERSION = "AC1015"   # R2000，绿色版/精简版 AutoCAD 兼容性最好


# ============================================================
# 轴网几何标准（王工偏好，单位 mm）
# ------------------------------------------------------------
# 关键规范：轴线端点落在轴号圈【近端】，圈整体位于轴线外侧，
#           轴线不得穿过圆圈。
#
#   轴线端 ──┐
#            ●  轴号圈（圆心 = AXIS_CENTER）
#   |<--DIM1-->|                第一道尺寸（分跨）
#   |<----DIM2---->|            第二道尺寸（总尺寸）
#   |<--AXIS_ENDOFF-->|         轴线延伸终点 = DIM2 + 500
#   |<---AXIS_CENTER--->|       圈心 = 轴线终点 + 半径
# ============================================================
AXIS_R = 350.0             # 轴号圈半径
AXIS_H = 280.0             # 轴号文字高度
DIM1 = 1500.0              # 第一道尺寸线距轴线
DIM2 = DIM1 + 750.0        # 第二道尺寸线距轴线（=2250）
AXIS_ENDOFF = DIM2 + 500.0 # 轴线端点距轴网边界（=2750）
AXIS_CENTER = AXIS_ENDOFF + AXIS_R   # 轴号圈心距轴网边界（=3100）


def layer_color(name, default=7):
    """取图层颜色（ACI），未定义则返回 default。"""
    return LAYERS.get(name, (default,))[0]


def layer_props(name):
    """取图层完整属性 (color, lineweight, linetype)，未定义返回通用白细实线。"""
    v = LAYERS.get(name)
    return (v[0], v[1], v[2]) if v else (7, 15, "Continuous")


def axis_labels(n, prefix="", kind="number"):
    """生成 n 个轴号。

    kind='number' -> 1..n；kind='letter' -> A.. 且跳过易与 1/0 混淆的 I、O
    （《房屋建筑制图统一标准》GB/T 50001 规定 I、O、Z 不得用作轴号，
      此处按工程惯例至少跳过 I、O）。
    """
    out = []
    if kind == "letter":
        code = ord("A")
        while len(out) < n:
            ch = chr(code)
            if ch not in ("I", "O", "Z"):
                out.append(prefix + ch)
            code += 1
    else:
        for i in range(1, n + 1):
            out.append(prefix + str(i))
    return out


# ============================================================
# 离线链路：把标准应用到 ezdxf 文档
# ============================================================
def apply_to_ezdxf(doc):
    """在 ezdxf 文档上建立全部图层 / 文字样式 / 标注样式 / 图头变量。

    幂等：重复调用不会报错。返回新建图层数量。
    """
    # --- 线型定义（DOTE 点划线，照抄真实模板 轴线.dxf LTYPE 定义）---
    # 天正/DOTE 不是纯 AutoCAD 标准线型，必须在本 DXF 的 LTYPE 表里显式定义，
    # 否则 CAD 因「线型未定义」拒绝加载，且 setup_layers 会把图层降级为 Continuous。
    # 定义值来自真实模板：长段2.0 / 空0.2 / 短点0.02 / 空0.2。
    try:
        if "DOTE" not in {lt.dxf.name.upper() for lt in doc.linetypes}:
            doc.linetypes.add(
                "DOTE",
                description="____ . ____ . ____ . ____",
                pattern=[2.0, -0.2, 0.02, -0.2],
            )
    except Exception:
        pass

    for k, v in HEADER_VARS.items():
        try:
            doc.header[k] = v
        except Exception:
            pass

    # 文字样式
    for sname, (font, bigfont, _desc) in TEXT_STYLES.items():
        try:
            if sname in doc.styles:
                st = doc.styles.get(sname)
                st.dxf.font = font
                if bigfont:
                    st.dxf.bigfont = bigfont
            else:
                attrs = {"font": font}
                if bigfont:
                    attrs["bigfont"] = bigfont
                # 注意：styles.add() 不支持 bigfont，必须用 new(dxfattribs=...)
                doc.styles.new(sname, dxfattribs=attrs)
        except Exception:
            pass

    # 标注样式
    try:
        if DIMSTYLE_NAME not in doc.dimstyles:
            doc.dimstyles.new(DIMSTYLE_NAME, dxfattribs=dict(DIMSTYLE))
    except Exception:
        pass

    # 图层
    # 先取文档里【实际已定义】的线型集合。引用未定义线型会让 CAD 拒绝加载
    # 整个图形，所以这里必须校验后再赋值，缺失的一律降级为 Continuous。
    try:
        defined = {lt.dxf.name.upper() for lt in doc.linetypes}
    except Exception:
        defined = {"CONTINUOUS"}

    n = 0
    for name, (color, lw, lt, _desc) in LAYERS.items():
        use_lt = lt if lt.upper() in defined else "Continuous"
        try:
            if name not in doc.layers:
                doc.layers.add(name, color=color, lineweight=lw, linetype=use_lt)
                n += 1
        except Exception:
            try:
                if name not in doc.layers:
                    doc.layers.add(name, color=color, lineweight=lw)
                    n += 1
            except Exception:
                pass
    return n
