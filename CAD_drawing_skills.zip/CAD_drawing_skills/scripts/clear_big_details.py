# -*- coding: utf-8 -*-
"""清理配筋「大样图」图层上的实体（不重画）。

删除以下图层全部实体，使平面图回到「轴网 + 柱 + 梁截面标注」的干净状态：
  - KL5 梁配筋集中标注：S-BEAM_REBAR
  - KL5 梁剖面详图：     S-REIN / S-STIRRUP / S-DETAIL / S-DETAIL_TEXT
  - KZ1 柱截面详图：     S-COLU_DE_TH / S-COLU_DE_REIN / S-COLU_DE_STIRRUP
                         S-COLU_DE_DIM / S-COLU_DE_TEXT
"""
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cad_live import connect, clear_layers

LAYERS = [
    "S-BEAM_REBAR",
    "S-REIN", "S-STIRRUP", "S-DETAIL", "S-DETAIL_TEXT",
    "S-COLU_DE_TH", "S-COLU_DE_REIN", "S-COLU_DE_STIRRUP",
    "S-COLU_DE_DIM", "S-COLU_DE_TEXT",
]


def main():
    acad = connect()
    doc = acad.ActiveDocument
    msp = doc.ModelSpace
    n = clear_layers(msp, LAYERS)
    print("已清理大样图层实体: %d" % n)
    print("COM_CLEAN_DONE=OK")


if __name__ == "__main__":
    main()
