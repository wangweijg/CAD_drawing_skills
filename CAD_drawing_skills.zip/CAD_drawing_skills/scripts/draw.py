# -*- coding: utf-8 -*-
"""统一出图入口：按图种派发到对应离线生成器（ROADMAP#8）。

用法：
    python draw.py <图种> [--frame A1] [其余原样转发给生成器]

图种别名（支持中文/英文）：
    axis|轴网        -> gen_axis_grid.py
    col|柱表|柱详图  -> gen_column_detail.py
    wall|剪力墙      -> gen_wall_plan.py
    found|基础|桩基  -> gen_foundation.py
    stair|楼梯       -> gen_stair.py
    arch|建筑        -> gen_arch_plan.py
    frame|图框       -> gen_frame.py
    notes|总说明     -> gen_general_notes.py

--frame <A0-A4>：出完图种后再生成一张该幅面图框（标题由图种生成，通用标题栏）。

例：
    python draw.py 桩基 --x-gaps 8400,8400,8400 --y-gaps 8400,8400,8400,8400 --frame A1
    python draw.py 剪力墙
    python draw.py 总说明
"""
import argparse
import os
import subprocess
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

GENERATOR = {
    # 别名 -> (脚本, 输出文件前缀, 标题关键字)
    "axis":  ("gen_axis_grid.py",     "轴网",              "轴网平面图"),
    "col":   ("gen_column_detail.py", "柱表",              "柱表/柱详图"),
    "wall":  ("gen_wall_plan.py",     "剪力墙布置图",      "剪力墙平面布置图"),
    "found": ("gen_foundation.py",    "桩基平面布置图",    "桩基承台平面布置图"),
    "stair": ("gen_stair.py",         "楼梯平法施工图",    "楼梯平法施工图"),
    "arch":  ("gen_arch_plan.py",     "建筑平面图",        "建筑平面图"),
    "frame": ("gen_frame.py",         "图框",              "图框"),
    "notes": ("gen_general_notes.py", "结构设计总说明",    "结构设计总说明"),
}
ALIAS = {
    "axis": "axis", "轴网": "axis",
    "col": "col", "柱": "col", "柱表": "col", "柱详图": "col",
    "wall": "wall", "剪力墙": "wall", "墙": "wall",
    "found": "found", "基础": "found", "桩基": "found", "承台": "found",
    "stair": "stair", "楼梯": "stair",
    "arch": "arch", "建筑": "arch", "建筑平面": "arch",
    "frame": "frame", "图框": "frame",
    "notes": "notes", "总说明": "notes", "结总": "notes", "说明": "notes",
}
DEFAULT_FRAME_TITLE = "结构施工图"


def main():
    # 首个位置参数 = 图种；其余转发
    argv = sys.argv[1:]
    if not argv:
        print("用法: python draw.py <图种> [--frame A0-A4] [生成器参数...]")
        print("图种: axis / col / wall / found / stair / arch / frame / notes（或中文）")
        sys.exit(1)
    kind_raw = argv[0]
    kind = ALIAS.get(kind_raw, ALIAS.get(kind_raw.lower(), None))
    if kind is None:
        print("未知图种: %r。可用: %s" % (kind_raw, "/".join(sorted(ALIAS))))
        sys.exit(1)

    script, _prefix, title = GENERATOR[kind]
    here = os.path.dirname(os.path.abspath(__file__))
    script_path = os.path.join(here, script)

    # 解析 --frame（本入口处理，不转发）
    frame = None
    forward = []
    i = 1
    while i < len(argv):
        if argv[i] == "--frame" and i + 1 < len(argv):
            frame = argv[i + 1].upper()
            i += 2
        elif argv[i] == "--frame":
            frame = "A1"
            i += 1
        else:
            forward.append(argv[i])
            i += 1

    if not os.path.isfile(script_path):
        print("生成器不存在: %s" % script_path)
        sys.exit(1)

    print("[draw] 图种=%s -> %s %s" % (kind_raw, script, " ".join(forward)))
    rc = subprocess.call([sys.executable, script_path] + forward)
    if rc != 0:
        print("[draw] 生成器返回非零: %s" % rc)
        sys.exit(rc)

    # 出图框
    if frame:
        frame_script = os.path.join(here, "gen_frame.py")
        ftitle = DEFAULT_FRAME_TITLE if frame == "A1" else DEFAULT_FRAME_TITLE
        # 用图种标题作为图名（结构平面类用 title，总说明/图框用其自身）
        title_use = title if kind not in ("frame", "notes") else DEFAULT_FRAME_TITLE
        frc = subprocess.call([sys.executable, frame_script,
                               "--size", frame,
                               "--title", title_use,
                               "--drawno", "结施-01",
                               "--date", "2026.09.04",
                               "--designer", "王工"])
        if frc != 0:
            print("[draw] 图框生成失败: %s" % frc)
            sys.exit(frc)
        print("[draw] 已生成图框 %s（标题：%s）" % (frame, title_use))

    print("[draw] 完成。成品在 output/ 目录。")


if __name__ == "__main__":
    main()
