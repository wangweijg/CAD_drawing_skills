# -*- coding: utf-8 -*-
"""
把「结构标准层梁板平法施工图」实时画进【已打开的 AutoCAD】。

运行权限说明（重要）：
    CAD 与脚本必须处于【同一完整性级别(IL)】。最简单稳妥的做法是两者都用
    【普通用户】身份运行——即先移除 acad.exe 的 RUNASADMIN 兼容性标记
    （见 scripts/_fix_runasadmin.py），再正常双击/命令行打开 CAD 并运行本脚本。
    无需“以管理员身份运行”。若 CAD 因历史原因仍在提权，则本脚本也需提权，
    但推荐前者（双普通用户）。

两种模式：
  --mode stream （默认）
      复用 gen_dxf_6x2.py 的几何，把每个图元(LINE/CIRCLE/LWPOLYLINE/TEXT/
      HATCH边界/DIMENSION)逐个映射成 COM Add*，画进「当前活动文档」。
      与 cad_draw_axis.py 的轴网风格一致，所见即所得。
      局限：当前文档的 Standard 文字样式若不含中文字体，中文注写可能显示不全；
            尺寸/填充为尽力而为（已逐实体容错，单点失败不影响整体）。
  --mode open
      Documents.Open 生成的 DXF（新开一个文档）。中文/标注/填充 100% 保真，
      零映射风险，是「完美还原」的兜底方案。

日志写入同目录 dxf_to_cad.log。
"""
import sys
import os
import array
import traceback
import argparse
from comtypes.automation import VARIANT

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cad_standards as STD
from cad_live import (connect, P, setup_layer, clear_layer,
                      ensure_standards, load_linetypes, zoom_extents)

LOG_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "dxf_to_cad.log")

log_lines = []


def log(msg):
    log_lines.append(str(msg))
    print(msg)
    sys.stdout.flush()


# ---------- 多重点坐标（轻量多段线用） ----------
def Pn(coords):
    """把扁平坐标列表 [x1,y1,x2,y2,...] 包装为 AutoCAD COM 需要的
    VARIANT(double SAFEARRAY)。"""
    v = VARIANT()
    v.value = array.array("d", [float(c) for c in coords])
    return v


def recreate_layers(cad_doc, ezdoc):
    """在 CAD 活动文档里重建图层，完整保留 颜色 / 线宽 / 线型。

    两步走：
    1. ensure_standards() 先按 cad_standards 建全套标准图层（27 层）
       并同步文字样式与 DIM100 标注样式——这一步保证机构标准不丢；
    2. 再补建 DXF 里出现、但不在标准表内的图层，按其自身 DXF 属性还原。

    ⚠️ 旧版本只设 Color，导致 S-DOTE 的 DOT 点划线在推送后退化成实线、
       各层线宽全丢。此处必须同时设置 Lineweight 与 Linetype。
    """
    info = ensure_standards(cad_doc)
    log("  标准同步：图层 %d 个，线型 %s，文字样式 %s"
        % (info["layers"], info["linetypes"], info["styles"]))
    for e in info["errors"][:8]:
        log("    [warn] %s" % e)

    n = info["layers"]
    extra = []
    for lay in ezdoc.layers:
        name = lay.dxf.name
        if name in ("0", "DEFPOINTS") or name in STD.LAYERS:
            continue
        try:
            try:
                l = cad_doc.Layers.Add(name)
            except Exception:
                l = cad_doc.Layers.Item(name)
            try:
                l.Color = int(lay.dxf.color)
            except Exception:
                pass
            try:
                lw = int(getattr(lay.dxf, "lineweight", 15))
                if lw > 0:                      # -1/-2/-3 为随层/随块/默认
                    l.Lineweight = lw
            except Exception:
                pass
            try:
                lt = getattr(lay.dxf, "linetype", "Continuous")
                if lt and lt != "Continuous":
                    load_linetypes(cad_doc, [lt])
                l.Linetype = lt
            except Exception:
                pass
            extra.append(name)
            n += 1
        except Exception:
            continue
    if extra:
        log("  非标准图层补建 %d 个: %s" % (len(extra), ", ".join(extra[:10])))
    return n


def hatch_boundaries(e):
    """提取 HATCH 的边界多段线（仅 PolylinePath；EdgePath 圆弧暂跳过）。
    返回 [(coords, closed), ...]。"""
    out = []
    try:
        for path in e.paths:
            if hasattr(path, "vertices"):  # PolylinePath
                coords = []
                for v in path.vertices:
                    coords.extend([float(v[0]), float(v[1])])
                if len(coords) >= 4:
                    out.append((coords, True))
    except Exception:
        pass
    return out


def draw_entity(msp, e):
    """把单个 ezdxf 图元画进 CAD ModelSpace。抛异常由调用方捕获计数。"""
    dt = e.dxftype()
    layer = e.dxf.layer if "layer" in e.dxfattribs() else "0"

    if dt == "LINE":
        ln = msp.AddLine(P(e.dxf.start[0], e.dxf.start[1]),
                         P(e.dxf.end[0], e.dxf.end[1]))
        ln.Layer = layer

    elif dt == "CIRCLE":
        c = msp.AddCircle(P(e.dxf.center[0], e.dxf.center[1]), float(e.dxf.radius))
        c.Layer = layer

    elif dt == "LWPOLYLINE":
        pts = e.get_points()
        if len(pts) < 2:
            return
        coords = []
        for p in pts:
            coords.extend([float(p[0]), float(p[1])])
        pl = msp.AddLightWeightPolyline(Pn(coords))
        pl.Layer = layer
        if getattr(e, "closed", False):
            pl.Closed = True

    elif dt == "TEXT":
        txt = str(e.dxf.text)
        ins = e.dxf.insert
        h = float(e.dxf.height)
        t = msp.AddText(txt, P(ins[0], ins[1]), h)
        t.Layer = layer
        rot = e.dxf.rotation
        if rot:
            try:
                t.Rotation = float(rot)
            except Exception:
                pass

    elif dt == "HATCH":
        for coords, closed in hatch_boundaries(e):
            pl = msp.AddLightWeightPolyline(Pn(coords))
            pl.Layer = layer
            if closed:
                pl.Closed = True

    elif dt == "DIMENSION":
        # 对齐标注：defpoint(13)=起点, defpoint2(14)=终点, defpoint3(15)=标注线位置
        p1 = e.dxf.defpoint
        p2 = e.dxf.defpoint2
        pl = e.dxf.defpoint3
        dim = msp.AddDimAligned(P(p1[0], p1[1]), P(p2[0], p2[1]), P(pl[0], pl[1]))
        dim.Layer = layer
        try:
            dim.StyleName = "DIM100"
        except Exception:
            pass
        txt = getattr(e.dxf, "text", None)
        if txt:
            try:
                dim.TextOverride = str(txt)
            except Exception:
                pass

    else:
        # 其它类型（INSERT/BLOCK 等）本图未用，跳过
        raise NotImplementedError("未支持的图元类型: %s" % dt)


def stream_to_cad(app, ezdoc, clear_layer_name=None):
    """把 ezdxf 文档的 modelspace 流式画进 CAD 活动文档。"""
    doc = app.ActiveDocument
    msp = doc.ModelSpace

    nlay = recreate_layers(doc, ezdoc)
    log("  重建图层 %d 个（含 DIM100 样式）" % nlay)

    if clear_layer_name:
        try:
            old = clear_layer(msp, clear_layer_name)
            if old:
                log("  已清理旧 %s 实体 %d 个" % (clear_layer_name, old))
        except Exception as e:
            log("  [warn] 清理跳过: %s" % e)

    ok = 0
    fail = 0
    errs = {}
    for e in ezdoc.modelspace():
        dt = e.dxftype()
        try:
            draw_entity(msp, e)
            ok += 1
        except Exception as ex:
            fail += 1
            errs[dt] = errs.get(dt, 0) + 1
            if fail <= 12:  # 仅前若干条写明细，避免刷屏
                log("  [fail] %s: %s" % (dt, str(ex)[:140]))

    try:
        doc.Regen(True)
    except Exception:
        pass
    try:
        doc.SendCommand("_ZOOM _E\n")
    except Exception:
        pass

    log("  流式绘制完成：成功 %d，失败 %d" % (ok, fail))
    if errs:
        log("  失败类型分布：%s" % ", ".join("%s×%d" % (k, v) for k, v in errs.items()))
    log("COM_LIVE_DRAW=OK" if fail == 0 else "COM_LIVE_DRAW=PARTIAL")


def open_dxf(app, dxf_path):
    """Documents.Open 打开 DXF（新文档，保真）。"""
    doc = app.Documents.Open(os.path.abspath(dxf_path))
    try:
        doc.SendCommand("_ZOOM _E\n")
    except Exception:
        pass
    log("  已用 Documents.Open 打开: %s" % dxf_path)
    log("COM_LIVE_DRAW=OK")


def main():
    ap = argparse.ArgumentParser(description="把梁板平法施工图实时画进打开的 AutoCAD")
    ap.add_argument("--mode", choices=["stream", "open"], default="stream",
                    help="stream=画进当前文档(默认)；open=打开DXF新文档(保真)")
    ap.add_argument("--dxf", default=None, help="指定 DXF 路径（默认用内置 6x2 生成器）")
    ap.add_argument("--clear-layer", default=None,
                    help="stream 模式下先清空该图层旧实体（如 S-AXIS），避免叠加")
    args = ap.parse_args()

    # 取得 ezdxf 文档（与几何单一数据源）
    ezdoc = None
    dxf_path = args.dxf
    try:
        if dxf_path:
            import ezdxf
            ezdoc = ezdxf.readfile(dxf_path)
            log("读取 DXF: %s" % dxf_path)
        else:
            log("生成内置 6x2 施工图（复用 gen_dxf_6x2.py）...")
            import gen_dxf_6x2
            ezdoc = gen_dxf_6x2.doc
            dxf_path = gen_dxf_6x2.OUT
            log("  已生成并落盘: %s" % dxf_path)
    except Exception as e:
        log("FAILED: 获取几何失败: %s" % e)
        log(traceback.format_exc())
        return

    # 连接 CAD
    try:
        log("连接 AutoCAD ...")
        app = connect()
        log("  已连接 -> %s %s" % (app.Application.Name, app.Version))
    except Exception as e:
        log("FAILED: 无法连接 AutoCAD: %s" % e)
        log("  请确认：① CAD 已打开  ② COM 已注册(/regserver)")
        log("          ③ CAD 与本脚本权限级别一致（普通用户即可；若 CAD 被 RUNASADMIN 标记提权，")
        log("             运行 scripts/_fix_runasadmin.py 移除标记后两者都按普通用户运行）")
        return

    if args.mode == "open":
        open_dxf(app, dxf_path)
    else:
        stream_to_cad(app, ezdoc, clear_layer_name=args.clear_layer)
    log("DONE")


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        log("FAILED: %s %s" % (type(e).__name__, str(e)[:240]))
        log(traceback.format_exc())
    finally:
        try:
            with open(LOG_PATH, "w", encoding="utf-8") as f:
                f.write("\n".join(log_lines))
        except Exception:
            pass
