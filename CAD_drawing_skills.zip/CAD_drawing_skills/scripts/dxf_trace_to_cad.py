# -*- coding: utf-8 -*-
"""
dxf_trace_to_cad.py —— 把【任意已有 DXF】用「画图方式」逐实体描进已打开的 AutoCAD。

定位：与 dxf_to_cad.py 的区别
    dxf_to_cad.py     只认技能自带的样例几何（gen_dxf_6x2），用于离线生成器的成果推送；
    dxf_trace_to_cad.py  接受【任意 DXF 输入】，原样重画：不改坐标、不换图层、不动样式，
    相当于"照着源图用 CAD 命令描一遍"，用于 PDF/图纸转换成果的复核与验收。

原样还原到什么程度（不调整原则）：
    · 坐标        ：源图 WCS 坐标原样使用（可选 --offset 整体平移，默认 0,0 不平移）
    · 图层        ：按源 DXF 逐层重建（颜色 / 线型，线型缺失则退回 Continuous 并记录）
    · 文字样式    ：按源 DXF 重建（SHX 主字体 + 大字体；宋体/黑体等 TTF 自动映射）
    · 标注样式    ：源 DIMENSION 用到的样式按参数重建（DIMSCALE/TXT/ASZ/EXE/EXO/TAD…）
    · 文字        ：内容、字高、旋转、对齐方式、宽度因子（ScaleWidth）全保留
    · 多段线      ：凸度（弧段）、闭合标志、等宽/变宽全保留
    · 块          ：块定义重建后原位插入（含块内 LINE/TEXT 的对齐与宽度因子）
    · 标注        ：按 defpoint2/defpoint3 + defpoint + angle 重新生成（线性/对齐/角度/半径/直径）

用法：
    python dxf_trace_to_cad.py <输入.dxf>                          # 只画，不存盘（冒烟自检）
    python dxf_trace_to_cad.py <输入.dxf> --save-as "J:\\out\\a.dwg"  # 画完另存
    python dxf_trace_to_cad.py <输入.dxf> --current                # 画进当前活动文档（不新建）
    python dxf_trace_to_cad.py <输入.dxf> --dry-run                # 只统计，不连 CAD
    python dxf_trace_to_cad.py <输入.dxf> --offset 100000,0        # 整体平移后描（默认不平移）
    python dxf_trace_to_cad.py <输入.dxf> --report out.json        # 输出 JSON 报告

运行前提（同 cad_live 链路）：
    · AutoCAD 已打开 + COM 已注册；权限级别一致（RUNASADMIN 问题见 _fix_runasadmin.py）
    · 未打开时脚本会尝试 CreateObject 自动拉起 AutoCAD（2018 实测可行，约 20~40 s）
    · 用本机 venv python 运行（需 ezdxf + comtypes）

2026-09-11 固化：源起 TEST-PDF2CAD-003/1#5#02.dxf 描图任务，2411/2411 实体全量还原，33 s。
"""
import argparse
import array
import json
import math
import os
import sys
import time
import traceback
from collections import Counter

import ezdxf
from comtypes.automation import VARIANT

TTF_MAP = {
    "宋体": "SimSun", "新宋体": "NSimSun", "黑体": "SimHei",
    "仿宋": "FangSong", "楷体": "KaiTi", "微软雅黑": "Microsoft YaHei",
}
LINETYPE_FALLBACK = "Continuous"


def log(msg):
    print(msg)
    sys.stdout.flush()


def P(x, y, z=0.0):
    """AutoCAD COM 点坐标：必须包成 VARIANT(double SAFEARRAY)，普通元组会报参数错误。"""
    v = VARIANT()
    v.value = array.array("d", [float(x), float(y), float(z)])
    return v


def PV(vec):
    """Vec3 / tuple → VARIANT 点。⚠️ ezdxf 的 Vec3 不支持切片，用 tuple() 转换。"""
    t = tuple(vec)
    return P(t[0], t[1], t[2] if len(t) > 2 else 0.0)


def RAD(deg):
    return math.radians(float(deg or 0) % 360.0)


# --------------------------------------------------------------------------
# 连接 CAD
# --------------------------------------------------------------------------
def connect_cad():
    import comtypes.client
    try:
        app = comtypes.client.GetActiveObject("AutoCAD.Application")
        log("已连接运行中的 AutoCAD：%s" % app.Version)
    except Exception:
        log("未发现运行中的 CAD，尝试通过 COM 启动 AutoCAD …")
        app = comtypes.client.CreateObject("AutoCAD.Application")
        log("已启动 AutoCAD：%s" % app.Version)
    try:
        app.Visible = True
    except Exception:
        pass
    time.sleep(1.5)
    return app


# --------------------------------------------------------------------------
# 样式 / 图层重建
# --------------------------------------------------------------------------
def rebuild_layers(doc, src, report):
    made = 0
    for lay in src.layers:
        name = lay.dxf.name
        if name in ("0", "Defpoints"):
            continue
        try:
            o = doc.Layers.Add(name)
            o.color = int(lay.dxf.color)
            lt = (lay.dxf.linetype or LINETYPE_FALLBACK).upper()
            if lt and lt != LINETYPE_FALLBACK.upper():
                try:
                    o.Linetype = lt            # 线型未定义时会抛错
                except Exception:
                    report["degraded"].append(["LAYER-LINETYPE", name, lt + "→Continuous"])
            made += 1
        except Exception as e:
            report["failed"].append(["LAYER", name, str(e)])
    log("图层重建：%d 个" % made)
    return made


def rebuild_text_styles(doc, src, report):
    made = 0
    for st in src.styles:
        name = st.dxf.name
        if name.upper() == "STANDARD":
            continue
        font = (st.dxf.font or "").strip()
        big = (getattr(st.dxf, "bigfont", "") or "").strip()
        try:
            o = doc.TextStyles.Add(name)
        except Exception:
            continue
        if name in TTF_MAP and not font:
            try:
                o.SetFont(TTF_MAP[name], False, False, 134, 0)   # 134 = GB2312 字符集
            except Exception as e:
                report["degraded"].append(["STYLE-TTF", name, str(e)[:60]])
        else:
            if font:
                try:
                    o.fontFile = font
                except Exception:
                    report["degraded"].append(["STYLE-FONT", name + ":" + font, "字体文件缺失，保留默认"])
            if big:
                try:
                    o.bigFontFile = big
                except Exception:
                    report["degraded"].append(["STYLE-BIG", name + ":" + big, "大字体缺失，保留默认"])
        made += 1
    log("文字样式重建：%d 个" % made)
    return made


def set_var(doc, name, val, report):
    try:
        doc.SetVariable(name, val)
    except Exception as e:
        report["degraded"].append(["DIMVAR", name, str(e)[:60]])


def rebuild_dimstyles(doc, src, names, report):
    """COM 惯例：DimStyles.Add（复制当前样式）→ 激活 → 改文档变量（写回该活动样式定义）。"""
    made = []
    for name in names:
        d = src.dimstyles.get(name)
        if d is None:
            continue
        try:
            o = doc.DimStyles.Add(name)
        except Exception:
            try:
                o = doc.DimStyles.Item(name)
            except Exception as e:
                report["failed"].append(["DIMSTYLE", name, str(e)])
                continue
        doc.ActiveDimStyle = o
        ds = float(d.dxf.dimscale or 1)
        set_var(doc, "DIMSCALE", ds, report)
        set_var(doc, "DIMTXT", float(d.dxf.dimtxt or 2.5) * ds, report)
        set_var(doc, "DIMASZ", float(d.dxf.dimasz or 2.5) * ds, report)
        set_var(doc, "DIMTSZ", float(d.dxf.dimtsz or 0) * ds, report)
        set_var(doc, "DIMEXE", float(d.dxf.dimexe or 1.5) * ds, report)
        set_var(doc, "DIMEXO", float(d.dxf.dimexo or 0.6) * ds, report)
        set_var(doc, "DIMGAP", float(d.dxf.dimgap or 1.0) * ds, report)
        set_var(doc, "DIMTAD", int(d.dxf.dimtad or 0), report)
        set_var(doc, "DIMDEC", int(d.dxf.dimdec or 0), report)
        set_var(doc, "DIMTIH", int(d.dxf.dimtih or 0), report)
        set_var(doc, "DIMTOH", int(d.dxf.dimtoh or 0), report)
        set_var(doc, "DIMCLRD", int(d.dxf.dimclrd or 0), report)
        set_var(doc, "DIMCLRE", int(d.dxf.dimclre or 0), report)
        set_var(doc, "DIMCLRT", int(d.dxf.dimclrt or 7), report)
        blk = (d.dxf.dimblk or "").strip()
        if blk:
            if blk.lower() == "_bwk":       # TSSD 私有箭头块，CAD 内不存在 → 斜线替代
                set_var(doc, "DIMBLK", "_ArchTick", report)
                report["degraded"].append(["DIMBLK", name, "_bwk→_ArchTick"])
            else:
                set_var(doc, "DIMBLK", blk, report)
        txsty = (d.dxf.dimtxsty or "").strip()
        if txsty:
            set_var(doc, "DIMTXSTY", txsty, report)
        made.append(name)
    log("标注样式重建：%s" % (", ".join(made) if made else "无"))
    return made


# --------------------------------------------------------------------------
# 实体绘制
# --------------------------------------------------------------------------
class Tracer(object):
    def __init__(self, doc, offset=(0.0, 0.0), report=None, src=None):
        self.doc = doc
        self.src = src
        self.dx, self.dy = offset
        self.report = report if report is not None else {"failed": [], "degraded": []}

    # -- 通用属性 --
    def _pt(self, vec):
        t = tuple(vec)
        return P(t[0] + self.dx, t[1] + self.dy, t[2] if len(t) > 2 else 0.0)

    def _style_common(self, obj, e):
        if e.dxf.layer:
            obj.Layer = e.dxf.layer
        if e.dxf.color != 256:          # 256 = BYLAYER，非随层才覆盖
            obj.Color = int(e.dxf.color)

    # -- 各类实体 --
    def line(self, space, e):
        o = space.AddLine(self._pt(e.dxf.start), self._pt(e.dxf.end))
        self._style_common(o, e)

    def lwpolyline(self, space, e):
        pts, bulges = [], []
        for p in e.get_points("xyb"):
            pts.extend([p[0] + self.dx, p[1] + self.dy])
            bulges.append(p[2])
        o = space.AddLightWeightPolyline(self._variant_array(pts))
        if e.closed:
            o.Closed = True
        for i, b in enumerate(bulges):           # 弧段凸度必须逐点补设
            if abs(b) > 1e-9:
                o.SetBulge(i, float(b))
        try:
            if getattr(e, "has_width", False):
                ws = [(p[3], p[4]) for p in e.get_points("xybss")]
                if all(abs(a - b) < 1e-9 for a, b in ws) and abs(ws[0][0]) > 1e-9:
                    o.ConstantWidth = ws[0][0]
                else:
                    for i, (a, b) in enumerate(ws):
                        if abs(a) > 1e-9 or abs(b) > 1e-9:
                            o.SetWidth(i, a, b)
        except Exception as ex:
            self.report["degraded"].append(["POLYLINE-WIDTH", e.dxf.handle, str(ex)[:60]])
        self._style_common(o, e)

    def polyline(self, space, e):                 # 老式 POLYLINE → 轻量多段线
        pts = []
        for v in e.vertices:
            t = tuple(v.dxf.location)
            pts.extend([t[0] + self.dx, t[1] + self.dy])
        if len(pts) < 4:
            return
        o = space.AddLightWeightPolyline(self._variant_array(pts))
        if e.is_closed:
            o.Closed = True
        self._style_common(o, e)

    def circle(self, space, e):
        o = space.AddCircle(self._pt(e.dxf.center), float(e.dxf.radius))
        self._style_common(o, e)

    def arc(self, space, e):
        o = space.AddArc(self._pt(e.dxf.center), float(e.dxf.radius),
                         RAD(e.dxf.start_angle), RAD(e.dxf.end_angle))
        self._style_common(o, e)

    def solid(self, space, e):
        o = space.AddSolid(self._pt(e.dxf.vtx0), self._pt(e.dxf.vtx1),
                           self._pt(e.dxf.vtx2), self._pt(e.dxf.vtx3))
        self._style_common(o, e)

    def text(self, space, e):
        d = e.dxf
        ins = d.get("insert", (0, 0, 0))
        o = space.AddText(d.text, self._pt(ins), float(d.height))
        o.StyleName = d.style
        o.Rotation = RAD(d.rotation)
        w = float(d.width or 1)
        if abs(w - 1.0) > 1e-9:                   # 宽度因子：COM 属性名是 ScaleWidth
            o.ScaleWidth = w
        if int(d.halign or 0) != 0:               # 对齐：先设 Alignment，再设对齐点
            o.Alignment = int(d.halign)
            ap = d.get("align_point", ins)        # ⚠️ 属性名是 align_point，不是 align
            o.TextAlignmentPoint = self._pt(ap)
        self._style_common(o, e)

    def mtext(self, space, e):
        d = e.dxf
        o = space.AddMText(self._pt(d.insert), float(d.width or 0), d.text)
        o.StyleName = d.style
        o.Rotation = RAD(d.rotation)
        try:
            if d.attachment_point:
                o.AttachmentPoint = int(d.attachment_point)
        except Exception:
            pass
        self._style_common(o, e)

    def dimension(self, space, e):
        d = e.dxf
        dt = int(d.dimtype) & 7
        p1, p2, dp = d.get("defpoint2"), d.get("defpoint3"), d.get("defpoint")
        if dt in (0, 1):
            if p1 is None or p2 is None or dp is None:
                raise ValueError("线性标注缺少定义点")
            if dt == 0:
                o = space.AddDimRotated(self._pt(p1), self._pt(p2), self._pt(dp), RAD(d.get("angle", 0)))
            else:
                o = space.AddDimAligned(self._pt(p1), self._pt(p2), self._pt(dp))
        elif dt == 3:
            o = space.AddDimDiametric(self._pt(dp), self._pt(p1), float(d.get("leader_length", 0) or 0))
        elif dt == 4:
            o = space.AddDimRadial(self._pt(dp), self._pt(p1), float(d.get("leader_length", 0) or 0))
        elif dt in (2, 5):
            apex = d.get("defpoint4") or d.get("defpoint")
            o = space.AddDimAngular(self._pt(apex), self._pt(p1), self._pt(p2), self._pt(dp))
        else:
            raise ValueError("暂不支持的标注类型 dimtype=%s" % dt)
        if (d.dimstyle or "") not in ("", "Standard"):
            try:
                o.StyleName = d.dimstyle
            except Exception:
                pass
        txt = d.get("text")
        if txt and txt not in ("<>", ""):
            o.TextOverride = txt
        self._style_common(o, e)

    def insert(self, space, e, depth=0):
        name = e.dxf.name
        blk = self.src.blocks.get(name)
        try:
            target = self.doc.Blocks.Add(P(0, 0, 0), name)
        except Exception:
            target = self.doc.Blocks.Item(name)
        tr = Tracer(self.doc, (0.0, 0.0), self.report, self.src)  # 块内实体按源坐标写，不加全局偏移
        for be in blk:
            fn = Tracer.HANDLERS.get(be.dxftype())
            if fn is None:
                tr.report["degraded"].append(["BLOCK-ENTITY", "%s/%s" % (name, be.dxftype()), "未支持，跳过"])
                continue
            try:
                if be.dxftype() == "INSERT" and depth >= 3:
                    continue
                fn(tr, target, be)
            except Exception as ex:
                tr.report["failed"].append(["BLOCK:%s" % name, be.dxftype(), str(ex)[:80]])
        d = e.dxf
        o = space.InsertBlock(self._pt(d.insert), name,
                              float(d.xscale or 1), float(d.yscale or 1), float(d.zscale or 1),
                              RAD(d.rotation))
        self._style_common(o, e)

    def hatch(self, space, e):
        """HATCH：AutoCAD COM 造填充边界较脆，退化为画边界线（记录降级）。"""
        n = 0
        for path in e.paths:
            if hasattr(path, "vertices"):
                pts = []
                for v in path.vertices:
                    pts.extend([v[0] + self.dx, v[1] + self.dy])
                if len(pts) >= 4:
                    space.AddLightWeightPolyline(self._variant_array(pts)).Layer = e.dxf.layer
                    n += 1
        self.report["degraded"].append(["HATCH", e.dxf.handle, "转为边界多段线 ×%d" % n])

    @staticmethod
    def _variant_array(coords):
        v = VARIANT()
        v.value = array.array("d", [float(c) for c in coords])
        return v

    HANDLERS = None


Tracer.HANDLERS = {
    "LINE": Tracer.line,
    "LWPOLYLINE": Tracer.lwpolyline,
    "POLYLINE": Tracer.polyline,
    "CIRCLE": Tracer.circle,
    "ARC": Tracer.arc,
    "SOLID": Tracer.solid,
    "TEXT": Tracer.text,
    "MTEXT": Tracer.mtext,
    "DIMENSION": Tracer.dimension,
    "INSERT": Tracer.insert,
    "HATCH": Tracer.hatch,
}


# --------------------------------------------------------------------------
# 主流程
# --------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser(description="任意 DXF → 画图方式描进 AutoCAD")
    ap.add_argument("dxf", help="输入 DXF 路径")
    ap.add_argument("--save-as", default=None, help="画完另存的路径（.dwg / .dxf），省略则只画不存")
    ap.add_argument("--current", action="store_true", help="画进当前活动文档（默认新建文档）")
    ap.add_argument("--offset", default="0,0", help="整体平移 dx,dy（默认 0,0 不平移）")
    ap.add_argument("--dry-run", action="store_true", help="只统计不连 CAD")
    ap.add_argument("--no-zoom", action="store_true", help="不执行 ZOOM E")
    ap.add_argument("--report", default=None, help="JSON 报告输出路径")
    ap.add_argument("--progress", type=int, default=300, help="每 N 个实体打印一次进度")
    args = ap.parse_args()

    dx, dy = [float(x) for x in args.offset.split(",")]
    report = {"source": args.dxf, "offset": [dx, dy], "failed": [], "degraded": [],
              "drawn": {}, "entities": 0}
    t0 = time.time()

    src = ezdxf.readfile(args.dxf)
    msp = src.modelspace()
    kinds = Counter(e.dxftype() for e in msp)
    report["entities"] = len(msp)
    log("源图：%s   版本 %s   实体 %d 个" % (os.path.basename(args.dxf), src.dxfversion, len(msp)))
    log("实体构成：%s" % dict(kinds))

    unsupported = {k: v for k, v in kinds.items() if k not in Tracer.HANDLERS}
    if unsupported:
        log("⚠️ 未支持的实体类型（将跳过）：%s" % unsupported)

    if args.dry_run:
        log("--dry-run：仅统计，不连接 CAD。")
        report["elapsed"] = round(time.time() - t0, 1)
        _dump_report(report, args.report)
        return

    app = connect_cad()
    doc = app.ActiveDocument if args.current else app.Documents.Add()
    log("目标文档：%s" % doc.Name)

    rebuild_layers(doc, src, report)
    rebuild_text_styles(doc, src, report)
    used_ds = sorted({e.dxf.dimstyle for e in msp if e.dxftype() == "DIMENSION" and e.dxf.dimstyle})
    rebuild_dimstyles(doc, src, used_ds, report)

    space = doc.ModelSpace
    tr = Tracer(doc, (dx, dy), report, src)
    drawn = Counter()
    total = len(msp)
    for n, e in enumerate(msp, 1):
        t = e.dxftype()
        fn = Tracer.HANDLERS.get(t)
        if fn is None:
            continue
        try:
            fn(tr, space, e)
            drawn[t] += 1
        except Exception:
            report["failed"].append([t, e.dxf.handle, traceback.format_exc(limit=1).strip().splitlines()[-1]])
        if args.progress and n % args.progress == 0:
            log("  进度 %d/%d  已耗时 %.1fs" % (n, total, time.time() - t0))

    report["drawn"] = dict(drawn)
    log("描图完成：%s" % dict(drawn))
    log("失败 %d 条，降级 %d 条" % (len(report["failed"]), len(report["degraded"])))
    for f in report["failed"][:10]:
        log("  [fail] %s" % (f,))
    for d in report["degraded"][:10]:
        log("  [降级] %s" % (d,))

    if not args.no_zoom:
        try:
            doc.SendCommand("_ZOOM\n_E\n\n")
        except Exception as e:
            log("ZOOM E 失败：%s" % e)

    try:
        report["cad_modelspace_count"] = doc.ModelSpace.Count
    except Exception:
        pass

    if args.save_as:
        save_confirmed(doc, app, args.save_as, report)

    report["elapsed"] = round(time.time() - t0, 1)
    log("总耗时 %.1fs" % report["elapsed"])
    _dump_report(report, args.report)


def _norm(p):
    return os.path.normcase(os.path.abspath(p))


def save_confirmed(doc, app, target, report):
    """另存加固：目标被其它已打开文档占用时先释放；仍失败则用临时名存好后改名。"""
    target = os.path.abspath(target)
    os.makedirs(os.path.dirname(target), exist_ok=True)

    # ① 关掉占用同一路径、且无未保存修改的文档（有改动的不动，避免误丢数据）
    try:
        for d in list(app.Documents):
            try:
                full = d.FullName
            except Exception:
                continue
            if full and _norm(full) == _norm(target):
                if d.Saved:
                    log("目标被文档 %s 占用，已释放（无未保存修改）" % d.Name)
                    d.Close(False)
                else:
                    log("⚠️ 文档 %s 占用了目标路径但存在未保存修改，未关闭" % d.Name)
    except Exception as e:
        log("释放占用检查失败（继续尝试保存）：%s" % str(e)[:80])

    # ② 直接另存
    try:
        doc.SaveAs(target)
        log("已保存：%s" % target)
        return
    except Exception as e:
        log("直接另存失败，改用临时名兜底：%s" % str(e)[:80])

    # ③ 临时名 → 改名覆盖
    root, ext = os.path.splitext(target)
    tmp = "%s_tmp%d%s" % (root, int(time.time()), ext or ".dwg")
    try:
        doc.SaveAs(tmp)
        os.replace(tmp, target)
        log("已保存（经临时文件改名）：%s" % target)
    except Exception as e2:
        report["failed"].append(["SAVE", target, str(e2)[:120]])
        log("❌ 保存失败：%s" % str(e2)[:200])
        raise


def _dump_report(report, path):
    if path:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(report, f, ensure_ascii=False, indent=2)
        log("报告：%s" % path)


if __name__ == "__main__":
    main()
