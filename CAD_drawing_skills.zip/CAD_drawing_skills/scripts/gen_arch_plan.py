# -*- coding: utf-8 -*-
"""离线生成建筑平面施工图 DXF（建施平面，对齐建筑标准图层思路）。

图面组成（平面布置图）：
- 外墙 200 双线(A-WALL) + 内墙 120 分隔(A-WALL)
- 窗(A-WINDOW 四线) / 门(A-DOOR 门扇+开启弧) / 洞口楼梯(A-OPEN)
- 房间名称+面积(A-TEXT) + 门窗编号(M/C) + 轴网尺寸
- 图名标注

图层为自建 A-* 系列（已入 cad_standards）。复用 cad_standards.apply_to_ezdxf()。

用法：
  python gen_arch_plan.py
  python gen_arch_plan.py --floor 二层 --project 某住宅
"""
import argparse
import math
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import ezdxf
from cad_standards import apply_to_ezdxf, axis_labels

_BASE = os.path.dirname(os.path.abspath(__file__))
OUT = (os.environ.get("CAD_DXF_OUT") or
       os.path.normpath(os.path.join(_BASE, os.pardir, "output")))

AXIS_R = 350.0
AXIS_H = 280.0
DIM1 = 1500.0
DIM2 = DIM1 + 750.0
AXIS_CENTER = DIM2 + 500.0 + AXIS_R

X_GAPS = [4000.0, 4000.0, 4000.0]
Y_GAPS = [3300.0, 3400.0, 3300.0]
EXT_WALL = 200.0
INT_WALL = 120.0


def finalize_view(doc, margin_ratio=0.04, aspect=1.78):
    from ezdxf.bbox import extents as _extents
    msp = doc.modelspace()
    ext = _extents(msp, fast=False)
    if not ext.has_data:
        print("WARN: empty")
        return
    minx, miny = ext.extmin.x, ext.extmin.y
    maxx, maxy = ext.extmax.x, ext.extmax.y
    w, h = maxx - minx, maxy - miny
    mx, my = w * margin_ratio, h * margin_ratio
    msp.dxf.extmin = (minx - mx, miny - my, 0.0)
    msp.dxf.extmax = (maxx + mx, maxy + my, 0.0)
    msp.dxf.limmin = (minx - mx, miny - my)
    msp.dxf.limmax = (maxx + mx, maxy + my)
    cx, cy = (minx + maxx) / 2.0, (miny + maxy) / 2.0
    vh = max(h * (1 + 2 * margin_ratio), w * (1 + 2 * margin_ratio) / aspect)
    for vp in doc.viewports.get("*Active"):
        vp.dxf.center = (cx, cy)
        vp.dxf.height = vh
        vp.dxf.aspect_ratio = aspect
    print("  extents: (%.0f,%.0f)-(%.0f,%.0f) size %.0f x %.0f" % (minx, miny, maxx, maxy, w, h))


def add_line(msp, a, b, layer):
    ln = msp.add_line((a[0], a[1], 0.0), (b[0], b[1], 0.0))
    ln.dxf.layer = layer
    return ln


def add_text(msp, txt, x, y, h, layer, style="Standard", rot=0, center=False):
    t = msp.add_text(str(txt), dxfattribs={
        "height": h, "layer": layer, "style": style,
        "insert": (x, y), "rotation": rot})
    if center:
        t.dxf.halign = 1
        t.dxf.valign = 1
    return t


def wall_run(msp, p1, p2, th, layer="A-WALL"):
    dx, dy = p2[0] - p1[0], p2[1] - p1[1]
    L = (dx * dx + dy * dy) ** 0.5
    if L < 1:
        return
    nx, ny = -dy / L, dx / L
    h2 = th / 2.0
    add_line(msp, (p1[0] + nx * h2, p1[1] + ny * h2),
             (p2[0] + nx * h2, p2[1] + ny * h2), layer)
    add_line(msp, (p1[0] - nx * h2, p1[1] - ny * h2),
             (p2[0] - nx * h2, p2[1] - ny * h2), layer)


def window_sym(msp, pos, wall_axis, w=1800.0, layer="A-WINDOW"):
    """外墙窗（四线）。wall_axis: 'h'=水平墙(窗沿 x 展开,于墙 y=const), 'v'=垂直墙(沿 y)。"""
    h2 = w / 2.0
    if wall_axis == "h":
        y = pos
        add_line(msp, (pos - h2, y), (pos + h2, y), layer)
        for k in range(4):
            x = pos - h2 + k * w / 3.0
            add_line(msp, (x, y - 75), (x, y + 75), layer)
    else:
        x = pos
        add_line(msp, (x, pos - h2), (x, pos + h2), layer)
        for k in range(4):
            y = pos - h2 + k * w / 3.0
            add_line(msp, (x - 75, y), (x + 75, y), layer)


def door_sym(msp, wall_axis, hinge, leaf_len, into_dir, layer="A-DOOR"):
    """门：门扇线 + 90° 开启弧。
    wall_axis: 'h' 门扇沿 y 开（铰点在水平墙上）；'v' 门扇沿 x 开（铰点在垂直墙上）。
    hinge: 铰点坐标。into_dir: +1 向内（房间侧）开的符号。"""
    if wall_axis == "h":
        leaf_end = (hinge[0], hinge[1] + into_dir * leaf_len)
        a0 = 90.0
        if into_dir < 0:
            a0 = -90.0
    else:
        leaf_end = (hinge[0] + into_dir * leaf_len, hinge[1])
        a0 = 180.0
        if into_dir < 0:
            a0 = 0.0
    add_line(msp, hinge, leaf_end, layer)
    msp.add_arc((hinge[0], hinge[1]), leaf_len, a0, a0 + 90.0,
                dxfattribs={"layer": layer})


def axis_draw(msp, xs, ys, xn, yn):
    xmax, ymax = xs[-1], ys[-1]
    for x in xs:
        add_line(msp, (x, -DIM1), (x, ymax + DIM2 + 500), "S-DOTE")
    for y in ys:
        add_line(msp, (-DIM1, y), (xmax + DIM2 + 500, y), "S-DOTE")
    for x, lab in zip(xs, xn):
        for cy in (-AXIS_CENTER, ymax + AXIS_CENTER):
            msp.add_circle((x, cy), AXIS_R, dxfattribs={"layer": "S-AXIS"})
            add_text(msp, lab, x, cy - AXIS_H / 2.0, AXIS_H, "S-AXIS_TEXT", style="AXIS", center=True)
    for y, lab in zip(ys, yn):
        for cx in (-AXIS_CENTER, xmax + AXIS_CENTER):
            msp.add_circle((cx, y), AXIS_R, dxfattribs={"layer": "S-AXIS"})
            add_text(msp, lab, cx - AXIS_H / 2.0, y, AXIS_H, "S-AXIS_TEXT", style="AXIS", center=True)


def bilateral_dims(msp, xs, ys):
    """四侧轴网尺寸：上下为 X 向分跨(DIM1)+总(DIM2)，左右为 Y 向分跨(DIM1)+总(DIM2)，对齐结构图规范。"""
    xmax, ymax = xs[-1], ys[-1]
    def dd(p1, p2, dist, text=None):
        d = msp.add_aligned_dim(p1=p1, p2=p2, distance=dist,
                                dimstyle="DIM100", dxfattribs={"layer": "S-DIM"})
        if text:
            d.set_text(str(text))
        d.render()
    for x0, x1 in zip(xs[:-1], xs[1:]):      # 下侧：分跨
        dd((x0, 0.0), (x1, 0.0), -DIM1, text=int(x1 - x0))
    dd((xs[0], 0.0), (xmax, 0.0), -DIM2, text=int(xmax - xs[0]))   # 下侧：总
    for x0, x1 in zip(xs[:-1], xs[1:]):      # 上侧：分跨
        dd((x0, ymax), (x1, ymax), DIM1, text=int(x1 - x0))
    dd((xs[0], ymax), (xmax, ymax), DIM2, text=int(xmax - xs[0]))  # 上侧：总
    for y0, y1 in zip(ys[:-1], ys[1:]):      # 左侧：分跨
        dd((0.0, y0), (0.0, y1), DIM1, text=int(y1 - y0))
    dd((0.0, ys[0]), (0.0, ymax), DIM2, text=int(ymax - ys[0]))    # 左侧：总
    for y0, y1 in zip(ys[:-1], ys[1:]):      # 右侧：分跨
        dd((xmax, y0), (xmax, y1), -DIM1, text=int(y1 - y0))
    dd((xmax, ys[0]), (xmax, ymax), -DIM2, text=int(ymax - ys[0])) # 右侧：总


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--x-gaps", default=",".join(str(int(g)) for g in X_GAPS))
    ap.add_argument("--y-gaps", default=",".join(str(int(g)) for g in Y_GAPS))
    ap.add_argument("--floor", default="一层")
    ap.add_argument("--project", default="某住宅")
    a = ap.parse_args()

    xg = [float(x) for x in a.x_gaps.split(",") if x.strip()]
    yg = [float(y) for y in a.y_gaps.split(",") if y.strip()]
    xs = [0.0]
    for g in xg:
        xs.append(xs[-1] + g)
    ys = [0.0]
    for g in yg:
        ys.append(ys[-1] + g)
    xn = axis_labels(len(xg) + 1, kind="number")
    yn = axis_labels(len(yg) + 1, kind="letter")
    xmax, ymax = xs[-1], ys[-1]

    doc = ezdxf.new("R2000", setup=True)
    apply_to_ezdxf(doc)
    doc.header["$INSUNITS"] = 4
    msp = doc.modelspace()

    # ---- 外墙（四边，200 双线）----
    wall_run(msp, (0, 0), (xmax, 0), EXT_WALL)
    wall_run(msp, (0, ymax), (xmax, ymax), EXT_WALL)
    wall_run(msp, (0, 0), (0, ymax), EXT_WALL)
    wall_run(msp, (xmax, 0), (xmax, ymax), EXT_WALL)

    # ---- 内墙分隔（120）----
    ix = 7600.0              # 竖向中墙：左(客厅/主卧) 右(厨/卫/次卧)
    wall_run(msp, (ix, 0), (ix, ymax), INT_WALL)
    iy = 5000.0              # 横向隔墙：下(客厅/厨房) 上(卧室区)
    wall_run(msp, (0, iy), (xmax, iy), INT_WALL)
    wall_run(msp, (10400.0, iy), (10400.0, ymax), INT_WALL)   # 卫生间分墙

    # ---- 窗（外墙）----
    window_sym(msp, 2600.0, "h", 1800.0)      # 顶墙窗
    add_text(msp, "C1", 3500.0, ymax + 220, 220, "A-TEXT", center=True)
    window_sym(msp, 10000.0, "h", 1800.0)
    add_text(msp, "C2", 10900.0, ymax + 220, 220, "A-TEXT", center=True)
    window_sym(msp, 2600.0, "h", 1500.0)     # 底墙窗
    window_sym(msp, 7400.0, "h", 1500.0)
    window_sym(msp, 2500.0, "v", 1500.0)     # 右墙窗
    add_text(msp, "C3", xmax + 260, 3000.0, 220, "A-TEXT", center=True)
    window_sym(msp, 7400.0, "v", 1500.0)
    add_text(msp, "C4", xmax + 260, 7900.0, 220, "A-TEXT", center=True)

    # ---- 门 ----
    door_sym(msp, "h", (5600.0, -100.0), 1000.0, 1.0)   # 入户门(底墙)向内
    add_text(msp, "M1", 5100.0, -420, 220, "A-TEXT", center=True)
    door_sym(msp, "v", (ix, 2500.0), 900.0, 1.0)         # 中墙门(客厅) +x 开
    add_text(msp, "M2", ix - 420, 2500.0, 220, "A-TEXT", center=True)
    door_sym(msp, "h", (1600.0, iy), 900.0, 1.0)         # 卧室门(横隔墙) +y 开
    add_text(msp, "M3", 2050.0, iy + 200, 220, "A-TEXT", center=True)
    door_sym(msp, "v", (ix, 4700.0), 800.0, 1.0)         # 厨房门
    add_text(msp, "M4", ix + 200, 4700.0, 220, "A-TEXT", center=True)

    # ---- 房间名称 + 面积 ----
    rooms = [
        (3800.0, 7800.0, "主卧室", "18.0m²"),
        (9200.0, 7400.0, "次卧室", "12.6m²"),
        (10600.0, 8200.0, "卫生间", "4.2m²"),
        (3200.0, 2300.0, "客厅(含餐厅)", "32.4m²"),
        (9000.0, 2300.0, "厨房", "8.4m²"),
    ]
    for rx, ry, name, area in rooms:
        add_text(msp, name, rx, ry + 220, 320, "A-TEXT", center=True)
        add_text(msp, area, rx, ry - 320, 240, "A-TEXT", center=True)

    # ---- 轴网 + 四侧尺寸 ----
    axis_draw(msp, xs, ys, xn, yn)
    bilateral_dims(msp, xs, ys)

    # ---- 门窗表（平面下方）----
    dy = -3600.0
    tx0 = 1200.0
    add_text(msp, "门窗表", tx0, dy, 320, "S-TAB_TEXT")
    add_line(msp, (tx0, dy - 80), (tx0 + 5200, dy - 80), "S-TAB")
    # 表头
    hdr = [("编号", 0), ("洞口宽x高", 1), ("编号", 2), ("洞口宽x高", 3)]
    colx = [tx0, tx0 + 1200, tx0 + 2600, tx0 + 3800]
    for (lab, ci) in hdr:
        add_text(msp, lab, colx[ci] + 100, dy - 320, 240, "S-TAB_TEXT")
    doors = [("M1", "1000x2100"), ("M2", "900x2100"), ("M3", "900x2100"), ("M4", "800x2100")]
    wins = [("C1", "1800x1500"), ("C2", "1500x1500"), ("C3", "1500x1500"), ("C4", "1500x1500")]
    row = 1
    for i in range(4):
        ys0 = dy - i * 320 - 700
        add_line(msp, (tx0, ys0), (tx0 + 5200, ys0), "S-TAB")
        if i < len(doors):
            add_text(msp, doors[i][0], colx[0] + 100, ys0 + 120, 240, "S-TAB_TEXT")
            add_text(msp, doors[i][1], colx[1] + 100, ys0 + 120, 240, "S-TAB_TEXT")
        if i < len(wins):
            add_text(msp, wins[i][0], colx[2] + 100, ys0 + 120, 240, "S-TAB_TEXT")
            add_text(msp, wins[i][1], colx[3] + 100, ys0 + 120, 240, "S-TAB_TEXT")

    # ---- 图名（图正下方，门窗表之下，对齐结构图规范）----
    tit = "%s %s建筑平面图  1:100" % (a.project, a.floor)
    ty = dy - 2600                       # 门窗表之下
    tw = len(tit) * 420
    tx = (xmax - tw) / 2.0
    add_text(msp, tit, tx, ty, 420, "A-TEXT")
    add_line(msp, (tx, ty - 180), (tx + tw, ty - 180), "A-TEXT")

    finalize_view(doc, margin_ratio=0.03, aspect=1.78)
    fname = "建筑平面图_arch_r2000.dxf"
    path = os.path.join(OUT, fname)
    os.makedirs(OUT, exist_ok=True)
    doc.saveas(path)
    errs = len(doc.audit().errors)
    ne = len(list(msp))
    print("[OK] %s 实体=%d 审计错误=%d" % (path, ne, errs))


if __name__ == "__main__":
    main()
