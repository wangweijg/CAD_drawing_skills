# -*- coding: utf-8 -*-
"""建筑平面图生成器：5600×6800 单跨小户型（客厅+餐桌区 / 餐厅-厨房备餐区 / 卧室 / 卫生间 / 阳台）。

对齐 CAD_drawing_skills 建筑+A-* 图层标准；轴网双侧两级尺寸（同结构图 gen_dxf_layout）；图名放图正下方。
R2000 出货，finalize_view 保证 CAD 打开可见。

用法：
  python gen_arch_plan_house.py                              # 默认 5600×6800
  python gen_arch_plan_house.py --x 5600 --y 6800 --name 某住宅 --floor 一层
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import ezdxf
from cad_standards import apply_to_ezdxf

_BASE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(os.path.dirname(_BASE), "output")
os.makedirs(OUT, exist_ok=True)

AXIS_R = 350.0
AXIS_H = 280.0
DIM1 = 1500.0
DIM2 = DIM1 + 750.0
AXIS_CENTER = DIM2 + 500.0 + AXIS_R
EXT = 200.0
INT = 120.0

msp = None  # global，供 aligned_dim / finalize_view 使用


def finalize_view(doc, margin_ratio=0.03, aspect=1.78, XMAX=5600.0, YMAX=6800.0):
    msp = doc.modelspace()
    from ezdxf import bbox as _b
    mnx = mny = float("inf"); mxx = mxy = float("-inf")
    for e in msp:
        if e.dxftype() == "DIMENSION":
            continue
        try:
            bb = _b.extents([e], fast=True)
            if bb.has_data:
                mnx = min(mnx, bb.extmin.x); mny = min(mny, bb.extmin.y)
                mxx = max(mxx, bb.extmax.x); mxy = max(mxy, bb.extmax.y)
        except Exception:
            pass
    if not (mnx < mxx and mny < mxy):
        mnx, mny, mxx, mxy = 0, 0, XMAX, YMAX
    mnx -= DIM2 + 800
    mny -= AXIS_CENTER + 2000   # 图名已下移到底部轴圈之下
    mxx += DIM2 + 800
    mxy += DIM2 + 800
    w = mxx - mnx; h = mxy - mny
    mx, my = w * margin_ratio, h * margin_ratio
    msp.dxf.extmin = (mnx - mx, mny - my, 0.0)
    msp.dxf.extmax = (mxx + mx, mxy + my, 0.0)
    msp.dxf.limmin = (mnx - mx, mny - my)
    msp.dxf.limmax = (mxx + mx, mxy + my)
    cx, cy = (mnx + mxx) / 2.0, (mny + mxy) / 2.0
    vh = max(h * (1 + 2 * margin_ratio), w * (1 + 2 * margin_ratio) / aspect)
    for vp in doc.viewports.get("*Active"):
        vp.dxf.center = (cx, cy)
        vp.dxf.height = vh
        vp.dxf.aspect_ratio = aspect


def line(msp, a, b, layer):
    ln = msp.add_line((a[0], a[1], 0.0), (b[0], b[1], 0.0))
    ln.dxf.layer = layer
    return ln


def txt(msp, s, x, y, h, layer, style="Standard", rot=0, center=False):
    t = msp.add_text(str(s), dxfattribs={"height": h, "layer": layer,
                     "style": style, "insert": (x, y), "rotation": rot})
    if center:
        t.dxf.halign = 1; t.dxf.valign = 1
    return t


def wall(msp, p1, p2, th, layer="A-WALL"):
    dx, dy = p2[0] - p1[0], p2[1] - p1[1]
    L = (dx * dx + dy * dy) ** 0.5
    if L < 1:
        return
    nx, ny = -dy / L, dx / L
    h2 = th / 2.0
    line(msp, (p1[0] + nx * h2, p1[1] + ny * h2), (p2[0] + nx * h2, p2[1] + ny * h2), layer)
    line(msp, (p1[0] - nx * h2, p1[1] - ny * h2), (p2[0] - nx * h2, p2[1] - ny * h2), layer)


def window_sym(msp, axis, wall_pos, along_pos, w, layer="A-WINDOW"):
    h2 = w / 2.0
    if axis == "h":
        y = wall_pos
        line(msp, (along_pos - h2, y), (along_pos + h2, y), layer)
        for k in range(4):
            x = along_pos - h2 + k * w / 3.0
            line(msp, (x, y - 75), (x, y + 75), layer)
    else:
        x = wall_pos
        line(msp, (x, along_pos - h2), (x, along_pos + h2), layer)
        for k in range(4):
            y = along_pos - h2 + k * w / 3.0
            line(msp, (x - 75, y), (x + 75, y), layer)


def door_sym(msp, axis, hinge, leaf, into, layer="A-DOOR"):
    if axis == "h":
        end = (hinge[0], hinge[1] + into * leaf)
        a0 = 90.0 if into >= 0 else -90.0
    else:
        end = (hinge[0] + into * leaf, hinge[1])
        a0 = 180.0 if into >= 0 else 0.0
    line(msp, hinge, end, layer)
    msp.add_arc((hinge[0], hinge[1]), leaf, a0, a0 + 90.0, dxfattribs={"layer": layer})


def sliding_door(msp, axis, wall_pos, along_pos, w, layer="A-DOOR"):
    """推拉门：双层门线。axis='h': 沿x(墙y)；axis='v': 沿y(墙x)。"""
    h2 = w / 2.0
    if axis == "h":
        line(msp, (along_pos - h2, wall_pos - 45), (along_pos + h2, wall_pos - 45), layer)
        line(msp, (along_pos - h2, wall_pos + 45), (along_pos + h2, wall_pos + 45), layer)
    else:
        x = wall_pos
        line(msp, (x - 45, along_pos - h2), (x - 45, along_pos + h2), layer)
        line(msp, (x + 45, along_pos - h2), (x + 45, along_pos + h2), layer)


def aligned_dim(p1, p2, distance, text=""):
    dim = msp.add_aligned_dim(p1=p1, p2=p2, distance=distance,
                              dimstyle="DIM100", dxfattribs={"layer": "S-DIM"})
    if text:
        dim.set_text(str(text))
    dim.render()
    return dim


def axis_draw(msp, XMAX, YMAX):
    xs = [0.0, XMAX]; ys = [0.0, YMAX]
    for x in xs:
        line(msp, (x, -DIM1), (x, YMAX + DIM2 + 500), "S-DOTE")
    for y in ys:
        line(msp, (-DIM1, y), (XMAX + DIM2 + 500, y), "S-DOTE")
    for x, lab in zip(xs, ["1", "2"]):
        for cy in (-AXIS_CENTER, YMAX + AXIS_CENTER):
            msp.add_circle((x, cy), AXIS_R, dxfattribs={"layer": "S-AXIS"})
            txt(msp, lab, x, cy - AXIS_H / 2.0, AXIS_H, "S-AXIS_TEXT", style="AXIS", center=True)
    for y, lab in zip(ys, ["A", "B"]):
        for cx in (-AXIS_CENTER, XMAX + AXIS_CENTER):
            msp.add_circle((cx, y), AXIS_R, dxfattribs={"layer": "S-AXIS"})
            txt(msp, lab, cx - AXIS_H / 2.0, y, AXIS_H, "S-AXIS_TEXT", style="AXIS", center=True)
    top_y = YMAX; right_x = XMAX
    aligned_dim((xs[0], 0.0), (xs[1], 0.0), -DIM1, text=str(int(xs[1] - xs[0])))
    aligned_dim((xs[0], 0.0), (xs[1], 0.0), -DIM2, text=str(int(xs[1] - xs[0])))
    aligned_dim((xs[0], top_y), (xs[1], top_y), DIM1, text=str(int(xs[1] - xs[0])))
    aligned_dim((xs[0], top_y), (xs[1], top_y), DIM2, text=str(int(xs[1] - xs[0])))
    aligned_dim((0.0, ys[0]), (0.0, ys[1]), DIM1, text=str(int(ys[1] - ys[0])))
    aligned_dim((0.0, ys[0]), (0.0, ys[1]), DIM2, text=str(int(ys[1] - ys[0])))
    aligned_dim((right_x, ys[0]), (right_x, ys[1]), -DIM1, text=str(int(ys[1] - ys[0])))
    aligned_dim((right_x, ys[0]), (right_x, ys[1]), -DIM2, text=str(int(ys[1] - ys[0])))


def plan_title(msp, name, XMAX):
    tit_h = 500.0
    y = -AXIS_CENTER - 1700              # 图名放图的正下方（底部轴圈之下）
    x0 = XMAX / 2.0 - len(name) * tit_h * 0.45
    txt(msp, name, x0, y, tit_h, "A-TEXT")
    w = len(name) * tit_h * 0.9
    line(msp, (x0, y - 200), (x0 + w, y - 200), "A-TEXT")
    txt(msp, "1:100", x0 + w + 300, y, int(tit_h * 0.7), "A-TEXT")


def main():
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--x", type=float, default=5600.0, help="X 向跨度（单跨）")
    ap.add_argument("--y", type=float, default=6800.0, help="Y 向跨度（单跨）")
    ap.add_argument("--name", default="某住宅")
    ap.add_argument("--floor", default="一层")
    ap.add_argument("--out", default=None)
    a = ap.parse_args()

    global msp
    XMAX, YMAX = a.x, a.y
    Y_SEP = YMAX * 0.69    # 横向主墙：下=客厅/餐厨，上=卧室/卫
    X_SEP = XMAX * 0.84    # 竖向通高墙：户内 | 阳台
    X_BED = XMAX * 0.45    # 上区竖墙：卧室 | 卫生间

    doc = ezdxf.new("R2000", setup=True)
    apply_to_ezdxf(doc)
    doc.header["$INSUNITS"] = 4
    msp = doc.modelspace()

    # 外墙 200 双线
    wall(msp, (0, 0), (XMAX, 0), EXT)
    wall(msp, (0, YMAX), (XMAX, YMAX), EXT)
    wall(msp, (0, 0), (0, YMAX), EXT)
    wall(msp, (XMAX, 0), (XMAX, YMAX), EXT)

    # 内墙 120
    wall(msp, (0, Y_SEP), (XMAX, Y_SEP), INT)
    wall(msp, (X_SEP, 0), (X_SEP, YMAX), INT)
    wall(msp, (X_BED, Y_SEP), (X_BED, YMAX), INT)

    # 窗（外墙）——相对比例
    window_sym(msp, "h", 0.0, XMAX * 0.5, XMAX * 0.43)      # 客厅窗（底墙）
    txt(msp, "C1", XMAX * 0.5, -360, 220, "A-TEXT", center=True)
    window_sym(msp, "h", YMAX, XMAX * 0.27, XMAX * 0.27)    # 卧室窗（顶墙）
    txt(msp, "C2", XMAX * 0.27, YMAX + 360, 220, "A-TEXT", center=True)
    window_sym(msp, "h", YMAX, XMAX * 0.64, XMAX * 0.16)    # 卫生间窗（顶墙）
    txt(msp, "C3", XMAX * 0.64, YMAX + 360, 220, "A-TEXT", center=True)
    window_sym(msp, "v", XMAX, YMAX * 0.35, XMAX * 0.21)    # 阳台窗（右墙）
    txt(msp, "C4", XMAX + 260, YMAX * 0.35, 220, "A-TEXT", center=True)

    # 门
    door_sym(msp, "h", (XMAX * 0.05, 0.0), XMAX * 0.16, 1.0)   # 入户门（底墙）
    txt(msp, "M1", XMAX * 0.14, -360, 220, "A-TEXT", center=True)
    door_sym(msp, "h", (XMAX * 0.16, Y_SEP), XMAX * 0.16, 1.0)  # 卧室门（横主墙）
    txt(msp, "M2", XMAX * 0.16, Y_SEP + 200, 220, "A-TEXT", center=True)
    door_sym(msp, "h", (XMAX * 0.61, Y_SEP), XMAX * 0.14, 1.0)  # 卫生间门
    txt(msp, "M3", XMAX * 0.61, Y_SEP + 200, 220, "A-TEXT", center=True)
    sliding_door(msp, "v", X_SEP, YMAX * 0.5, XMAX * 0.43)      # 阳台推拉双门线
    txt(msp, "TL1", X_SEP + 260, YMAX * 0.5, 220, "A-TEXT", center=True)

    # 房间分区 + 面积（相对比例）
    rooms = [
        ("客厅(含餐桌区)", (XMAX * 0.42, YMAX * 0.35), XMAX * YMAX * 0.56 / 1e6),
        ("餐厅/厨房备餐区", (XMAX * 0.77, YMAX * 0.35), None),
        ("卧室", (XMAX * 0.22, YMAX * 0.85), XMAX * YMAX * 0.14 / 1e6),
        ("卫生间", (XMAX * 0.64, YMAX * 0.85), XMAX * YMAX * 0.12 / 1e6),
        ("阳台", (XMAX * 0.92, YMAX * 0.5), XMAX * YMAX * 0.16 / 1e6),
    ]
    for name, (rx, ry), area in rooms:
        txt(msp, name, rx, ry + 230, 360 if area else 260, "A-TEXT", center=True)
        if area:
            txt(msp, "%.1f m²" % area, rx, ry - 300, 240, "A-TEXT", center=True)

    # 轴网 + 图名
    axis_draw(msp, XMAX, YMAX)
    plan_title(msp, "%s %s建筑平面图" % (a.name, a.floor), XMAX)

    finalize_view(doc, XMAX=XMAX, YMAX=YMAX)
    fname = a.out or "建筑平面_小户型_%dx%d_r2000.dxf" % (int(XMAX), int(YMAX))
    path = os.path.join(OUT, fname)
    doc.saveas(path)
    errs = len(doc.audit().errors)
    print("[OK] %s 实体=%d 审计错误=%d" % (path, len(list(msp)), errs))


if __name__ == "__main__":
    main()
