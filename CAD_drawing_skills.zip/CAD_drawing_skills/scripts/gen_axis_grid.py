# -*- coding: utf-8 -*-
"""绘制轴网 DXF：X 向 6 跨 × 4000，Y 向 2 跨 × 5600。

只输出轴网（轴线 + 轴线圈 + 轴号），供在 AutoCAD 中打开后继续手绘结构图。
对齐 structural_demo_template.py 的约定：DOT 线型、GBENOR/GBCBIG 字体、R2000 输出。
"""
import ezdxf, os

_BASE = os.path.dirname(os.path.abspath(__file__))
OUT = os.environ.get("CAD_DXF_OUT") or os.path.join(
    _BASE, os.pardir, "output", "axis_grid_4000x6_5600x2.dxf")
OUT = os.path.normpath(OUT)
os.makedirs(os.path.dirname(OUT), exist_ok=True)

doc = ezdxf.new("R2018", setup=True)
doc.header["$DIMSCALE"] = 100.0
doc.header["$LTSCALE"] = 100.0
doc.header["$TEXTSIZE"] = 200.0
doc.header["$INSUNITS"] = 4      # 毫米

std = doc.styles.get("Standard")
std.dxf.font = "GBENOR"
std.dxf.bigfont = "GBCBIG"
doc.styles.new("AXIS", dxfattribs={"font": "txt.shx"})

doc.layers.add("S-DOTE", color=253, lineweight=15, linetype="DOT")
doc.layers.add("S-AXIS", color=3, lineweight=15)
doc.layers.add("S-AXIS_TEXT", color=7, lineweight=15)
doc.layers.add("S-TEXT", color=7, lineweight=15)

msp = doc.modelspace()

# ---- 几何参数 ----
XS = [0, 4000, 8000, 12000, 16000, 20000, 24000]   # 6 跨 × 4000 -> 7 条 X 轴
YS = [0, 5600, 11200]                               # 2 跨 × 5600 -> 3 条 Y 轴
XNUM = ["1", "2", "3", "4", "5", "6", "7"]
YNUM = ["A", "B", "C"]
EXT = 2000
AXIS_R = 350
AXIS_H = 280
AXIS_ENDOFF = EXT
AXIS_CENTER = AXIS_ENDOFF + AXIS_R


def add_axis_text(text, x, y):
    t = msp.add_text(text, dxfattribs={
        "layer": "S-AXIS_TEXT", "height": AXIS_H,
        "style": "AXIS", "color": 7})
    t.set_placement((x - AXIS_H * 0.25 * len(text), y - AXIS_H * 0.35))


# ---- 轴线（S-DOTE, DOT 线型，避开 AutoCAD 不识别的 DOTE）----
for x in XS:
    msp.add_line((x, -AXIS_ENDOFF), (x, YS[-1] + AXIS_ENDOFF),
                 dxfattribs={"layer": "S-DOTE"})
for y in YS:
    msp.add_line((-AXIS_ENDOFF, y), (XS[-1] + AXIS_ENDOFF, y),
                 dxfattribs={"layer": "S-DOTE"})

# ---- 轴号（四边：圆圈 + 编号）----
for i, x in enumerate(XS):
    for y in [-AXIS_CENTER, YS[-1] + AXIS_CENTER]:
        msp.add_circle((x, y), AXIS_R, dxfattribs={"layer": "S-AXIS"})
        add_axis_text(XNUM[i], x, y)
for i, y in enumerate(YS):
    for x in [-AXIS_CENTER, XS[-1] + AXIS_CENTER]:
        msp.add_circle((x, y), AXIS_R, dxfattribs={"layer": "S-AXIS"})
        add_axis_text(YNUM[i], x, y)

# ---- 图名 ----
name = "轴网  4000x6 / 5600x2"
ty = YS[-1] + AXIS_CENTER + 1400
tx0 = XS[-1] / 2 - len(name) * 280 * 0.45
msp.add_text(name, dxfattribs={"layer": "S-TEXT", "height": 280, "style": "Standard"}
             ).set_placement((tx0, ty))


# ---- 收尾：设置视图范围，否则 CAD 打开一片空白 ----
def finalize_view(doc, margin_ratio=0.06, aspect=1.78):
    from ezdxf.bbox import extents as _extents
    msp = doc.modelspace()
    ext = _extents(msp, fast=False)
    if not ext.has_data:
        print("WARN: modelspace empty, skip finalize_view")
        return
    minx, miny = ext.extmin.x, ext.extmin.y
    maxx, maxy = ext.extmax.x, ext.extmax.y
    w, h = maxx - minx, maxy - miny
    mx, my = w * margin_ratio, h * margin_ratio
    lo = (minx - mx, miny - my)
    hi = (maxx + mx, maxy + my)
    msp.dxf.extmin = (lo[0], lo[1], 0.0)
    msp.dxf.extmax = (hi[0], hi[1], 0.0)
    msp.dxf.limmin = lo
    msp.dxf.limmax = hi
    cx, cy = (minx + maxx) / 2.0, (miny + maxy) / 2.0
    view_h = max(h * (1 + 2 * margin_ratio), w * (1 + 2 * margin_ratio) / aspect)
    for vp in doc.viewports.get("*Active"):
        vp.dxf.center = (cx, cy)
        vp.dxf.height = view_h
        vp.dxf.aspect_ratio = aspect
    print(f"  extents: ({minx:.0f},{miny:.0f}) - ({maxx:.0f},{maxy:.0f})  "
          f"size {w:.0f} x {h:.0f}")


finalize_view(doc)
doc.dxfversion = "AC1015"      # R2000，兼容性最好
doc.saveas(OUT)
print("saved ->", OUT)
