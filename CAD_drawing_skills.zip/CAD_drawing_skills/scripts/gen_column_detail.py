# -*- coding: utf-8 -*-
"""柱配筋详图离线 DXF 生成器（22G101-1 柱表截面详图）。

给定一根柱的配筋，离线生成可双击用 AutoCAD 打开的 DXF，
同时输出一份 SVG 预览（同一套几何，仅供快速查看）。

与 cad_column_detail.py（COM 实时版）共用模板 JSON 几何与 cad_standards，
因此离线出图与实时出图完全一致，且都按模板「柱子_详图_600x600」重放：
  - 外框 7700×10000（上 800 标题行 + 6000 截面区 + 底部 3200 四行柱表）
  - 柱截面放大 10/3≈3.33 倍，截面中心 (4400,6200)
  - 复合箍筋（1 外箍 + 2 内箍），12 点多段线含 135° 弯钩
  - 纵筋 circle 样式实心圆点（线宽随直径缩放）
  - 尺寸线距截面 666.7（底部 + 右侧，文本=实际截面）
  - 直径符号 %%132（HRB400，TSSD 字体）
  - 图层：S-COLU_DE / S-REIN / S-TAB / S-TAB_TEXT / S-PUB_TEXT / S-COLU_DE_TEXT / S-DIM

用法：
  python gen_column_detail.py --name KZ-1 --section 400x400 \\
      --rebar "8C20" --stirrup "C8@100/200" --level "基础顶~-3.470" \\
      --frame --out "output/柱表_KZ-1_400x400.dxf"
"""
import os
import re
import sys
import math
import argparse

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cad_standards as STD

import ezdxf
from ezdxf.enums import TextEntityAlignment
from ezdxf.bbox import extents as _extents

# 模板几何：与 cad_column_detail.py（COM 实时版）共用同一套
# 模板读取（find_template / Geom）与几何函数（edge_positions / stirrup_pts），
# 保证离线出图与实时出图逐点一致。
from cad_column_detail import (Geom, find_template, edge_positions,
                               stirrup_pts)

# 柱详图专用图层（对齐模板 zhuzi.dxf 7 层）
DETAIL_LAYERS = [
    "S-COLU_DE", "S-REIN", "S-TAB", "S-TAB_TEXT",
    "S-PUB_TEXT", "S-COLU_DE_TEXT", "S-DIM",
]

TXT_H = 300.0              # 详图/引出线文字字高（对齐模板）
TAB_NAME_H = 450.0         # 柱号文字字高（KZ-3，S-TAB_TEXT）
TAB_TXT_H = 300.0          # 表内文字字高（S-PUB_TEXT）
LABEL_GAP = 600.0
DIM_OFFSET_MM = 250.0
TEXT_LINE = 350.0
BAR_DOT_W = 58.33          # 纵筋点多段线宽度（对齐模板）
STIRRUP_W = 40.0           # 箍筋多段线宽度（对齐模板）
BAR_INSET = 65.0           # 纵筋点中心到箍筋中心线的间距（对齐模板）
HOOK_EXT = 100.0           # 弯钩延伸量
HOOK_DIAG = 177.0          # 弯钩对角线长度

DEFAULT_FRAME_W = 7700.0
DEFAULT_FRAME_H = 10700.0
DEFAULT_SECTION_H = 7500.0
DEFAULT_ROW_H = 800.0
DEFAULT_SCALE = 10.0 / 3.0


# ============================================================
# 解析
# ============================================================
def normalize_phi(s):
    """统一替换为 %%132（HRB400 钢筋符号，TSSD 字体）。"""
    import re as _re
    if not s:
        return s
    return _re.sub(r"[CcφΦ]|%%132|%%c", "%%132", str(s))


def parse_section(section):
    m = re.match(r"(\d+)\s*[xX*]\s*(\d+)", section.strip())
    if not m:
        raise ValueError("截面格式应为 500x500: %s" % section)
    return int(m.group(1)), int(m.group(2))


def parse_rebar(spec):
    """解析纵筋规格：'12C20' / '8C25+4C20' -> [(count,dia), ...]。"""
    spec = re.sub(r"%%132|%%c|Φ|φ|C|c", " ", str(spec))
    groups = []
    for part in re.split(r"[+＋]", spec):
        part = part.strip()
        m = re.match(r"(\d+)\s+(\d+)", part)
        if m:
            groups.append((int(m.group(1)), int(m.group(2))))
    return groups


def build_diameter_list(groups):
    """按 22G101 平法约定把纵筋组分配到位置顺序的直径列表。"""
    if not groups:
        return []
    if len(groups) == 1:
        return [groups[0][1]] * groups[0][0]
    b_count, b_dia = groups[0]
    h_count, h_dia = groups[1]
    b_mid = max(0, (b_count - 4) // 2)
    h_mid = max(0, h_count // 2)
    n_per = max(b_mid, h_mid, 1)
    dlist = [b_dia] * 4
    for i in range(n_per):
        dlist.append(b_dia if i < b_mid else b_dia)
        dlist.append(b_dia if i < b_mid else b_dia)
        dlist.append(h_dia if i < h_mid else h_dia)
        dlist.append(h_dia if i < h_mid else h_dia)
    total = sum(c for c, _ in groups)
    return dlist[:total]


# ============================================================
# 几何（同时供 DXF 与 SVG 复用，单一数据源）
# ============================================================
def _build_template_layout(*, name, section, rebar, stirrup, level,
                           b, h, g, dx, dy, leader):
    """按模板「柱子_详图_600x600」geometry 逐点重放（与 cad_column_detail 一致）。

    模板实测几何：
      外框 7700x10000（上 800 标题行 + 6000 截面区 + 底部 3200 四行柱表）
      截面中心 (4400,6200)，放大 10/3，保护层 30 -> 截面内缩 100
      纵筋外圈布置（circle 样式实心圆点，半径随直径缩放）
      箍筋 3 道 12 点多段线（135° 弯钩在右下角），线宽 40
      尺寸线距截面 666.7（底部 + 右侧，文本=实际截面）
      仅一条角部引出线 + 顶部/左侧两个边部文字（无引出线）
    """
    hw, hh = b * g.scale / 2.0, h * g.scale / 2.0
    cov = g.cover_mm * g.scale
    cx, cy = g.cx + dx, g.cy + dy
    left, right = cx - hw, cx + hw
    bottom, top = cy - hh, cy + hh

    # 1) 外框（闭合多段线）+ 表行分隔 + 表列竖线（S-TAB）
    frame_poly = [(0 + dx, 0 + dy), (g.frame_w + dx, 0 + dy),
                  (g.frame_w + dx, g.frame_h + dy), (0 + dx, g.frame_h + dy)]
    frame_lines = [
        (frame_poly[0][0], frame_poly[0][1],
         frame_poly[1][0], frame_poly[1][1]),
        (frame_poly[1][0], frame_poly[1][1],
         frame_poly[2][0], frame_poly[2][1]),
        (frame_poly[2][0], frame_poly[2][1],
         frame_poly[3][0], frame_poly[3][1]),
        (frame_poly[3][0], frame_poly[3][1],
         frame_poly[0][0], frame_poly[0][1]),
    ]
    table_lines = []
    for yy in g.table["h_lines"]:
        table_lines.append((dx, yy + dy, g.frame_w + dx, yy + dy))
    table_lines.append((g.table["v_line_x"] + dx, dy,
                        g.table["v_line_x"] + dx,
                        g.table["h_lines"][-1] + dy))

    # 2) 标题 + 表行标签/值
    #    标签一律 S-TAB_TEXT h=450；值按行高：level/rebar/stirrup -> S-PUB_TEXT h=300，
    #    name -> S-TAB_TEXT h=450（与模板 text_index 逐项一致）
    texts = [{
        "txt": g.title["text"], "x": g.title["x"] + dx,
        "y": g.title["y"] + dy, "h": g.h_title,
        "layer": "S-TAB_TEXT", "align": "center", "rotation": 0.0,
    }]
    table_rows = []
    value_map = {"name": name, "level": level,
                 "rebar": normalize_phi(rebar),
                 "stirrup": normalize_phi(stirrup)}
    for row in g.table["rows"]:
        table_rows.append((row["label"], g.table["label_x"] + dx,
                           row["y"] + dy, "S-TAB_TEXT", g.h_table))
        field = row.get("field")
        if field:
            layer = "S-PUB_TEXT" if field in ("level", "rebar",
                                              "stirrup") else "S-TAB_TEXT"
            table_rows.append((value_map[field], g.table["value_x"] + dx,
                               row["y"] + dy, layer,
                               row.get("h", g.h_table)))

    # 3) 截面轮廓（S-COLU_DE）
    outline = {"kind": "rect", "cx": cx, "cy": cy, "w": 2 * hw,
               "h": 2 * hh, "layer": "S-COLU_DE"}

    # 4) 复合箍筋（外箍 + 内箍竖 + 内箍横，12 点多段线，几何与模板逐点一致）
    sw, sh = 2 * hw - 2 * cov, 2 * hh - 2 * cov
    bar_sp_x = (2 * hw - 2 * g.bar_offset) / (g.grid[0] - 1.0)
    bar_sp_y = (2 * hh - 2 * g.bar_offset) / (g.grid[1] - 1.0)
    iw = 2 * (hw - (g.bar_offset + bar_sp_x - g.inner_corr))
    ih = 2 * (hh - (g.bar_offset + bar_sp_y - g.inner_corr))

    def _mk_stirrup(w, h2):
        pts = stirrup_pts(cx - w / 2.0, cy - h2 / 2.0,
                          cx + w / 2.0, cy + h2 / 2.0, g)
        return {"kind": "stirrup_poly", "pts": pts,
                "layer": "S-REIN", "width": g.stirrup_w}

    stirrups = [
        _mk_stirrup(sw, sh),
        _mk_stirrup(iw, sh),
        _mk_stirrup(sw, ih),
    ]

    # 5) 纵筋点（外圈布置，circle 样式实心圆点）
    groups = parse_rebar(rebar)
    if not groups:
        raise ValueError("无法解析纵筋: %s" % rebar)
    total = sum(c for c, _ in groups)
    dia = groups[0][1]
    positions = edge_positions(cx, cy, hw, hh, g.bar_offset, total)
    bars = [(px, py) for px, py in positions]

    # 6) 尺寸标注（DIM100，底边向下 666.7、右边向右 666.7，文本=实际截面）
    dims = [
        {"kind": "hdim", "x1": left, "y1": bottom, "x2": right,
         "y2": bottom, "text": str(b), "layer": "S-DIM",
         "offset": g.dim_offset, "distance": -g.dim_offset},
        {"kind": "vdim", "x1": right, "y1": bottom, "x2": right,
         "y2": top, "text": str(h), "layer": "S-DIM",
         "offset": g.dim_offset},
    ]

    # 7) 角部引出线 + 顶部/左侧边部文字（模板只有一条引出线）
    ld = g.leader
    leaders = []
    side_dia = groups[1][1] if len(groups) > 1 else dia
    n_per_side = max(0, (total - 4) // 4)
    if leader and total >= 4:
        leaders.append({
            "points": [(right, top),
                       (right + ld["line_dx"], top + ld["line_dy"])],
            "text": f"角部4%%132{dia}",
            "text_xy": (right + ld["text_dx"], top + ld["text_dy"]),
            "layer": "S-COLU_DE_TEXT", "align": "left", "rotation": 0.0,
        })
    if n_per_side >= 1:
        texts.append({
            "txt": f"{n_per_side}%%132{side_dia}",
            "x": cx, "y": cy + hh + ld["top_dy"], "h": g.h_detail,
            "layer": "S-COLU_DE_TEXT", "align": "center", "rotation": 0.0,
        })
        texts.append({
            "txt": f"{n_per_side}%%132{side_dia}",
            "x": cx - hw + ld["left_dx"], "y": cy, "h": g.h_detail,
            "layer": "S-COLU_DE_TEXT", "align": "center", "rotation": 90.0,
        })

    return {
        "outline": outline, "fill": None, "stirrups": stirrups,
        "bars": bars, "dims": dims, "frame_dims": [],
        "frame_lines": frame_lines, "frame_poly": frame_poly,
        "table_lines": table_lines, "table_rows": table_rows,
        "texts": texts, "leaders": leaders,
        "groups": groups,
        "meta": {
            "b": b, "h": h, "total": total, "dia": dia,
            "BW": 2 * hw, "BH": 2 * hh, "cx": cx, "cy": cy,
            "scale": g.scale, "frame": True,
            "fbbox": (dx, dy, g.frame_w + dx, g.frame_h + dy),
            "frame_w": g.frame_w, "frame_h": g.frame_h,
            "row_h": 0, "n_rows": 0, "fcx": g.frame_w / 2.0 + dx,
            "fcy": g.frame_h / 2.0 + dy,
            "tpl": True,
            "bar_dot_style": g.dot_style,
            "bar_w": g.bar_w_base * dia / 20.0,
            "bar_scale": g.bar_scale,
        },
    }


def build_primitives(*, name, section, rebar, stirrup, level,
                     x=0.0, y=0.0, scale=DEFAULT_SCALE, cover=30.0,
                     frame=False,
                     frame_w=DEFAULT_FRAME_W, frame_h=DEFAULT_FRAME_H,
                     row_h=DEFAULT_ROW_H, n_rows=4, anchor="column",
                     leader=False, tpl=None):
    """返回一套图元，render_dxf / render_svg 各渲染一遍。"""
    b, h = parse_section(section)
    BW, BH = b * scale, h * scale
    cov = cover * scale

    # 模板式布局（--frame 且找到柱详图模板时）：按模板 geometry 逐点重放
    if frame and tpl is not None:
        return _build_template_layout(
            name=name, section=section, rebar=rebar, stirrup=stirrup,
            level=level, b=b, h=h, g=tpl, dx=x, dy=y, leader=leader)

    # ===== 决定外框/柱中心 =====
    if frame:
        table_h = n_rows * row_h
        section_h = frame_h - table_h
        if anchor == "frame":
            fcx, fcy = x, y
            cx = fcx
            cy = fcy + table_h / 2.0
        else:
            cx, cy = x, y
            fcx = cx
            fcy = cy - table_h / 2.0
        fbbox = (fcx - frame_w / 2, fcy - frame_h / 2,
                 fcx + frame_w / 2, fcy + frame_h / 2)
        table_top_y = fbbox[1] + n_rows * row_h
    else:
        cx, cy = x, y
        fcx, fcy = None, None
        fbbox = None
        table_top_y = None

    # 1) 截面轮廓（S-COLU_DE 层）
    outline = {"kind": "rect", "cx": cx, "cy": cy, "w": BW, "h": BH,
               "layer": "S-COLU_DE"}

    # 1.5) 截面实心填充（S-REIN 层，红色，画在箍筋/钢筋点之下）
    fill = None

    # 2) 复合箍筋（S-REIN 层，3 组：外箍 + 内箍竖 + 内箍横）
    sw, sh = BW - 2 * cov, BH - 2 * cov

    def _mk_stirrup(w, h):
        """生成 12 点箍筋多段线（含 135° 弯钩，对齐模板）。"""
        a, b = w / 2.0, h / 2.0
        br_x, br_y = cx + a, cy - b
        pts = [
            (br_x - HOOK_DIAG, br_y + HOOK_DIAG),    # 0: 弯钩起点
            (br_x, br_y),                              # 1: 角部
            (br_x + HOOK_EXT, br_y),                   # 2: 向外延伸
            (br_x + HOOK_EXT, br_y + HOOK_EXT),        # 3: 向上
            (br_x, br_y),                              # 4: 返回角部
            (br_x, cy + b),                            # 5: 右上角
            (cx - a, cy + b),                          # 6: 左上角
            (cx - a, br_y),                            # 7: 左下角
            (br_x, br_y),                              # 8: 返回右下角
            (br_x + HOOK_EXT, br_y),                   # 9: 向外延伸
            (br_x + HOOK_EXT, br_y + HOOK_EXT),        # 10: 向上
            (br_x - HOOK_DIAG, br_y + HOOK_DIAG),      # 11: 弯钩终点
        ]
        return {"kind": "stirrup_poly", "pts": pts,
                "layer": "S-REIN", "width": STIRRUP_W}

    stirrups = [
        _mk_stirrup(sw, sh),              # 外箍
        _mk_stirrup(sw / 3.0, sh),        # 内箍竖（窄）
        _mk_stirrup(sw, sh / 3.0),        # 内箍横（矮）
    ]

    # 3) 纵筋点（S-REIN 层，3 点多段线 bulge=1）
    groups = parse_rebar(rebar)
    if not groups:
        raise ValueError("无法解析纵筋: %s" % rebar)
    total = sum(c for c, _ in groups)
    dia = groups[0][1]
    diameter_list = build_diameter_list(groups)

    bar_in = cov + BAR_INSET
    pos = [
        (cx - BW / 2.0 + bar_in, cy - BH / 2.0 + bar_in),
        (cx + BW / 2.0 - bar_in, cy - BH / 2.0 + bar_in),
        (cx + BW / 2.0 - bar_in, cy + BH / 2.0 - bar_in),
        (cx - BW / 2.0 + bar_in, cy + BH / 2.0 - bar_in),
    ]
    remain = total - 4
    if remain > 0:
        n_per = max(1, remain // 4)
        span_w, span_h = BW - 2 * bar_in, BH - 2 * bar_in
        for i in range(n_per):
            t = (i + 1.0) / (n_per + 1.0)
            pos.append((cx - BW / 2.0 + bar_in + t * span_w,
                        cy - BH / 2.0 + bar_in))
            pos.append((cx - BW / 2.0 + bar_in + t * span_w,
                        cy + BH / 2.0 - bar_in))
            pos.append((cx - BW / 2.0 + bar_in,
                        cy - BH / 2.0 + bar_in + t * span_h))
            pos.append((cx + BW / 2.0 - bar_in,
                        cy - BH / 2.0 + bar_in + t * span_h))
    bars = [(px, py) for (px, py) in pos[:total]]

    # 4) 柱尺寸标注（S-DIM 层）
    left, right = cx - BW / 2.0, cx + BW / 2.0
    bottom, top = cy - BH / 2.0, cy + BH / 2.0
    off = DIM_OFFSET_MM * scale
    dims = [
        {"kind": "hdim", "x1": left, "y1": bottom, "x2": right, "y2": bottom,
         "text": str(b), "layer": "S-DIM", "offset": off},
        {"kind": "vdim", "x1": right, "y1": bottom, "x2": right, "y2": top,
         "text": str(h), "layer": "S-DIM", "offset": off},
    ]

    # 5) 外框 + 表行 + 外框尺寸
    frame_dims = []
    table_rows = []
    leaders = []
    if frame:
        fx1, fy1, fx2, fy2 = fbbox
        frame_lines = [
            (fx1, fy1, fx2, fy1), (fx2, fy1, fx2, fy2),
            (fx2, fy2, fx1, fy2), (fx1, fy2, fx1, fy1),
        ]
        table_lines = []
        for i in range(1, n_rows):
            y = fy1 + i * row_h
            table_lines.append((fx1, y, fx2, y))
        # 柱表文字：第 1 行 KZ-3 → S-TAB_TEXT h=450；其余 → S-PUB_TEXT h=300
        stirrup_text = normalize_phi(stirrup)
        rows = [name, level, normalize_phi(rebar), stirrup_text]
        while len(rows) < n_rows:
            rows.append("")
        rows = rows[:n_rows]
        table_rows = []
        for i, txt in enumerate(rows):
            row_cy = fy2 - (i + 0.5) * row_h
            if i == 0:
                table_rows.append((txt, fcx, row_cy, "S-TAB_TEXT", TAB_NAME_H))
            else:
                table_rows.append((txt, fcx, row_cy, "S-PUB_TEXT", TAB_TXT_H))
        # 外框尺寸
        frame_dims = [
            {"kind": "hdim", "x1": fx1, "y1": fy2, "x2": fx2, "y2": fy2,
             "text": str(int(frame_w)), "layer": "S-DIM", "offset": off * 0.5},
            {"kind": "vdim", "x1": fx1, "y1": table_top_y, "x2": fx1, "y2": fy2,
             "text": str(int(section_h)), "layer": "S-DIM", "offset": off * 0.5},
        ]
        for i in range(1, n_rows + 1):
            y1 = fy1 + (i - 1) * row_h
            y2 = fy1 + i * row_h
            frame_dims.append({
                "kind": "vdim", "x1": fx1 - off * 0.9, "y1": y1,
                "x2": fx1 - off * 0.9, "y2": y2,
                "text": str(int(row_h)), "layer": "S-DIM", "offset": 0,
            })
        # 引出线（S-COLU_DE_TEXT 层，%%132）
        if leader and total >= 4:
            corner_txt = f"角部4%%132{dia}"
            side_dia = groups[1][1] if len(groups) > 1 else dia
            n_per_side = max(0, (total - 4) // 4)
            side_txt = f"每边{n_per_side}%%132{side_dia}"
            leaders.append({
                "points": [(right, top), (right + off * 0.6, top + off * 0.6),
                           (right + off * 0.6 + 400, top + off * 0.6)],
                "text": corner_txt,
                "text_xy": (right + off * 0.6 + 500, top + off * 0.6),
                "layer": "S-COLU_DE_TEXT",
            })
            if n_per_side >= 1:
                leaders.append({
                    "points": [(cx, top), (cx, top + off * 0.6),
                               (cx + 400, top + off * 0.6)],
                    "text": side_txt,
                    "text_xy": (cx + 500, top + off * 0.6),
                    "layer": "S-COLU_DE_TEXT",
                })
            if n_per_side >= 1 and total >= 8:
                leaders.append({
                    "points": [(left, cy), (left - off * 0.6, cy),
                               (left - off * 0.6 - 400, cy)],
                    "text": side_txt,
                    "text_xy": (left - off * 0.6 - 1500, cy),
                    "layer": "S-COLU_DE_TEXT",
                })
    else:
        frame_lines = []
        table_lines = []

    return {
        "outline": outline, "fill": fill, "stirrups": stirrups, "bars": bars,
        "dims": dims, "frame_dims": frame_dims,
        "frame_lines": frame_lines, "table_lines": table_lines,
        "table_rows": table_rows, "leaders": leaders,
        "groups": groups,
        "meta": {
            "b": b, "h": h, "total": total, "dia": dia,
            "BW": BW, "BH": BH, "cx": cx, "cy": cy, "scale": scale,
            "frame": frame, "fbbox": fbbox, "frame_w": frame_w, "frame_h": frame_h,
            "row_h": row_h, "n_rows": n_rows, "fcx": fcx, "fcy": fcy,
        },
    }


# ============================================================
# DXF 渲染
# ============================================================
def _add_rect(msp, cx, cy, w, h, layer, closed=True):
    a, b = w / 2.0, h / 2.0
    pts = [(cx - a, cy - b), (cx + a, cy - b), (cx + a, cy + b), (cx - a, cy + b)]
    msp.add_lwpolyline(pts, dxfattribs={"layer": layer, "closed": closed})


def _add_text(msp, txt, x, y, h, layer, align="left", rotation=0.0,
              style="TSSD_Rein"):
    al = {"left": TextEntityAlignment.LEFT,
          "center": TextEntityAlignment.MIDDLE_CENTER,
          "right": TextEntityAlignment.RIGHT}[align]
    t = msp.add_text(str(txt), dxfattribs={
        "layer": layer, "height": h, "style": style, "rotation": rotation})
    t.set_placement((x, y), align=al)
    return t


def render_dxf(prims, doc):
    msp = doc.modelspace()
    # 轮廓
    o = prims["outline"]
    _add_rect(msp, o["cx"], o["cy"], o["w"], o["h"], o["layer"])
    # 截面实心填充（红色 SOLID，画在箍筋/钢筋点之下）
    f = prims.get("fill")
    if f:
        fx1 = f["cx"] - f["w"] / 2.0
        fy1 = f["cy"] - f["h"] / 2.0
        fx2 = f["cx"] + f["w"] / 2.0
        fy2 = f["cy"] + f["h"] / 2.0
        msp.add_solid(
            [(fx1, fy1), (fx2, fy1), (fx1, fy2), (fx2, fy2)],
            dxfattribs={"layer": f["layer"]})
    # 箍筋（12 点多段线，const_width=40）
    for s in prims["stirrups"]:
        pts_with_bulge = [(p[0], p[1], 0, 0, 0) for p in s["pts"]]
        msp.add_lwpolyline(pts_with_bulge, dxfattribs={
            "layer": s["layer"], "const_width": s["width"]
        })
    # 纵筋点（模板 circle 样式：2 段 180° 弧闭合 + 恒定线宽 -> 实心圆点）
    _m = prims["meta"]
    _dot_style = _m.get("bar_dot_style", "segment")
    _bar_w = _m.get("bar_w", BAR_DOT_W)
    _bar_scale = _m.get("bar_scale", 1.0)
    for (px, py) in prims["bars"]:
        if _dot_style == "circle":
            _R = (_bar_w / 2.0) * _bar_scale
            _d = _R / 2.0
            msp.add_lwpolyline(
                [(px - _d, py, 0, 0, 1.0), (px + _d, py, 0, 0, 1.0)],
                close=True,
                dxfattribs={"layer": "S-REIN", "const_width": _R,
                            "color": 0})
        else:
            r = _bar_w / 2.0
            msp.add_lwpolyline(
                [(px + r, py, 0, 0, 1.0), (px - r, py, 0, 0, 1.0),
                 (px + r, py, 0, 0, 1.0)],
                dxfattribs={"layer": "S-REIN", "const_width": _bar_w,
                            "color": 0})
    # 外框（S-TAB 层：模板式为闭合多段线，旧版为 4 条直线）
    _fp = prims.get("frame_poly")
    if _fp:
        msp.add_lwpolyline(_fp, close=True, dxfattribs={"layer": "S-TAB"})
    else:
        for (x1, y1, x2, y2) in prims["frame_lines"]:
            msp.add_line((x1, y1), (x2, y2), dxfattribs={"layer": "S-TAB"})
    # 表行分隔（S-TAB 层）
    for (x1, y1, x2, y2) in prims["table_lines"]:
        msp.add_line((x1, y1), (x2, y2), dxfattribs={"layer": "S-TAB"})
    # 柱表文字（KZ-3 → S-TAB_TEXT h=450；其余 → S-PUB_TEXT h=300）
    for (txt, x, y, layer, h) in prims["table_rows"]:
        _add_text(msp, txt, x, y, h, layer, align="center")
    # 标题 / 边部文字（模板式，支持对齐与旋转）
    for t in prims.get("texts", []):
        _add_text(msp, t["txt"], t["x"], t["y"], t["h"], t["layer"],
                  align=t.get("align", "left"),
                  rotation=t.get("rotation", 0.0))
    # 柱尺寸标注（S-DIM 层）
    for d in prims["dims"]:
        x1, y1, x2, y2 = d["x1"], d["y1"], d["x2"], d["y2"]
        # ezdxf ? distance ??????????????????????
        dim = msp.add_aligned_dim(
            p1=(x1, y1), p2=(x2, y2), distance=d.get("distance", -d["offset"]),
            text=str(d["text"]), dimstyle="DIM100",
            dxfattribs={"layer": d["layer"]})
        dim.render()
    # 外框尺寸
    for d in prims["frame_dims"]:
        x1, y1, x2, y2 = d["x1"], d["y1"], d["x2"], d["y2"]
        if d["offset"] > 0:
            dim = msp.add_aligned_dim(
                p1=(x1, y1), p2=(x2, y2), distance=d["offset"],
                text=str(d["text"]), dimstyle="DIM100",
                dxfattribs={"layer": d["layer"]})
            dim.render()
        else:
            dim = msp.add_linear_dim(
                base=(x1 - 100, (y1 + y2) / 2),
                p1=(x1, y1), p2=(x2, y2), dimstyle="DIM100",
                dxfattribs={"layer": d["layer"]})
            try:
                dim.render()
            except Exception:
                pass
    # 引出线（S-COLU_DE_TEXT 层，绿色覆盖）
    for L in prims["leaders"]:
        pts = L["points"]
        for i in range(len(pts) - 1):
            ln = msp.add_line(pts[i], pts[i + 1],
                              dxfattribs={"layer": L["layer"]})
            ln.dxf.color = 3
        tx, ty = L["text_xy"]
        t = _add_text(msp, L["text"], tx, ty, TXT_H, L["layer"], align="left")
        t.dxf.color = 3
    return msp


def finalize_view(doc, margin_ratio=0.06, aspect=1.78):
    msp = doc.modelspace()
    ext = _extents(msp, fast=False)
    if not ext.has_data:
        print("WARN: modelspace empty, skip finalize_view")
        return
    minx, miny = ext.extmin.x, ext.extmin.y
    maxx, maxy = ext.extmax.x, ext.extmax.y
    w, h = maxx - minx, maxy - miny
    mx, my = w * margin_ratio, h * margin_ratio
    lo = (minx - mx, miny - my)
    hi = (maxx + mx, maxy + my)
    msp.dxf.extmin = (lo[0], lo[1], 0.0)
    msp.dxf.extmax = (hi[0], hi[1], 0.0)
    msp.dxf.limmin = lo
    msp.dxf.limmax = hi
    ccx, ccy = (minx + maxx) / 2.0, (miny + maxy) / 2.0
    view_h = max(h * (1 + 2 * margin_ratio),
                 w * (1 + 2 * margin_ratio) / aspect)
    for vp in doc.viewports.get("*Active"):
        vp.dxf.center = (ccx, ccy)
        vp.dxf.height = view_h
        vp.dxf.aspect_ratio = aspect
    print("  extents: (%.0f,%.0f) - (%.0f,%.0f)  size %.0f x %.0f"
          % (minx, miny, maxx, maxy, w, h))


# ============================================================
# SVG 预览渲染
# ============================================================
def render_svg(prims, path):
    m = prims["meta"]
    xs, ys = [], []
    for p in prims["bars"]:
        xs.append(p[0]); ys.append(p[1])
    o = prims["outline"]
    xs += [o["cx"] - o["w"] / 2, o["cx"] + o["w"] / 2]
    ys += [o["cy"] - o["h"] / 2, o["cy"] + o["h"] / 2]
    for d in prims["dims"]:
        xs += [d["x1"], d["x2"]]
        ys += [d["y1"], d["y2"]]
        if d["kind"] == "hdim":
            ys.append(d["y1"] - d["offset"])
        else:
            xs.append(d["x1"] + d["offset"])
    if m["frame"] and m["fbbox"]:
        fx1, fy1, fx2, fy2 = m["fbbox"]
        xs += [fx1, fx2]; ys += [fy1, fy2]
    for L in prims["leaders"]:
        for (x, y) in L["points"]:
            xs.append(x); ys.append(y)
        tx, ty = L["text_xy"]
        xs.append(tx + 800); ys.append(ty)
    minx, maxx = min(xs) - 300, max(xs) + 300
    miny, maxy = min(ys) - 300, max(ys) + 300
    W = maxx - minx
    H = maxy - miny
    s = 900.0 / max(W, H)
    pad = 20
    vw = W * s + 2 * pad
    vh = H * s + 2 * pad

    def tx(x):
        return pad + (x - minx) * s

    def ty(y):
        return pad + (maxy - y) * s

    LAYER_COLOR = {
        "S-COLU_DE": "#0000ff", "S-REIN": "#ff0000",
        "S-TAB": "#666666", "S-TAB_TEXT": "#000000",
        "S-PUB_TEXT": "#000000", "S-COLU_DE_TEXT": "#333333",
        "S-DIM": "#00aa00",
    }

    parts = ['<svg xmlns="http://www.w3.org/2000/svg" '
             'width="%g" height="%g" viewBox="0 0 %g %g">'
             % (vw, vh, vw, vh)]
    parts.append('<rect x="0" y="0" width="%g" height="%g" fill="#ffffff"/>'
                 % (vw, vh))
    lw = max(1.5, o["w"] * s * 0.012)

    # 轮廓
    x0, y0 = tx(o["cx"] - o["w"] / 2), ty(o["cy"] + o["h"] / 2)
    parts.append('<rect x="%g" y="%g" width="%g" height="%g" fill="none" '
                 'stroke="%s" stroke-width="%g"/>'
                 % (x0, y0, o["w"] * s, o["h"] * s,
                    LAYER_COLOR[o["layer"]], lw))
    # 截面实心填充（红色，画在箍筋/钢筋点之下）
    f = prims.get("fill")
    if f:
        fx0 = tx(f["cx"] - f["w"] / 2)
        fy0 = ty(f["cy"] + f["h"] / 2)
        parts.append('<rect x="%g" y="%g" width="%g" height="%g" '
                     'fill="#ff0000" fill-opacity="0.7"/>'
                     % (fx0, fy0, f["w"] * s, f["h"] * s))
    # 箍筋（12 点多段线 → 画矩形 + 弯钩）
    for st in prims["stirrups"]:
        pts = st["pts"]
        d_str = " ".join("%.1f,%.1f" % (tx(p[0]), ty(p[1])) for p in pts)
        sw_svg = max(1.5, st["width"] * s)
        parts.append('<polyline points="%s" fill="none" '
                     'stroke="%s" stroke-width="%g"/>'
                     % (d_str, LAYER_COLOR[st["layer"]], sw_svg))
    # 纵筋点（实心圆，黑色与红底对比；模板 circle 样式半径随直径缩放）
    bar_r = (m.get("bar_w", BAR_DOT_W) / 2.0
             * m.get("bar_scale", 1.0)) * s
    for (px, py) in prims["bars"]:
        parts.append('<circle cx="%g" cy="%g" r="%g" fill="#000000"/>'
                     % (tx(px), ty(py), bar_r))
    # 外框
    for (x1, y1, x2, y2) in prims["frame_lines"]:
        parts.append('<line x1="%g" y1="%g" x2="%g" y2="%g" stroke="%s" '
                     'stroke-width="2"/>'
                     % (tx(x1), ty(y1), tx(x2), ty(y2),
                        LAYER_COLOR["S-TAB"]))
    # 表行分隔
    for (x1, y1, x2, y2) in prims["table_lines"]:
        parts.append('<line x1="%g" y1="%g" x2="%g" y2="%g" stroke="%s" '
                     'stroke-width="1.2"/>'
                     % (tx(x1), ty(y1), tx(x2), ty(y2),
                        LAYER_COLOR["S-TAB"]))
    # 柱表文字（字高随模板行高缩放）
    for (txt, x, y, layer, h) in prims["table_rows"]:
        val = txt.replace("%%132", "Φ").replace("%%c", "Φ")
        font_size = max(14, min(40, int(h / 15.0)))
        parts.append('<text x="%g" y="%g" font-size="%d" fill="%s" '
                     'text-anchor="middle" dominant-baseline="middle">%s</text>'
                     % (tx(x), ty(y), font_size, LAYER_COLOR[layer], val))
    # 标题 / 边部文字（支持对齐与旋转）
    for t in prims.get("texts", []):
        val = t["txt"].replace("%%132", "Φ").replace("%%c", "Φ")
        anchor = "middle" if t.get("align") == "center" else "start"
        fs = max(14, min(40, int(t["h"] / 15.0)))
        rot = t.get("rotation", 0.0)
        rot_attr = ""
        if rot:
            rot_attr = ' transform="rotate(%g %g %g)"' % (
                -rot, tx(t["x"]), ty(t["y"]))
        parts.append('<text x="%g" y="%g" font-size="%d" fill="%s" '
                     'text-anchor="%s" dominant-baseline="middle"%s>%s</text>'
                     % (tx(t["x"]), ty(t["y"]), fs,
                        LAYER_COLOR[t["layer"]], anchor, rot_attr, val))
    # 柱尺寸
    for d in prims["dims"] + prims["frame_dims"]:
        col = LAYER_COLOR[d["layer"]]
        off = d["offset"]
        if d["kind"] == "hdim":
            x1, y1, x2, y2 = d["x1"], d["y1"], d["x2"], d["y2"]
            my = y1 - off if off > 0 else y1
            parts.append('<line x1="%g" y1="%g" x2="%g" y2="%g" stroke="%s" stroke-width="1"/>'
                         % (tx(x1), ty(y1), tx(x1), ty(my), col))
            parts.append('<line x1="%g" y1="%g" x2="%g" y2="%g" stroke="%s" stroke-width="1"/>'
                         % (tx(x2), ty(y2), tx(x2), ty(my), col))
            parts.append('<line x1="%g" y1="%g" x2="%g" y2="%g" stroke="%s" stroke-width="1"/>'
                         % (tx(x1), ty(my), tx(x2), ty(my), col))
            parts.append('<text x="%g" y="%g" font-size="14" fill="%s" '
                         'text-anchor="middle">%s</text>'
                         % (tx((x1 + x2) / 2.0), ty(my) + 5, col, d["text"]))
        else:
            x1, y1, x2, y2 = d["x1"], d["y1"], d["x2"], d["y2"]
            mx = x1 + off if off > 0 else x1
            parts.append('<line x1="%g" y1="%g" x2="%g" y2="%g" stroke="%s" stroke-width="1"/>'
                         % (tx(x1), ty(y1), tx(mx), ty(y1), col))
            parts.append('<line x1="%g" y1="%g" x2="%g" y2="%g" stroke="%s" stroke-width="1"/>'
                         % (tx(x2), ty(y2), tx(mx), ty(y2), col))
            parts.append('<line x1="%g" y1="%g" x2="%g" y2="%g" stroke="%s" stroke-width="1"/>'
                         % (tx(mx), ty(y1), tx(mx), ty(y2), col))
            text_x = tx(mx + 30) if off > 0 else tx(mx - 30)
            parts.append('<text x="%g" y="%g" font-size="14" fill="%s" '
                         'text-anchor="middle" transform="rotate(-90 %g %g)">%s</text>'
                         % (text_x, ty((y1 + y2) / 2.0), col,
                            text_x, ty((y1 + y2) / 2.0), d["text"]))
    # 引出线（绿色，对齐参考图）
    for L in prims["leaders"]:
        pts = L["points"]
        for i in range(len(pts) - 1):
            parts.append('<line x1="%g" y1="%g" x2="%g" y2="%g" stroke="%s" '
                         'stroke-width="1"/>'
                         % (tx(pts[i][0]), ty(pts[i][1]),
                            tx(pts[i + 1][0]), ty(pts[i + 1][1]),
                            "#00aa00"))
        tx2, ty2 = L["text_xy"]
        val = L["text"].replace("%%132", "Φ").replace("%%c", "Φ")
        parts.append('<text x="%g" y="%g" font-size="14" fill="#00aa00">%s</text>'
                     % (tx(tx2), ty(ty2), val))
    parts.append('</svg>')
    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(parts))


# ============================================================
# 主流程
# ============================================================
def main():
    ap = argparse.ArgumentParser(description="柱配筋截面详图离线 DXF 生成器（对齐模板 zhuzi.dxf）")
    ap.add_argument("--name", default="KZ-3", help="柱编号")
    ap.add_argument("--section", required=True, help="截面尺寸，如 500x500")
    ap.add_argument("--rebar", required=True,
                    help="纵筋，如 '8C25+4C20'（C=Φ=HRB400）")
    ap.add_argument("--stirrup", required=True, help="箍筋，如 'C8@100/200'")
    ap.add_argument("--level", default="（详见柱表）", help="标高范围")
    ap.add_argument("--frame", action="store_true",
                    help="画柱表外框 + 底部 4 行参数表")
    ap.add_argument("--frame-w", type=float, default=DEFAULT_FRAME_W,
                    help="外框宽（默认 7700）")
    ap.add_argument("--frame-h", type=float, default=DEFAULT_FRAME_H,
                    help="外框总高（默认 10700）")
    ap.add_argument("--row-h", type=float, default=DEFAULT_ROW_H,
                    help="柱表行高（默认 800）")
    ap.add_argument("--n-rows", type=int, default=4, help="柱表行数")
    ap.add_argument("--anchor", choices=["column", "frame"], default="column",
                    help="(x,y) 语义：column=柱中心（默认），frame=外框中心")
    ap.add_argument("--leader", action="store_true",
                    help="画角部/边部引出线（默认不画）")
    ap.add_argument("--no-leader", action="store_true",
                    help="不画角部/边部引出线（兼容）")
    ap.add_argument("--template", default=None,
                    help="柱详图模板名/路径关键字（默认自动匹配 600 柱详图）")
    ap.add_argument("--x", type=float, default=0.0, help="X")
    ap.add_argument("--y", type=float, default=0.0, help="Y")
    ap.add_argument("--scale", type=float, default=DEFAULT_SCALE,
                    help="放大倍数（默认 10/3≈3.33，对齐模板）")
    ap.add_argument("--cover", type=float, default=30.0,
                    help="保护层 mm（默认 30，对齐模板）")
    ap.add_argument("--out", default=None, help="DXF 输出路径")
    args = ap.parse_args()

    # 模板式布局：--frame 时自动读取 templates/ 下的柱详图模板几何
    tpl = None
    tpath = None
    if args.frame:
        try:
            tpath, tdata = find_template(args.section, args.template)
            tpl = Geom(tdata)
            print("模板: %s" % tpath)
        except SystemExit as e:
            if args.template:
                raise
            print("WARN: %s（回退旧版布局）" % e)
    if tpl is not None:
        # 模板式出图默认带角部引出线与边部文字（与实时版一致），--no-leader 可关
        args.leader = not args.no_leader
    else:
        args.leader = args.leader and not args.no_leader

    if args.out:
        out = os.path.abspath(args.out)
    else:
        base = os.path.dirname(os.path.abspath(__file__))
        out_dir = os.path.normpath(os.path.join(base, "..", "..", "output"))
        if not os.path.isdir(out_dir):
            out_dir = os.path.join(base, "output")
        os.makedirs(out_dir, exist_ok=True)
        out = os.path.join(out_dir, "柱表_%s_%s.dxf" % (args.name, args.section))
    svg_out = os.path.splitext(out)[0] + ".svg"

    doc = ezdxf.new("R2000", setup=True)
    STD.apply_to_ezdxf(doc)

    prims = build_primitives(
        name=args.name, section=args.section, rebar=args.rebar,
        stirrup=args.stirrup, level=args.level,
        x=args.x, y=args.y, scale=args.scale, cover=args.cover,
        frame=args.frame, frame_w=args.frame_w, frame_h=args.frame_h,
        row_h=args.row_h, n_rows=args.n_rows, anchor=args.anchor,
        leader=args.leader, tpl=tpl)

    render_dxf(prims, doc)
    finalize_view(doc)
    doc.dxfversion = "AC1015"
    doc.saveas(out)
    render_svg(prims, svg_out)

    m = prims["meta"]
    print("柱表详图 %s 已生成：" % args.name)
    print("  DXF : %s" % out)
    print("  SVG : %s" % svg_out)
    rebar_disp = "+".join("%dΦ%d" % (c, d) for c, d in prims["groups"])
    print("  截面 %s，纵筋 %s，箍筋 %s，放大 %.2f 倍"
          % (args.section, rebar_disp,
             normalize_phi(args.stirrup), args.scale))
    if m["frame"]:
        if m.get("tpl"):
            print("  模板式柱表：外框 %.0f×%.0f（标题行+截面区+四行柱表），"
                  "截面中心 (%.0f, %.0f)"
                  % (m["frame_w"], m["frame_h"], m["cx"], m["cy"]))
        else:
            print("  外框 %.0f×%.0f，行数 %d，行高 %.0f" % (
                m["frame_w"], m["frame_h"], m["n_rows"], m["row_h"]))
    if tpath:
        print("  模板 : %s" % tpath)
    print("OFFLINE_DXF=OK")


if __name__ == "__main__":
    main()
