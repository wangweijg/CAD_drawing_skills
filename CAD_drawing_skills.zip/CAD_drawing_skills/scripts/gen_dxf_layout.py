# -*- coding: utf-8 -*-
"""可复用的结构平面布置图生成器（22G101 平法 · 对齐真实模板标准）。

只画：轴网 + 轴号 + 两级尺寸 + 框架柱（可选填充）+ 框架梁（双线轮廓）。
不画板筋/配筋/柱详图/图签——这些按需由其它脚本叠加。

用法：
    python gen_dxf_layout.py                # 用下方默认参数（4000x6 + 5000x2 等）
    python gen_dxf_layout.py --x-gap 4000 --x-spans 6 --y-gap 5000 --y-spans 2 \
        --col 400x500 --edge 250x400 --internal 200x400 --no-fill

关键实现要点（详见 SKILL.md）：
- 字体 GBENOR+GBCBIG（CAD 自带，无第三方插件字体）
- 标注 dimtsz=0.5 建筑斜线，不依赖 _ArchTick 块
- 图层线型 S-DOTE 用 DOTE 点划线（cad_standards.apply_to_ezdxf 已注册定义；非纯标准名但 CAD 可加载）
- 收尾必须 finalize_view()，否则 CAD 打开一片空白
- 只输出 R2000(AC1015)
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import ezdxf
import cad_standards as STD

# ============================================================
# 参数（按需修改；也可命令行覆盖）
# ------------------------------------------------------------
X_SPANS = 6            # X 向跨数
X_GAP = 4000           # X 向每跨尺寸 mm
Y_SPANS = 2            # Y 向跨数
Y_GAP = 5000           # Y 向每跨尺寸 mm
COL_W, COL_H = 400, 500    # 矩形柱截面 b×h（X 向 b，Y 向 h）
FILL_COL = False       # 柱实心填充（王工本次要求不填充）
EDGE_BEAM = (250, 600)     # 边跨梁 b×h（与柱外边对齐，2026-09-08）
INTERNAL_BEAM = (200, 400) # 内部梁 b×h
TITLE = "结构平面布置图"

# 命令行覆盖
for k in range(1, len(sys.argv)):
    a = sys.argv[k]
    if a == "--x-spans":
        X_SPANS = int(sys.argv[k + 1])
    elif a == "--x-gap":
        X_GAP = int(sys.argv[k + 1])
    elif a == "--y-spans":
        Y_SPANS = int(sys.argv[k + 1])
    elif a == "--y-gap":
        Y_GAP = int(sys.argv[k + 1])
    elif a == "--col":
        COL_W, COL_H = (int(v) for v in sys.argv[k + 1].lower().split("x"))
    elif a == "--edge":
        EDGE_BEAM = tuple(int(v) for v in sys.argv[k + 1].lower().split("x"))
    elif a == "--internal":
        INTERNAL_BEAM = tuple(int(v) for v in sys.argv[k + 1].lower().split("x"))
    elif a == "--no-fill":
        FILL_COL = False
    elif a == "--fill":
        FILL_COL = True

# 轴坐标
XS = [i * X_GAP for i in range(X_SPANS + 1)]
YS = [i * Y_GAP for i in range(Y_SPANS + 1)]
XNUM = STD.axis_labels(len(XS), kind="number")
YNUM = STD.axis_labels(len(YS), kind="letter")
COL_HX, COL_HY = COL_W / 2.0, COL_H / 2.0

# 轴网几何标准（取自 cad_standards，保证与实时画一致）
AXIS_R = STD.AXIS_R
AXIS_H = STD.AXIS_H
DIM1 = STD.DIM1
DIM2 = STD.DIM2
AXIS_ENDOFF = STD.AXIS_ENDOFF
AXIS_CENTER = STD.AXIS_CENTER

# 输出路径：技能包 output/ 目录
_ROOT = os.path.dirname(os.path.abspath(__file__))
OUT_DIR = os.path.join(_ROOT, os.pardir, "output")
os.makedirs(OUT_DIR, exist_ok=True)
OUT = os.path.normpath(
    os.path.join(OUT_DIR, f"结构平面布置图_{X_GAP}x{X_SPANS}_{Y_GAP}x{Y_SPANS}_r2000.dxf")
)

doc = ezdxf.new("R2000", setup=True)
STD.apply_to_ezdxf(doc)
msp = doc.modelspace()


# ============================================================
# 通用绘图工具
# ============================================================
def aligned_dim(p1, p2, distance, text=""):
    dim = msp.add_aligned_dim(
        p1=p1, p2=p2, distance=distance,
        dimstyle=STD.DIMSTYLE_NAME, dxfattribs={"layer": "S-DIM"})
    if text:
        dim.set_text(text)
    dim.render()


def put_text(txt, x, y, layer, height, style="Standard", center=False, color=None):
    attr = {"layer": layer, "height": height, "style": style}
    if color is not None:
        attr["color"] = color
    t = msp.add_text(txt, dxfattribs=attr)
    x0 = x - len(txt) * height * 0.31 if center else x
    t.set_placement((x0, y))
    return t


# ============================================================
# 轴网 / 轴号 / 尺寸
# ============================================================
def draw_axis_grid(oy):
    for x in XS:
        msp.add_line((x, oy - AXIS_ENDOFF), (x, oy + YS[-1] + AXIS_ENDOFF),
                     dxfattribs={"layer": "S-DOTE"})
    for y in YS:
        msp.add_line((-AXIS_ENDOFF, oy + y), (XS[-1] + AXIS_ENDOFF, oy + y),
                     dxfattribs={"layer": "S-DOTE"})


def add_axis_text(text, x, y):
    t = msp.add_text(text, dxfattribs={
        "layer": "S-AXIS_TEXT", "height": AXIS_H,
        "style": "AXIS", "color": 7})
    t.set_placement((x - AXIS_H * 0.25 * len(text), y - AXIS_H * 0.35))


def draw_axis_marks(oy):
    for i, x in enumerate(XS):
        for y in [oy - AXIS_CENTER, oy + YS[-1] + AXIS_CENTER]:
            msp.add_circle((x, y), AXIS_R, dxfattribs={"layer": "S-AXIS"})
            add_axis_text(XNUM[i], x, y)
    for i, y in enumerate(YS):
        for x in [-AXIS_CENTER, XS[-1] + AXIS_CENTER]:
            msp.add_circle((x, oy + y), AXIS_R, dxfattribs={"layer": "S-AXIS"})
            add_axis_text(YNUM[i], x, oy + y)


def draw_dims(oy):
    top_y = oy + YS[-1]
    right_x = XS[-1]
    # 水平（底部）两道：内排分跨 + 外排总尺寸
    for i in range(len(XS) - 1):
        aligned_dim((XS[i], oy), (XS[i + 1], oy), -DIM1,
                    text=str(XS[i + 1] - XS[i]))
    aligned_dim((XS[0], oy), (XS[-1], oy), -DIM2, text=str(XS[-1] - XS[0]))
    # 水平（顶部）两道 —— 双侧标注
    for i in range(len(XS) - 1):
        aligned_dim((XS[i], top_y), (XS[i + 1], top_y), DIM1,
                    text=str(XS[i + 1] - XS[i]))
    aligned_dim((XS[0], top_y), (XS[-1], top_y), DIM2,
                text=str(XS[-1] - XS[0]))
    # 垂直（左侧）两道
    for i in range(len(YS) - 1):
        aligned_dim((0, oy + YS[i]), (0, oy + YS[i + 1]), DIM1,
                    text=str(YS[i + 1] - YS[i]))
    aligned_dim((0, oy + YS[0]), (0, oy + YS[-1]), DIM2,
                text=str(YS[-1] - YS[0]))
    # 垂直（右侧）两道 —— 双侧标注
    for i in range(len(YS) - 1):
        aligned_dim((right_x, oy + YS[i]), (right_x, oy + YS[i + 1]), -DIM1,
                    text=str(YS[i + 1] - YS[i]))
    aligned_dim((right_x, oy + YS[0]), (right_x, oy + YS[-1]), -DIM2,
                text=str(YS[-1] - YS[0]))


# ============================================================
# 框架柱（矩形，可选填充）
# ============================================================
def add_column(cx, cy, w, h, tag=None, fill=FILL_COL):
    hx, hy = w / 2.0, h / 2.0
    pts = [(cx - hx, cy - hy), (cx + hx, cy - hy),
           (cx + hx, cy + hy), (cx - hx, cy + hy), (cx - hx, cy - hy)]
    if fill:
        hatch = msp.add_hatch(dxfattribs={"layer": "S-COLU_HATCH"})
        hatch.paths.add_polyline_path(pts, is_closed=True)
    msp.add_lwpolyline(pts, dxfattribs={"layer": "S-COLU", "closed": True})




column_tags = [[f"KZ-{1 + r * len(XS) + c}" for c in range(len(XS))]
               for r in range(len(YS))]
column_tags = list(reversed(column_tags))  # 从 A 排到 C（下→上）


def draw_columns(oy, with_num=True):
    # 柱：名称+截面 一行，标在柱右上角（KZ-n 500×500）
    for r, y in enumerate(YS):
        for c, x in enumerate(XS):
            tag = column_tags[r][c] if with_num else None
            add_column(x, oy + y, COL_W, COL_H, tag)
            if with_num:
                sname = f"{int(COL_W)}×{int(COL_H)}"
                label = f"{tag} {sname}"
                # 柱右上角：柱右上角点 (x+hx, y+hy) 之外，文字左对齐+水平
                t = msp.add_text(label, dxfattribs={"layer": "S-COLU_NUM",
                                                    "height": 200, "style": "AXIS"})
                t.set_placement((x + COL_HX + 100, oy + y + COL_HY + 120))


# ============================================================
# 框架梁（双线，柱处断开；边跨/内部跨不同梁宽）+ 梁名称/截面标注
# ============================================================
AT_BEAM = {"layer": "S-BEAM_CON"}
B_LABEL = {"layer": "S-BEAM_TEXT", "height": 220}


def _beam_label(msp, txt, x, y, center=True, rotation=0):
    attr = dict(B_LABEL)
    if rotation:
        attr["rotation"] = rotation
    t = msp.add_text(txt, dxfattribs=attr)
    if center:
        t.set_placement((x - 90 * len(txt), y))
    else:
        t.set_placement((x, y))
    return t


def _seg(th, i, n):
    """返回第 i 段的梁宽/高：边跨(首/末)用 EDGE，中间跨用 INTERNAL。（保留接口，供调用）"""
    edge = (i == 0 or i == n - 1)
    bw = EDGE_BEAM[0] if edge else INTERNAL_BEAM[0]
    bh = EDGE_BEAM[1] if edge else INTERNAL_BEAM[1]
    return bw, bh


def _edge_section(is_edge):
    """按轴线是否最外侧(边跨梁)返回截面：外侧用 EDGE_BEAM，内部用 INTERNAL_BEAM。"""
    if is_edge:
        return EDGE_BEAM
    return INTERNAL_BEAM


def draw_beams(oy):
    # 22G101-1 §4.2.1：梁集中标注每根梁一次，不逐跨重复。
    # 边跨梁=最外侧轴网上的所有梁（用 EDGE_BEAM，与柱外边对齐）；内部梁用 INTERNAL_BEAM。
    # 每道轴线标一个编号，KL 号唯一。
    kl = 0
    n_span = len(XS) - 1
    # 纵向轴线（Y 向）上的水平梁
    for y in YS:
        is_top = (y == YS[-1])
        is_bot = (y == YS[0])
        is_edge = is_top or is_bot
        bw, bh = _edge_section(is_edge)
        for i in range(n_span):            # 画所有跨
            ax, bx = XS[i] + COL_HX, XS[i + 1] - COL_HX
            # 外侧边跨梁：梁外边缘与柱外边对齐
            off = 0.0
            if is_bot:
                off = -(COL_H - bw) / 2.0
            elif is_top:
                off = (COL_H - bw) / 2.0
            cyc = oy + y + off
            if bx > ax:
                msp.add_line((ax, cyc - bw / 2), (bx, cyc - bw / 2), AT_BEAM)
                msp.add_line((ax, cyc + bw / 2), (bx, cyc + bw / 2), AT_BEAM)
        kl += 1
        cyc_lab = oy + y + ((COL_H - bw) / 2.0 if is_top else (-(COL_H - bw) / 2.0 if is_bot else 0.0))
        _beam_label(msp, f"KL{kl}({n_span}) {int(bw)}x{int(bh)}",
                    (XS[0] + XS[1]) / 2.0, cyc_lab + bw / 2.0 + 90)
    # 横向轴线（X 向）上的竖直梁
    m_span = len(YS) - 1
    for x in XS:
        is_left = (x == XS[0])
        is_right = (x == XS[-1])
        is_edge = is_left or is_right
        bw, bh = _edge_section(is_edge)
        for i in range(m_span):
            ay, by = YS[i] + COL_HY, YS[i + 1] - COL_HY
            off = 0.0
            if is_left:
                off = -(COL_W - bw) / 2.0
            elif is_right:
                off = (COL_W - bw) / 2.0
            xc = x + off
            if by > ay:
                msp.add_line((xc - bw / 2, oy + ay), (xc - bw / 2, oy + by), AT_BEAM)
                msp.add_line((xc + bw / 2, oy + ay), (xc + bw / 2, oy + by), AT_BEAM)
        kl += 1
        xc_lab = x + ((COL_W - bw) / 2.0 if is_right else (-(COL_W - bw) / 2.0 if is_left else 0.0))
        _beam_label(msp, f"KL{kl}({m_span}) {int(bw)}x{int(bh)}",
                    xc_lab + bw / 2.0 + 200, oy + (YS[0] + YS[1]) / 2.0,
                    center=False, rotation=90)


# ============================================================
# 图名（写在图的下方）
# ============================================================
def draw_plan_title(oy):
    name = TITLE
    y = oy - AXIS_CENTER - 1700          # 图名移到图的下方（底部轴圈之下）
    tit_h = 500
    x0 = XS[-1] / 2 - len(name) * tit_h * 0.45
    put_text(name, x0, y, "S-TEXT", tit_h)
    w = len(name) * tit_h * 0.9
    msp.add_line((x0, y - 200), (x0 + w, y - 200), dxfattribs={"layer": "S-TEXT"})
    put_text("1:100", x0 + w + 300, y, "S-TEXT", int(tit_h * 0.7))
    put_text(f"梁：边跨 {int(EDGE_BEAM[0])}x{int(EDGE_BEAM[1])}  中间 {int(INTERNAL_BEAM[0])}x{int(INTERNAL_BEAM[1])}   柱 {int(COL_W)}x{int(COL_H)}",
             x0, y - 480, "S-TEXT", int(tit_h * 0.55))


# ============================================================
# 组装
# ============================================================
OY = 0
draw_axis_grid(OY)
draw_axis_marks(OY)
draw_dims(OY)
draw_columns(OY, with_num=True)
draw_beams(OY)
draw_plan_title(OY)


# ============================================================
# 收尾：视图范围 + R2000
# ============================================================
def finalize_view(doc, margin_ratio=0.04, aspect=1.78):
    from ezdxf.bbox import extents as _extents
    msp = doc.modelspace()
    ext = _extents(msp, fast=False)
    if not ext.has_data:
        print("WARN: modelspace empty, skip finalize_view")
        return
    minx, miny = ext.extmin.x, ext.extmin.y
    maxx, maxy = ext.extmax.x, ext.extmax.y
    w, h = maxx - minx, maxy - miny
    mx, my = w * margin_ratio, h * margin_ratio
    lo = (minx - mx, miny - my)
    hi = (maxx + mx, maxy + my)
    msp.dxf.extmin = (lo[0], lo[1], 0.0)
    msp.dxf.extmax = (hi[0], hi[1], 0.0)
    msp.dxf.limmin = lo
    msp.dxf.limmax = hi
    cx, cy = (minx + maxx) / 2.0, (miny + maxy) / 2.0
    view_h = max(h * (1 + 2 * margin_ratio), w * (1 + 2 * margin_ratio) / aspect)
    for vp in doc.viewports.get("*Active"):
        vp.dxf.center = (cx, cy)
        vp.dxf.height = view_h
        vp.dxf.aspect_ratio = aspect
    print(f"  extents: ({minx:.0f},{miny:.0f}) - ({maxx:.0f},{maxy:.0f})  "
          f"size {w:.0f} x {h:.0f}")
    print(f"  view center=({cx:.0f},{cy:.0f}) height={view_h:.0f}")


finalize_view(doc)
doc.dxfversion = "AC1015"
doc.saveas(OUT)
print("saved ->", OUT)
