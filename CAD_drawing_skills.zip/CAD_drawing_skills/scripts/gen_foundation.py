# -*- coding: utf-8 -*-
"""离线生成基础/桩基平法施工图 DXF（22G101-3）。

支持三种基础模式（--mode）：
  pile(默认) 桩承台：每柱位 承台 CT(S-FOUND) + 桩位圈(S-PILE) + 柱位(S-FOUND_INNER)
  dj         独立基础：每柱位 独立基础 DJ(底板矩形) + 柱位 + DJn 编号
  tj         条形基础：沿周边墙 条基 TJ + 内纵横TJ + TJA/TJB 编号

图面：上图=基础平面布置图+轴网尺寸；下图=详图（承台剖面+桩大样 / 独立基础详图 / 条基详图）。
图层：S-FOUND(轮廓) S-FOUND_INNER(柱位/台阶) S-FOUND_TEXT(编号) S-FOUND_REIN(配筋)
      S-FOUND_DIM(尺寸) S-PILE(桩圈) S-PILE_TEXT(桩编号)。
复用 cad_standards.apply_to_ezdxf() 单源标准 + TSSD_Rein 配筋字体。★轴网 gaps 全参数化。

用法：
  python gen_foundation.py --x-gaps 8400,8400,8400 --y-gaps 8400,8400,8400,8400
  python gen_foundation.py --mode dj --foot 2200
  python gen_foundation.py --mode tj --strip-w 1200
"""
import argparse
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import ezdxf
from cad_standards import apply_to_ezdxf, axis_labels

_BASE = os.path.dirname(os.path.abspath(__file__))
OUT = (os.environ.get("CAD_DXF_OUT") or
       os.path.normpath(os.path.join(_BASE, os.pardir, "output")))

AXIS_R = 350.0
AXIS_H = 280.0
DIM1 = 1500.0
DIM2 = DIM1 + 750.0
AXIS_CENTER = DIM2 + 500.0 + AXIS_R

X_GAPS = [3600.0, 4200.0, 4200.0, 3600.0]
Y_GAPS = [4200.0, 4800.0, 4200.0]
CT_SIZE = 2400.0
CT_H = 1200.0
PILE_R = 200.0
PILE_N = 4
PILE_PITCH = 1100.0
COL = 400.0
DJ_FOOT = 2200.0      # 独立基础边长
TJ_STRIP_W = 1200.0   # 条形基础宽


def finalize_view(doc, margin_ratio=0.04, aspect=1.78):
    from ezdxf.bbox import extents as _extents
    msp = doc.modelspace()
    ext = _extents(msp, fast=False)
    if not ext.has_data:
        print("WARN: empty, skip finalize_view"); return
    minx, miny = ext.extmin.x, ext.extmin.y
    maxx, maxy = ext.extmax.x, ext.extmax.y
    w, h = maxx - minx, maxy - miny
    mx, my = w * margin_ratio, h * margin_ratio
    msp.dxf.extmin = (minx - mx, miny - my, 0.0)
    msp.dxf.extmax = (maxx + mx, maxy + my, 0.0)
    msp.dxf.limmin = (minx - mx, miny - my)
    msp.dxf.limmax = (maxx + mx, maxy + my)
    cx, cy = (minx + maxx) / 2.0, (miny + maxy) / 2.0
    vh = max(h * (1 + 2 * margin_ratio), w * (1 + 2 * margin_ratio) / aspect)
    for vp in doc.viewports.get("*Active"):
        vp.dxf.center = (cx, cy); vp.dxf.height = vh; vp.dxf.aspect_ratio = aspect
    print("  extents: (%.0f,%.0f)-(%.0f,%.0f) size %.0f x %.0f" % (minx, miny, maxx, maxy, w, h))


def add_line(msp, a, b, layer):
    ln = msp.add_line((a[0], a[1], 0.0), (b[0], b[1], 0.0)); ln.dxf.layer = layer; return ln


def add_rect(msp, cx, cy, w, h, layer):
    x0, y0 = cx - w / 2.0, cy - h / 2.0
    add_line(msp, (x0, y0), (x0 + w, y0), layer)
    add_line(msp, (x0 + w, y0), (x0 + w, y0 + h), layer)
    add_line(msp, (x0 + w, y0 + h), (x0, y0 + h), layer)
    add_line(msp, (x0, y0 + h), (x0, y0), layer)


def add_text(msp, txt, x, y, h, layer, style="Standard", rot=0, center=False):
    t = msp.add_text(str(txt), dxfattribs={"height": h, "layer": layer, "style": style,
                                           "insert": (x, y), "rotation": rot})
    if center:
        t.dxf.halign = 1; t.dxf.valign = 1
    return t


def axis_draw(msp, xs, ys, xn, yn):
    xmax, ymax = xs[-1], ys[-1]
    for x in xs:
        add_line(msp, (x, -DIM1), (x, ymax + DIM2 + 500), "S-DOTE")
    for y in ys:
        add_line(msp, (-DIM1, y), (xmax + DIM2 + 500, y), "S-DOTE")
    for x, lab in zip(xs, xn):
        for cy in (-AXIS_CENTER, ymax + AXIS_CENTER):
            msp.add_circle((x, cy), AXIS_R, dxfattribs={"layer": "S-AXIS"})
            add_text(msp, lab, x, cy - AXIS_H / 2.0, AXIS_H, "S-AXIS_TEXT", style="AXIS", center=True)
    for y, lab in zip(ys, yn):
        for cx in (-AXIS_CENTER, xmax + AXIS_CENTER):
            msp.add_circle((cx, y), AXIS_R, dxfattribs={"layer": "S-AXIS"})
            add_text(msp, lab, cx - AXIS_H / 2.0, y, AXIS_H, "S-AXIS_TEXT", style="AXIS", center=True)


def pile_layout(px, py, n):
    rows = (n + 1) // 2
    out = []
    for i in range(n):
        r, c = divmod(i, 2)
        out.append((px - PILE_PITCH / 2.0 + c * PILE_PITCH,
                    py - PILE_PITCH / 2.0 * (rows - 1) + r * PILE_PITCH))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--x-gaps", default=",".join(str(int(g)) for g in X_GAPS))
    ap.add_argument("--y-gaps", default=",".join(str(int(g)) for g in Y_GAPS))
    ap.add_argument("--mode", default="pile", choices=["pile", "dj", "tj"])
    ap.add_argument("--ct-size", type=float, default=CT_SIZE)
    ap.add_argument("--pile-n", type=int, default=PILE_N)
    ap.add_argument("--foot", type=float, default=DJ_FOOT, help="独立基础边长")
    ap.add_argument("--strip-w", type=float, default=TJ_STRIP_W, help="条形基础宽")
    a = ap.parse_args()

    xg = [float(x) for x in a.x_gaps.split(",") if x.strip()]
    yg = [float(y) for y in a.y_gaps.split(",") if y.strip()]
    xs = [0.0]
    for g in xg: xs.append(xs[-1] + g)
    ys = [0.0]
    for g in yg: ys.append(ys[-1] + g)
    xn = axis_labels(len(xg) + 1, kind="number")
    yn = axis_labels(len(yg) + 1, kind="letter")
    xmax, ymax = xs[-1], ys[-1]

    doc = ezdxf.new("R2000", setup=True)
    apply_to_ezdxf(doc)
    doc.header["$INSUNITS"] = 4
    msp = doc.modelspace()

    if a.mode == "pile":
        # ---- 桩承台 ----
        pn = min(a.pile_n, 8)
        no = 1
        for x in xs:
            for y in ys:
                add_rect(msp, x, y, a.ct_size, a.ct_size, "S-FOUND")
                for (px, py) in pile_layout(x, y, pn):
                    msp.add_circle((px, py), PILE_R, dxfattribs={"layer": "S-PILE"})
                    add_text(msp, "ZH%d" % no, px + PILE_R + 150, py, 200, "S-PILE_TEXT", center=True)
                add_rect(msp, x, y, COL, COL, "S-FOUND_INNER")
                add_text(msp, "CT%d" % no, x + a.ct_size / 2.0 + 300, y + a.ct_size / 2.0 + 300, 260, "S-FOUND_TEXT")
                no += 1
        title = "桩承台基础平面布置图  1:100"
        detail = ["承台与桩详图 (CT1)  1:100", "%%13212@250 双层双向", "承台高 %d" % int(CT_H),
                  "桩 400 d=400 有效桩长 6000", "%%1328@200 螺旋箍"]
    elif a.mode == "dj":
        # ---- 独立基础 ----
        no = 1
        for x in xs:
            for y in ys:
                add_rect(msp, x, y, a.foot, a.foot, "S-FOUND")
                # 变阶内线
                add_rect(msp, x, y, a.foot * 0.6, a.foot * 0.6, "S-FOUND_INNER")
                add_rect(msp, x, y, COL, COL, "S-FOUND_INNER")
                add_text(msp, "DJ%d" % no, x + a.foot / 2.0 + 300, y + a.foot / 2.0 + 300, 260, "S-FOUND_TEXT")
                no += 1
        title = "独立基础平面布置图  1:100"
        detail = ["独立基础详图 (DJ1)  1:100", "%%13212@250 双向 底板筋", "基础顶/底标高见设计", "台阶 a=%d  h1=300 h2=200" % int(a.foot / 2.0)]
    else:
        # ---- 条形基础 ----
        sw = a.strip_w
        tj = 1
        for p1, p2 in (((0, 0), (xmax, 0)), ((0, ymax), (xmax, ymax)),
                       ((0, 0), (0, ymax)), ((xmax, 0), (xmax, ymax))):
            # 条基 = 宽 sw 的矩形条沿墙线
            dx, dy = p2[0] - p1[0], p2[1] - p1[1]
            L = (dx * dx + dy * dy) ** 0.5
            nx, ny = -dy / L, dx / L
            h2 = sw / 2.0
            add_rect(msp, (p1[0] + p2[0]) / 2.0, (p1[1] + p2[1]) / 2.0, L, sw, "S-FOUND")
            add_text(msp, "TJ%d" % tj, (p1[0] + p2[0]) / 2.0, (p1[1] + p2[1]) / 2.0, 240,
                     "S-FOUND_TEXT", center=True)
            tj += 1
        # 内纵条基（中间一条）
        if len(ys) >= 3:
            ym = (ys[1] + ys[2]) / 2.0
            add_rect(msp, xmax / 2.0, ym, xmax, sw, "S-FOUND")
            add_text(msp, "TJ%d" % tj, xmax / 2.0, ym, 240, "S-FOUND_TEXT", center=True)
            tj += 1
        title = "条形基础平面布置图  1:100"
        detail = ["条形基础详图 (TJ1)  1:100", "%%13212@250 双向 底板筋", "条基宽 %d  高 1000" % int(sw), "%%1328@200 分布筋"]

    axis_draw(msp, xs, ys, xn, yn)
    add_text(msp, title, xmax / 2.0, ymax + 2600, 420, "S-TEXT", center=True)

    # ---- 详图区（下图）----
    dy = -6500.0
    xc = xmax / 2.0
    add_text(msp, detail[0], xc, dy, 380, "S-TEXT", center=True)
    for k, d in enumerate(detail[1:], 1):
        add_text(msp, d, xc, dy - k * 420, 260, "S-FOUND_TEXT", style="TSSD_Rein", center=True)
    add_text(msp, "基础平面布置图下方详图", xc, dy - (len(detail)) * 420 - 300, 240,
             "S-TEXT", center=True)

    finalize_view(doc, margin_ratio=0.03, aspect=1.78)
    fname = "基础平法图_found_%s_r2000.dxf" % a.mode
    path = os.path.join(OUT, fname)
    os.makedirs(OUT, exist_ok=True)
    doc.saveas(path)
    errs = len(doc.audit().errors)
    ne = len(list(msp))
    print("[OK] mode=%s %s 实体=%d 审计错误=%d" % (a.mode, path, ne, errs))


if __name__ == "__main__":
    main()
