# -*- coding: utf-8 -*-
"""离线生成 A0–A4 全套图框 DXF（GB/T 50001 图纸幅面与格式）。

输出：<技能包>/output/图框_Ax_r2000.dxf（R2000,1:scale）
图框组成（与 cad_a1_frame.py 一致，只是参数化到任意幅面）：
  - 外框 + 内框（左/上留装订边 25mm，右/下 10mm）
  - 右下角标题栏（图名 / 比例 / 图号 / 日期 / 设计 四格）
  - 图层：S-PUB_TITLE / S-TAB / S-TAB_TEXT / S-DRAWING_NUMBER

复用 cad_standards.apply_to_ezdxf()（单源标准），收尾调用 finalize_view()。

用法：
  python gen_frame.py                          # A0-A4 全部
  python gen_frame.py --size A1 A3             # 指定若干幅面
  python gen_frame.py --scale 100 --title 结构平面布置图 --drawno 结施-01 --designer 王工
"""
import argparse
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import ezdxf
from cad_standards import apply_to_ezdxf

_BASE = os.path.dirname(os.path.abspath(__file__))
OUT = (os.environ.get("CAD_DXF_OUT") or
       os.path.normpath(os.path.join(_BASE, os.pardir, "output")))

# 幅面（mm，横向：长边水平）尺寸遵循 ISO 216 / GB/T 14689
SHEET_MM = {
    "A0": (1189.0, 841.0),
    "A1": (841.0, 594.0),
    "A2": (594.0, 420.0),
    "A3": (420.0, 297.0),
    "A4": (297.0, 210.0),
}
DEFAULT_SIZES = ["A0", "A1", "A2", "A3", "A4"]

MARGIN_LT_MM = 25.0   # 装订边（左/上）
MARGIN_RB_MM = 10.0   # 右/下
TB_W_MM = 240.0       # 标题栏宽
TB_H_MM = 60.0        # 标题栏高


def finalize_view(doc, margin_ratio=0.02, aspect=None):
    from ezdxf.bbox import extents as _extents
    msp = doc.modelspace()
    ext = _extents(msp, fast=False)
    if not ext.has_data:
        print("WARN: modelspace empty, skip finalize_view")
        return
    minx, miny = ext.extmin.x, ext.extmin.y
    maxx, maxy = ext.extmax.x, ext.extmax.y
    w, h = maxx - minx, maxy - miny
    mx, my = w * margin_ratio, h * margin_ratio
    lo = (minx - mx, miny - my)
    hi = (maxx + mx, maxy + my)
    msp.dxf.extmin = (lo[0], lo[1], 0.0)
    msp.dxf.extmax = (hi[0], hi[1], 0.0)
    msp.dxf.limmin = lo
    msp.dxf.limmax = hi
    cx, cy = (minx + maxx) / 2.0, (miny + maxy) / 2.0
    ar = aspect or (w / h if h else 1.78)
    view_h = max(h * (1 + 2 * margin_ratio), w * (1 + 2 * margin_ratio) / ar)
    for vp in doc.viewports.get("*Active"):
        vp.dxf.center = (cx, cy)
        vp.dxf.height = view_h
        vp.dxf.aspect_ratio = ar
    print("  extents: (%.0f,%.0f)-(%.0f,%.0f) size %.0f x %.0f"
          % (minx, miny, maxx, maxy, w, h))


def add_line(msp, x0, y0, x1, y1, layer):
    ln = msp.add_line((x0, y0, 0.0), (x1, y1, 0.0))
    ln.dxf.layer = layer
    return ln


def add_rect(msp, cx, cy, w, h, layer):
    x0, y0 = cx - w / 2.0, cy - h / 2.0
    pts = [(x0, y0), (x0 + w, y0), (x0 + w, y0 + h), (x0, y0 + h), (x0, y0)]
    for a, b in zip(pts, pts[1:]):
        add_line(msp, a[0], a[1], b[0], b[1], layer)


def add_text(msp, txt, x, y, h, layer, style="Standard", center=False):
    t = msp.add_text(str(txt), dxfattribs={
        "height": h, "layer": layer, "style": style, "insert": (x, y)})
    if center:
        t.dxf.halign = 1   # 中间对齐
        t.dxf.valign = 1
    return t


def gen_one(size, scale, title, drawno, date, designer):
    w_mm, h_mm = SHEET_MM[size]
    s = scale
    FW, FH = w_mm * s, h_mm * s
    cx, cy = FW / 2.0, FH / 2.0

    doc = ezdxf.new("R2000", setup=True)
    try:
        apply_to_ezdxf(doc)
    except Exception as e:
        print("WARN apply_to_ezdxf:", e)
    doc.header["$INSUNITS"] = 4   # 毫米

    msp = doc.modelspace()

    # 外框（居中于幅面，粗线用 S-PUB_TITLE 与 cad_a1_frame 一致）
    add_rect(msp, cx, cy, FW, FH, "S-PUB_TITLE")
    # 内框（留装订边）
    ix = cx - (FW / 2.0 - MARGIN_LT_MM * s)
    iy = cy - (FH / 2.0 - MARGIN_LT_MM * s)
    iw = FW - (MARGIN_LT_MM + MARGIN_RB_MM) * s
    ih = FH - (MARGIN_LT_MM + MARGIN_RB_MM) * s
    add_rect(msp, ix + iw / 2.0, iy + ih / 2.0, iw, ih, "S-PUB_TITLE")

    # 标题栏（右下角，内框内右下）
    tbw = TB_W_MM * s
    tbh = TB_H_MM * s
    irx = ix + iw
    iry = iy
    tbx0 = irx - tbw
    tby0 = iry
    tbx1 = irx
    tby1 = iry + tbh
    add_rect(msp, (tbx0 + tbx1) / 2.0, (tby0 + tby1) / 2.0, tbw, tbh, "S-TAB")
    name_h = tbh * 0.45
    y_split1 = tby0 + name_h
    add_line(msp, tbx0, y_split1, tbx1, y_split1, "S-TAB")
    col_w = tbw / 4.0
    for k in range(1, 4):
        xv = tbx0 + col_w * k
        add_line(msp, xv, y_split1, xv, tby1, "S-TAB")

    th_big = 3.5 * s
    th_sm = 2.5 * s
    add_text(msp, title, (tbx0 + tbx1) / 2.0, y_split1 - name_h / 2.0,
             th_big, "S-TAB_TEXT", center=True)
    cells = ["比例 1:%d" % int(s), "图号 %s" % drawno,
             "日期 %s" % date, "设计 %s" % designer]
    for k, c in enumerate(cells):
        xc = tbx0 + col_w * (k + 0.5)
        add_text(msp, c, xc, (y_split1 + tby1) / 2.0, th_sm, "S-TAB_TEXT",
                 center=True)

    finalize_view(doc, margin_ratio=0.02, aspect=FW / FH)

    fname = "图框_%s_r2000.dxf" % size
    path = os.path.join(OUT, fname)
    os.makedirs(OUT, exist_ok=True)
    doc.saveas(path)
    n_ent = len(list(msp))
    # ezdxf 审计
    auditor = doc.audit()
    errs = len(auditor.errors)
    print("[OK] %s  -> %s  | 实体 %d | 审计错误 %d" % (size, path, n_ent, errs))
    return path, n_ent, errs


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--size", nargs="*", default=DEFAULT_SIZES,
                    help="幅面列表，默认 A0 A1 A2 A3 A4，可指定多个")
    ap.add_argument("--scale", type=float, default=100.0)
    ap.add_argument("--title", default="结构平面布置图")
    ap.add_argument("--drawno", default="结施-01")
    ap.add_argument("--date", default="2026.09.04")
    ap.add_argument("--designer", default="王工")
    a = ap.parse_args()

    sizes = [x.upper() for x in a.size]
    bad = [x for x in sizes if x not in SHEET_MM]
    if bad:
        raise SystemExit("未知幅面: %s (可选: %s)" % (bad, list(SHEET_MM)))

    total_ents = total_errs = 0
    made = []
    for size in sizes:
        p, ne, ne_err = gen_one(size, a.scale, a.title, a.drawno, a.date,
                                a.designer)
        made.append(p)
        total_ents += ne
        total_errs += ne_err
    print("\n合计：%d 幅图框 | 实体 %d | 审计错误 %d" % (len(made), total_ents,
                                                total_errs))


if __name__ == "__main__":
    main()
