# -*- coding: utf-8 -*-
"""结构平面布置图(轴网+柱+梁) + 柱详图(柱表式) 可复用模板。

按王工验收稿「结构平面图_柱详图.dxf」(2026-08-07 验收通过) 整理。

图面组成（同一 DXF，平面图在左、柱详图在右）：
- 左：结构平面布置图
    * 轴网（双侧标注：分跨尺寸 + 总尺寸，轴号圈上下/左右成对）
    * 柱 500x500 不填充，编号放在柱右上角外侧
    * 梁：边跨梁 250x600 靠外侧对齐；内部梁 200x400 居中
    * 梁编号 KL1~ 每道梁一个编号：横梁在上方/下方中间跨跨中，竖梁在左(旋转90°)
    * 图名在图面下侧
- 右：一层框架柱表（柱表式详图，样式对齐验收稿 1.dxf）
    * 截面 500x500 放大 10/3，纵筋为正圆实心点（2点 bulge=1 多段线 + 线宽）
    * 箍筋：外箍 + 双向内箍（复合箍，含135度弯钩），箍筋位于纵筋外侧
    * 尺寸标注距柱边 200mm

用法：
    python gen_frame_plan_col_detail.py                 # 输出到 ../output/
    CAD_DXF_OUT=D:/tmp/xxx.dxf python gen_frame_plan_col_detail.py
    python quick_validate.py ../output/frame_plan_col_detail_r2000.dxf
    python render_preview.py                            # 渲染 PNG 预览

改图：只改下方「平面图参数」与「柱详图参数」两段即可。
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cad_standards as STD
import ezdxf
from ezdxf.enums import TextEntityAlignment

_BASE = os.path.dirname(os.path.abspath(__file__))
OUT = os.environ.get("CAD_DXF_OUT") or os.path.join(
    _BASE, os.pardir, "output", "frame_plan_col_detail_r2000.dxf")
OUT = os.path.normpath(OUT)

# ================= 平面图参数 =================
X_GAP, X_SPANS = 4000, 5          # 横向跨度 x 跨数
Y_GAP, Y_SPANS = 7500, 2          # 纵向跨度 x 跨数
COL_W, COL_H = 500, 500           # 柱截面 b x h
COL_TAG = "KZ-1"                  # 柱编号
EDGE_BEAM = (250, 600)            # 边跨梁 b x h（最外侧梁，靠外侧对齐）
INTERNAL_BEAM = (200, 400)        # 内部梁 b x h（居中）
TITLE = "结构平面布置图"             # 图名（图面下侧）
SCALE_TEXT = "1:100"

# ================= 柱详图参数（柱表式，对齐验收稿 1.dxf） =================
DET_OFF_X = 23000.0               # 详图外框相对平面图原点的 X 偏移
DET_FW, DET_FH = 7700.0, 10000.0  # 柱表外框宽 x 高
DET_TITLE = "一层框架柱表"           # 柱表标题
DET_TAG = "KZ-1"                  # 柱编号
DET_ELEV = "基础顶~-3.470"         # 标高范围
DET_BAR_N, DET_BAR_D = 12, 22     # 纵筋根数 x 直径(mm)
DET_BAR_GRADE = "%%132"           # 钢筋等级代号(%%132 = C / HRB400)
DET_BAR_GRADE_TXT = "C"           # 注记中显示的等级文字
DET_STIRRUP_TEXT = "%%1328@100/200"  # 箍筋标注（%%132 = 一级/HPB300 符号）
DET_SCALE = 10.0 / 3.0            # 截面放大倍数
DET_COVER = 30.0                  # 保护层(mm)，放大后 = 100
DET_BAR_OFF = 165.05              # 纵筋圆心距柱边(放大后)，对齐验收稿
DET_STIRRUP_W = 40.0              # 箍筋线宽
DET_BAR_W = 58.33 * DET_BAR_D / 20.0   # 纵筋点直径（随筋径缩放）

XS = [i * X_GAP for i in range(X_SPANS + 1)]
YS = [i * Y_GAP for i in range(Y_SPANS + 1)]
XNUM = STD.axis_labels(len(XS), kind="number")
YNUM = STD.axis_labels(len(YS), kind="letter")
COL_HX, COL_HY = COL_W / 2.0, COL_H / 2.0
DET_COV = DET_COVER * DET_SCALE

AXIS_R = STD.AXIS_R
AXIS_H = STD.AXIS_H
DIM1 = STD.DIM1
DIM2 = STD.DIM2
AXIS_ENDOFF = STD.AXIS_ENDOFF
AXIS_CENTER = STD.AXIS_CENTER

doc = ezdxf.new("R2000", setup=True)
STD.apply_to_ezdxf(doc)
msp = doc.modelspace()

# ================= 平面图 =================
def aligned_dim(p1, p2, distance, text=""):
    dim = msp.add_aligned_dim(p1=p1, p2=p2, distance=distance,
                              dimstyle=STD.DIMSTYLE_NAME,
                              dxfattribs={"layer": "S-DIM"})
    if text:
        dim.set_text(text)
    dim.render()

def put_text(txt, x, y, layer, height, style="Standard", center=False, color=None):
    attr = {"layer": layer, "height": height, "style": style}
    if color is not None:
        attr["color"] = color
    t = msp.add_text(txt, dxfattribs=attr)
    x0 = x - len(txt) * height * 0.31 if center else x
    t.set_placement((x0, y))
    return t

def draw_axis_grid(oy):
    for x in XS:
        msp.add_line((x, oy - AXIS_ENDOFF), (x, oy + YS[-1] + AXIS_ENDOFF),
                     dxfattribs={"layer": "S-DOTE"})
    for y in YS:
        msp.add_line((-AXIS_ENDOFF, oy + y), (XS[-1] + AXIS_ENDOFF, oy + y),
                     dxfattribs={"layer": "S-DOTE"})

def add_axis_text(text, x, y):
    t = msp.add_text(text, dxfattribs={"layer": "S-AXIS_TEXT", "height": AXIS_H,
                                       "style": "AXIS", "color": 7})
    t.set_placement((x - AXIS_H * 0.25 * len(text), y - AXIS_H * 0.35))

def draw_axis_marks(oy):
    for i, x in enumerate(XS):
        for y in [oy - AXIS_CENTER, oy + YS[-1] + AXIS_CENTER]:
            msp.add_circle((x, y), AXIS_R, dxfattribs={"layer": "S-AXIS"})
            add_axis_text(XNUM[i], x, y)
    for i, y in enumerate(YS):
        for x in [-AXIS_CENTER, XS[-1] + AXIS_CENTER]:
            msp.add_circle((x, oy + y), AXIS_R, dxfattribs={"layer": "S-AXIS"})
            add_axis_text(YNUM[i], x, oy + y)

def draw_dims(oy):
    # 横向：下侧 + 上侧（双侧标注）
    for i in range(len(XS) - 1):
        aligned_dim((XS[i], oy), (XS[i + 1], oy), -DIM1, text=str(XS[i + 1] - XS[i]))
    aligned_dim((XS[0], oy), (XS[-1], oy), -DIM2, text=str(XS[-1] - XS[0]))
    top = oy + YS[-1]
    for i in range(len(XS) - 1):
        aligned_dim((XS[i], top), (XS[i + 1], top), DIM1, text=str(XS[i + 1] - XS[i]))
    aligned_dim((XS[0], top), (XS[-1], top), DIM2, text=str(XS[-1] - XS[0]))
    # 纵向：左侧 + 右侧（双侧标注）
    for i in range(len(YS) - 1):
        aligned_dim((0, oy + YS[i]), (0, oy + YS[i + 1]), DIM1, text=str(YS[i + 1] - YS[i]))
    aligned_dim((0, oy + YS[0]), (0, oy + YS[-1]), DIM2, text=str(YS[-1] - YS[0]))
    right = XS[-1]
    for i in range(len(YS) - 1):
        aligned_dim((right, oy + YS[i]), (right, oy + YS[i + 1]), -DIM1, text=str(YS[i + 1] - YS[i]))
    aligned_dim((right, oy + YS[0]), (right, oy + YS[-1]), -DIM2, text=str(YS[-1] - YS[0]))

def beam_label(txt, x, y, rotation=0.0):
    t = msp.add_text(txt, dxfattribs={"layer": "S-BEAM_TEXT", "height": 250,
                                      "style": "AXIS", "rotation": rotation})
    t.set_placement((x, y), align=TextEntityAlignment.MIDDLE_CENTER)

def add_column(cx, cy, w, h, tag=None, fill=False):
    hx, hy = w / 2.0, h / 2.0
    pts = [(cx - hx, cy - hy), (cx + hx, cy - hy),
           (cx + hx, cy + hy), (cx - hx, cy + hy), (cx - hx, cy - hy)]
    if fill:
        hatch = msp.add_hatch(dxfattribs={"layer": "S-COLU_HATCH"})
        hatch.paths.add_polyline_path(pts, is_closed=True)
    msp.add_lwpolyline(pts, dxfattribs={"layer": "S-COLU", "closed": True})
    if tag:
        t = msp.add_text(tag, dxfattribs={"layer": "S-COLU_NUM",
                                          "height": 220, "style": "AXIS"})
        t.set_placement((cx + hx + 10, cy + hy + 10),
                        align=TextEntityAlignment.BOTTOM_LEFT)

def draw_columns(oy, tag=COL_TAG):
    for y in YS:
        for x in XS:
            add_column(x, oy + y, COL_W, COL_H, tag)

def draw_beams(oy):
    AT_BEAM = {"layer": "S-BEAM_CON"}
    n_span = len(XS) - 1
    m_span = len(YS) - 1
    num = 0
    for y in reversed(YS):                       # 横梁：上 -> 下，每道梁一个编号
        num += 1
        edge = (y == YS[0] or y == YS[-1])
        bw, bh = EDGE_BEAM if edge else INTERNAL_BEAM
        for i in range(n_span):
            ax, bx = XS[i] + COL_HX, XS[i + 1] - COL_HX
            if bx <= ax:
                continue
            if y == YS[-1]:                      # 顶部边跨梁：靠外侧(上)对齐
                lo, hi = y, y + bw
            elif y == YS[0]:                     # 底部边跨梁：靠外侧(下)对齐
                lo, hi = y - bw, y
            else:                                # 内部梁：居中
                lo, hi = y - bw / 2.0, y + bw / 2.0
            msp.add_line((ax, oy + lo), (bx, oy + lo), AT_BEAM)
            msp.add_line((ax, oy + hi), (bx, oy + hi), AT_BEAM)
        # 标注放在中间跨的跨中；顶部/中间梁在上方、底部梁在下方
        mi = n_span // 2
        mx = (XS[mi] + XS[mi + 1]) / 2.0
        if y == YS[0]:
            beam_label("KL%d %dx%d" % (num, bw, bh), mx, oy + y - bw - 180)
        else:
            beam_label("KL%d %dx%d" % (num, bw, bh), mx,
                       oy + y + (bw if edge else 0) + 180)
    for x in XS:                                 # 竖梁：左 -> 右，每道梁一个编号
        num += 1
        edge = (x == XS[0] or x == XS[-1])
        bw, bh = EDGE_BEAM if edge else INTERNAL_BEAM
        for i in range(m_span):
            ay, by = YS[i] + COL_HY, YS[i + 1] - COL_HY
            if by <= ay:
                continue
            if x == XS[0]:                       # 左边跨梁：靠外侧(左)对齐
                lo, hi = x - bw, x
            elif x == XS[-1]:                    # 右边跨梁：靠外侧(右)对齐
                lo, hi = x, x + bw
            else:                                # 内部梁：居中
                lo, hi = x - bw / 2.0, x + bw / 2.0
            msp.add_line((lo, oy + ay), (lo, oy + by), AT_BEAM)
            msp.add_line((hi, oy + ay), (hi, oy + by), AT_BEAM)
        # 标注放在下边跨的跨中，置于梁左侧（旋转90°）
        ly = (YS[0] + YS[1]) / 2.0
        lx = x - (bw if edge else bw / 2.0) - 160
        beam_label("KL%d %dx%d" % (num, bw, bh), lx, oy + ly, rotation=90.0)

def draw_plan_title(oy):
    name = TITLE
    y = oy - AXIS_CENTER - 1400
    tit_h = 500
    x0 = XS[-1] / 2 - len(name) * tit_h * 0.45
    put_text(name, x0, y, "S-TEXT", tit_h)
    w = len(name) * tit_h * 0.9
    msp.add_line((x0, y - 200), (x0 + w, y - 200), dxfattribs={"layer": "S-TEXT"})
    put_text(SCALE_TEXT, x0 + w + 300, y, "S-TEXT", int(tit_h * 0.7))

OY = 0
draw_axis_grid(OY)
draw_axis_marks(OY)
draw_dims(OY)
draw_columns(OY)
draw_beams(OY)
draw_plan_title(OY)

# 注记
_note = ("注：柱 %s %dx%d（纵筋%d%s%d）；梁：边跨%dx%d、内部%dx%d" % (
    DET_TAG, COL_W, COL_H, DET_BAR_N, DET_BAR_GRADE_TXT, DET_BAR_D,
    EDGE_BEAM[0], EDGE_BEAM[1], INTERNAL_BEAM[0], INTERNAL_BEAM[1]))
put_text(_note, 0, OY + YS[-1] + AXIS_CENTER + 700, "S-TEXT", 260)

# ================= 柱详图（柱表式，对齐验收稿 1.dxf） =================
def _det_add_text(txt, x, y, h, layer, align="center", rotation=0.0, style="TSSD_Rein"):
    al = {"center": TextEntityAlignment.MIDDLE_CENTER,
          "left": TextEntityAlignment.LEFT,
          "right": TextEntityAlignment.RIGHT}[align]
    t = msp.add_text(str(txt), dxfattribs={"layer": layer, "height": h,
                                           "style": style, "rotation": rotation})
    t.set_placement((x, y), align=al)
    return t

def _det_rect(x0, y0, x1, y1, layer):
    msp.add_lwpolyline([(x0, y0), (x1, y0), (x1, y1), (x0, y1), (x0, y0)],
                       dxfattribs={"layer": layer, "closed": True})

def _stirrup(box, layer):
    """12点箍筋多段线(含135度弯钩)，几何对齐验收稿 1.dxf。"""
    x0, y0, x1, y1 = box
    pts = [
        (x1 - 277.0, y0 + 177.0),   # 弯钩起点(斜向)
        (x1 - 100.0, y0),
        (x1, y0),
        (x1, y0 + 100.0),
        (x1, y0),
        (x1, y1),
        (x0, y1),
        (x0, y0),
        (x1 - 100.0, y0),
        (x1, y0),
        (x1, y0 + 100.0),
        (x1 - 177.0, y0 + 277.0),   # 弯钩终点(斜向)
    ]
    msp.add_lwpolyline(pts, dxfattribs={"layer": layer, "closed": False,
                                        "const_width": DET_STIRRUP_W})

def _bar_dot(cx, cy, r):
    # 2点 bulge=1 闭合多段线(两个半圆拼成整圆) + 线宽 = 正圆实心点
    x0, x1 = cx - r, cx + r
    pts = [(x0, cy, 1.0), (x1, cy, 1.0)]
    msp.add_lwpolyline(pts, format="xyb", close=True,
                       dxfattribs={"layer": "S-REIN", "const_width": DET_BAR_W})

def draw_col_detail():
    dx = DET_OFF_X
    # 外框 + 表行 + 标题行
    _det_rect(dx, 0, dx + DET_FW, DET_FH, "S-TAB")
    for yy in [800, 1600, 2400, 3200, 9200]:
        msp.add_line((dx, yy), (dx + DET_FW, yy), dxfattribs={"layer": "S-TAB"})
    msp.add_line((dx + 1500, 0), (dx + 1500, 9200), dxfattribs={"layer": "S-TAB"})
    # 标题
    _det_add_text(DET_TITLE, dx + DET_FW / 2, 9600, 600, "S-TAB_TEXT")
    # 左列标签
    for txt, yy in [("截 面", 6200), ("编 号", 2800), ("标 高", 2000),
                    ("纵 筋", 1200), ("箍筋、拉筋", 400)]:
        _det_add_text(txt, dx + 750, yy, 450, "S-TAB_TEXT")
    # 表内数值
    _det_add_text(DET_TAG, dx + 4600, 2800, 450, "S-TAB_TEXT")
    _det_add_text(DET_ELEV, dx + 4600, 2000, 300, "S-PUB_TEXT")
    _det_add_text("%d%s%d" % (DET_BAR_N, DET_BAR_GRADE, DET_BAR_D),
                  dx + 4600, 1200, 300, "S-PUB_TEXT")
    _det_add_text(DET_STIRRUP_TEXT, dx + 4600, 400, 300, "S-PUB_TEXT")

    # 截面（中心 dx+4400, 6200；放大 10/3）
    cx, cy = dx + 4400, 6200.0
    hw = 500.0 * DET_SCALE / 2
    _det_rect(cx - hw, cy - hw, cx + hw, cy + hw, "S-COLU_DE")
    # 12 根纵筋（角部4 + 每边中间2），圆心距柱边 DET_BAR_OFF
    k_mid = (DET_BAR_N - 4) // 4          # 每边中间筋根数
    assert DET_BAR_N == 4 + 4 * k_mid, "纵筋根数需为 4+4k（角部4根+每边k根）"
    off = DET_BAR_OFF
    gap = (2 * hw - 2 * off) / (k_mid + 1)
    xs = [cx - hw + off + i * gap for i in range(k_mid + 2)]
    ys = [cy - hw + off + i * gap for i in range(k_mid + 2)]
    r = DET_BAR_W / 2
    # 箍筋：外箍 + 双向内箍（复合箍），箍筋在纵筋外侧
    sw = 2 * hw - 2 * DET_COV
    _stirrup((cx - sw / 2, cy - sw / 2, cx + sw / 2, cy + sw / 2), "S-REIN")
    iw = gap * (k_mid - 1) + DET_BAR_W + 50.0   # 内箍宽：包裹每边中间 k 根纵筋
    _stirrup((cx - iw / 2, cy - sw / 2, cx + iw / 2, cy + sw / 2), "S-REIN")
    _stirrup((cx - sw / 2, cy - iw / 2, cx + sw / 2, cy + iw / 2), "S-REIN")
    for x in xs:
        for y in ys:
            if (x in (xs[0], xs[-1]) and y in (ys[0], ys[-1])) or \
               (x not in (xs[0], xs[-1])) or (y not in (ys[0], ys[-1])):
                _bar_dot(x, y, r)
    # 尺寸标注：距柱边 200mm(=666.7 放大后)
    _dim_detail((cx - hw, cy - hw), (cx + hw, cy - hw), -DET_COV * 2 - 466.7, "500")
    _dim_detail((cx + hw, cy - hw), (cx + hw, cy + hw), -(DET_COV * 2 + 466.7), "500")
    # 引线 + 文字
    msp.add_line((cx + hw, cy + hw), (cx + hw + 900, cy + hw + 900),
                 dxfattribs={"layer": "S-COLU_DE_TEXT"})
    _det_add_text("角部4%s%d" % (DET_BAR_GRADE, DET_BAR_D), cx + hw + 1000,
                  cy + hw + 900, 300, "S-COLU_DE_TEXT", align="left")
    _det_add_text("2%s%d" % (DET_BAR_GRADE, DET_BAR_D), cx, cy + hw + 200,
                  300, "S-COLU_DE_TEXT")
    _det_add_text("2%s%d" % (DET_BAR_GRADE, DET_BAR_D), cx - hw - 350, cy,
                  300, "S-COLU_DE_TEXT", rotation=90.0)

def _dim_detail(p1, p2, distance, text):
    dim = msp.add_aligned_dim(p1=p1, p2=p2, distance=distance,
                              dimstyle=STD.DIMSTYLE_NAME,
                              dxfattribs={"layer": "S-DIM"})
    dim.set_text(text)
    dim.render()

draw_col_detail()

# ================= 收尾 =================
def finalize_view(doc, margin_ratio=0.04, aspect=1.78):
    from ezdxf.bbox import extents as _extents
    msp = doc.modelspace()
    ext = _extents(msp, fast=False)
    if not ext.has_data:
        print("WARN: empty")
        return
    minx, miny = ext.extmin.x, ext.extmin.y
    maxx, maxy = ext.extmax.x, ext.extmax.y
    w, h = maxx - minx, maxy - miny
    mx, my = w * margin_ratio, h * margin_ratio
    lo = (minx - mx, miny - my)
    hi = (maxx + mx, maxy + my)
    msp.dxf.extmin = (lo[0], lo[1], 0.0)
    msp.dxf.extmax = (hi[0], hi[1], 0.0)
    msp.dxf.limmin = lo
    msp.dxf.limmax = hi

finalize_view(doc)
doc.dxfversion = "AC1015"
os.makedirs(os.path.dirname(OUT), exist_ok=True)
doc.saveas(OUT)
print("saved ->", OUT)