"""根据OCR提取的"基础顶~5.550m柱平面配筋图"参数生成DXF"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cad_standards as STD
import ezdxf
from ezdxf.enums import TextEntityAlignment

OUT_PATH = r"D:\desktopdata\Desktop\25195-11510-X-7_基础顶~5.550m柱平面配筋图.dxf"

# ================= 从图纸提取的参数 =================
# X向: 14根轴线(1-14), 13跨
X_SPANS = [7200, 3600, 3600, 7200, 7200, 7200, 7200, 3300, 3900, 3600, 3600, 7200, 7200]
# Y向: 4根轴线(A-D), 3跨
Y_SPANS = [7200, 7200, 7200]

# 柱截面 (按轴网交点)
COLUMNS = {
    # 角柱 (A-1, A-14, D-1, D-14) — 从OCR推测 350×350
    "corner": (350, 350),
    # 边柱 (A轴、D轴中间列) — 从OCR推测 300×500
    "edge": (300, 500),
    # 中柱 (B轴、C轴中间列) — 从OCR推测 350×350~300×500
    "inner": (350, 350),
}

CONCRETE_GRADE = "C35"
SCALE = "1:100"

# 计算轴网坐标
xs = [0]
for s in X_SPANS:
    xs.append(xs[-1] + s)
ys = [0]
for s in Y_SPANS:
    ys.append(ys[-1] + s)

X_TOTAL = xs[-1]
Y_TOTAL = ys[-1]

# ================= 初始化文档 =================
doc = ezdxf.new("R2000", setup=True)
doc.header["$DIMSCALE"] = 100.0
doc.header["$LTSCALE"] = 100.0
doc.header["$TEXTSIZE"] = 200.0
doc.header["$INSUNITS"] = 4
msp = doc.modelspace()

# 文字样式
std = doc.styles.get("Standard")
std.dxf.font = "GBENOR"
std.dxf.bigfont = "GBCBIG"
doc.styles.new("AXIS", dxfattribs={"font": "txt.shx"})

# 标注样式
doc.dimstyles.new("DIM100", dxfattribs={
    "dimscale": 100.0, "dimtxt": 2.5, "dimasz": 2.5,
    "dimtsz": 0.5, "dimblk": "", "dimexe": 1.5,
    "dimexo": 1.5, "dimtad": 1, "dimclrd": 3,
    "dimclre": 3, "dimclrt": 7, "dimtxsty": "Standard",
})

# 创建图层
for name, (aci, lw, lt, desc) in STD.LAYERS.items():
    doc.layers.new(name, dxfattribs={"color": aci, "lineweight": lw, "linetype": lt})

MARGIN = 2000

# ================= 轴网 =================
# 轴线
for x in xs:
    msp.add_line((x, -MARGIN), (x, Y_TOTAL + MARGIN), dxfattribs={"layer": "S-DOTE"})
for y in ys:
    msp.add_line((-MARGIN, y), (X_TOTAL + MARGIN, y), dxfattribs={"layer": "S-DOTE"})

# 轴号 — X向 (1~14)
for i, x in enumerate(xs):
    num = str(i + 1)
    for y_pos, side in [(-600, "下"), (Y_TOTAL + 600, "上")]:
        msp.add_circle((x, y_pos), 250, dxfattribs={"layer": "S-AXIS"})
        msp.add_text(num, height=350, dxfattribs={"layer": "S-AXIS_TEXT"}).set_placement(
            (x, y_pos), align=TextEntityAlignment.MIDDLE_CENTER)

# 轴号 — Y向 (A~D)
letters = ["A", "B", "C", "D"]
for i, y in enumerate(ys):
    letter = letters[i]
    for x_pos in [-600, X_TOTAL + 600]:
        msp.add_circle((x_pos, y), 250, dxfattribs={"layer": "S-AXIS"})
        msp.add_text(letter, height=350, dxfattribs={"layer": "S-AXIS_TEXT"}).set_placement(
            (x_pos, y), align=TextEntityAlignment.MIDDLE_CENTER)

# ================= 尺寸标注 =================
DIM_OFFSET = 1500
DIM_GAP = 600

# X向 — 分跨尺寸
for i in range(len(X_SPANS)):
    msp.add_aligned_dim(
        p1=(xs[i], -DIM_OFFSET), p2=(xs[i+1], -DIM_OFFSET),
        distance=DIM_OFFSET + DIM_GAP,
        dimstyle="DIM100", dxfattribs={"layer": "S-DIM"}
    ).render()

# X向 — 总尺寸
msp.add_aligned_dim(
    p1=(xs[0], -DIM_OFFSET), p2=(xs[-1], -DIM_OFFSET),
    distance=DIM_OFFSET + DIM_GAP * 2,
    dimstyle="DIM100", dxfattribs={"layer": "S-DIM"}
).render()

# Y向 — 分跨尺寸
for i in range(len(Y_SPANS)):
    msp.add_aligned_dim(
        p1=(-DIM_OFFSET, ys[i]), p2=(-DIM_OFFSET, ys[i+1]),
        distance=DIM_OFFSET + DIM_GAP,
        dimstyle="DIM100", dxfattribs={"layer": "S-DIM"}
    ).render()

# Y向 — 总尺寸
msp.add_aligned_dim(
    p1=(-DIM_OFFSET, ys[0]), p2=(-DIM_OFFSET, ys[-1]),
    distance=DIM_OFFSET + DIM_GAP * 2,
    dimstyle="DIM100", dxfattribs={"layer": "S-DIM"}
).render()

# ================= 柱 =================
for xi, x in enumerate(xs):
    for yi, y in enumerate(ys):
        # 判断柱类型
        is_corner = (xi == 0 or xi == len(xs)-1) and (yi == 0 or yi == len(ys)-1)
        is_edge = (yi == 0 or yi == len(ys)-1)  # A轴或D轴
        if is_corner:
            bw, bh = COLUMNS["corner"]
        elif is_edge:
            bw, bh = COLUMNS["edge"]
        else:
            bw, bh = COLUMNS["inner"]

        # 柱轮廓（不填充）
        x0, y0 = x - bw/2, y - bh/2
        x1, y1 = x + bw/2, y + bh/2
        msp.add_lwpolyline([(x0, y0), (x1, y0), (x1, y1), (x0, y1), (x0, y0)],
                           dxfattribs={"layer": "S-COLU", "closed": True})

        # 柱编号
        num = xi + yi * len(xs) + 1
        if yi == 0:
            kz_num = xi + 1  # A轴: KZ1, KZ2, ... KZ14
        else:
            kz_num = xi + 1 + yi * len(xs)  # 其他轴

        tag = f"KZ{kz_num}"
        msp.add_text(tag, height=300, dxfattribs={"layer": "S-COLU_NUM"}).set_placement(
            (x + bw/2 + 200, y + bh/2 + 100),
            align=TextEntityAlignment.BOTTOM_LEFT)

# ================= 梁 =================
BEAM_B, BEAM_H = 350, 700  # 主梁典型截面

# X向梁 (水平方向)
for i in range(len(X_SPANS)):
    for j in range(len(ys)):
        x_l = xs[i] + COLUMNS["corner"][0]/2 if i == 0 or i == len(X_SPANS) else xs[i] + COLUMNS.get("inner", (350,350))[0]/2
        x_r = xs[i+1] - COLUMNS["corner"][0]/2 if i == 0 or i == len(X_SPANS) else xs[i+1] - COLUMNS.get("inner", (350,350))[0]/2
        
        # 确定该列柱的宽度
        if j == 0 or j == len(ys)-1:
            col_w = COLUMNS["edge"][0]
        else:
            col_w = COLUMNS["inner"][0]
            
        x_l = xs[i] + col_w/2
        x_r = xs[i+1] - col_w/2
        y_c = ys[j]
        b = BEAM_B / 2
        msp.add_line((x_l, y_c + b), (x_r, y_c + b), dxfattribs={"layer": "S-BEAM_CON"})
        msp.add_line((x_l, y_c - b), (x_r, y_c - b), dxfattribs={"layer": "S-BEAM_CON"})

# Y向梁 (垂直方向)
for i in range(len(xs)):
    for j in range(len(Y_SPANS)):
        x_c = xs[i]
        if i == 0 or i == len(xs)-1:
            col_h = COLUMNS["corner"][1]
        else:
            col_h = COLUMNS["inner"][1]
        y_b = ys[j] + col_h/2
        y_t = ys[j+1] - col_h/2
        b = BEAM_B / 2
        msp.add_line((x_c - b, y_b), (x_c - b, y_t), dxfattribs={"layer": "S-BEAM_CON"})
        msp.add_line((x_c + b, y_b), (x_c + b, y_t), dxfattribs={"layer": "S-BEAM_CON"})

# ================= 图名 =================
TITLE_Y = -3500
msp.add_text("基础顶~5.550m 柱平面配筋图", height=500,
             dxfattribs={"layer": "S-DIM_SYMB"}).set_placement(
    (X_TOTAL/2, TITLE_Y), align=TextEntityAlignment.BOTTOM_CENTER)

msp.add_text("1:100", height=350,
             dxfattribs={"layer": "S-DIM_SYMB"}).set_placement(
    (X_TOTAL/2, TITLE_Y - 600), align=TextEntityAlignment.TOP_CENTER)

# 混凝土等级标注
msp.add_text(f"混凝土强度等级: {CONCRETE_GRADE}", height=300,
             dxfattribs={"layer": "S-TEXT"}).set_placement(
    (200, TITLE_Y - 600), align=TextEntityAlignment.BOTTOM_LEFT)

# ================= finalize_view =================
msp.dxf.extmin = (-3000, -4000, 0)
msp.dxf.extmax = (X_TOTAL + 3000, Y_TOTAL + 2000, 0)

for vp in doc.viewports.get("*Active"):
    vp.dxf.center = (X_TOTAL/2, Y_TOTAL/2)
    vp.dxf.height = max(Y_TOTAL + 6000, X_TOTAL * 0.6)

doc.saveas(OUT_PATH)
print(f"OK: {OUT_PATH}")
print(f"轴网: {len(xs)}x{len(ys)} ({len(X_SPANS)}跨×{len(Y_SPANS)}跨)")
print(f"X向: {', '.join(str(s) for s in X_SPANS)}")
print(f"Y向: {', '.join(str(s) for s in Y_SPANS)}")
print(f"柱: 角柱{COLUMNS['corner']}, 边柱{COLUMNS['edge']}, 中柱{COLUMNS['inner']}")
print(f"梁: {BEAM_B}x{BEAM_H}")
print(f"混凝土: {CONCRETE_GRADE}")