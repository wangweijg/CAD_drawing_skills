# -*- coding: utf-8 -*-
"""离线生成结构设计总说明页 DXF（结总-1 文字页）。

图面：A1 幅面 + 图头（图名/图号）+ 编号说明条（S-TEXT），覆盖结构图纸必备总说明内容：
    工程概况 / 设计依据 / 设计条件 / 主要材料 / 混凝土保护层 / 基础 / 构造与施工要求 / 其他。
复用 cad_standards.apply_to_ezdxf() 单源标准。钢筋等级默认 HRB400 三级钢（配筋行 TSSD_Rein）。

用法：
    python gen_general_notes.py
    python gen_general_notes.py --title 结构设计总说明 --drawno 结总-1
"""
import argparse
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import ezdxf
from cad_standards import apply_to_ezdxf, REBAR_GRADE_CN

_BASE = os.path.dirname(os.path.abspath(__file__))
OUT = (os.environ.get("CAD_DXF_OUT") or
       os.path.normpath(os.path.join(_BASE, os.pardir, "output")))

# A1 幅面（横向）mm
W_MM, H_MM = 841.0, 594.0
MARG_LT = 25.0
MARG_RB = 10.0
TB_H = 60.0

NOTES = [
    "一、工程概况",
    "1. 本工程为钢筋混凝土框架（-剪力墙）结构，设计使用年限 50 年，建筑结构安全等级为二级。",
    "2. 结构抗震设防类别/烈度、场地类别按地质勘察报告与当地抗震设防区划确定。",
    "",
    "二、设计依据",
    "1. 《建筑结构荷载规范》GB 50009；《建筑抗震设计规范》GB 50011；",
    "2. 《混凝土结构设计规范》GB 50010；《混凝土结构施工图平面整体表示方法制图规则和构造详图》GB/T 22G101；",
    "3. 《建筑桩基技术规范》JGJ 94；《建筑地基基础设计规范》GB 50007。",
    "",
    "三、主要设计条件",
    "1. 主要活荷载：病房/诊室 2.0kN/m2，走廊/楼梯 3.5kN/m2，上人屋面 2.0kN/m2；",
    "2. 基本风压/基本雪压按当地 50 年重现期取值；地面粗糙度 B 类。",
    "",
    "四、主要材料",
    "1. 混凝土：基础、梁、板、柱、墙混凝土强度等级见各图（常用 C30/C35/C40）；",
    "2. 钢筋：HRB400 三级钢（底部总说明收口，图面不逐根标注等级）；",
    "3. 砌体：非承重填充墙用加气混凝土砌块，强度与容重见建筑专业。",
    "",
    "五、混凝土保护层（最外层钢筋，环境类别按 GB 50010）",
    "1. 柱/墙（一类环境）20mm；梁 25mm；板 15mm；",
    "2. 基础底面/侧面 40mm；桩身保护层 50mm。",
    "",
    "六、基础与地下室",
    "1. 基础形式（独立基础/桩承台/筏板等）及定位、桩位见基础平面布置图与基础详图；",
    "2. 桩基：桩型、桩径、有效桩长、单桩承载力特征值见桩位图与桩大样。",
    "",
    "七、构造与施工要求",
    "1. 钢筋锚固、搭接、保护层、弯钩等构造按 22G101 图集；",
    "2. 混凝土浇筑前应复核预埋件、套管、留洞位置；",
    "3. 后浇带、施工缝按设计留设并满足相应构造处理；模板拆除、养护按规范执行。",
    "",
    "八、其他",
    "1. 本图一律采用毫米为单位，标高以米计；",
    "2. 未尽事宜应遵守现行国家、地方有关规范规程；图中尺寸与详图冲突时以详图为准。",
]


def finalize_view(doc, margin_ratio=0.02, aspect=W_MM / H_MM):
    from ezdxf.bbox import extents as _extents
    msp = doc.modelspace()
    ext = _extents(msp, fast=False)
    if not ext.has_data:
        print("WARN: empty")
        return
    minx, miny = ext.extmin.x, ext.extmin.y
    maxx, maxy = ext.extmax.x, ext.extmax.y
    w, h = maxx - minx, maxy - miny
    mx, my = w * margin_ratio, h * margin_ratio
    msp.dxf.extmin = (minx - mx, miny - my, 0.0)
    msp.dxf.extmax = (maxx + mx, maxy + my, 0.0)
    msp.dxf.limmin = (minx - mx, miny - my)
    msp.dxf.limmax = (maxx + mx, maxy + my)
    cx, cy = (minx + maxx) / 2.0, (miny + maxy) / 2.0
    vh = max(h * (1 + 2 * margin_ratio), w * (1 + 2 * margin_ratio) / aspect)
    for vp in doc.viewports.get("*Active"):
        vp.dxf.center = (cx, cy)
        vp.dxf.height = vh
        vp.dxf.aspect_ratio = aspect
    print("  extents: (%.0f,%.0f)-(%.0f,%.0f) size %.0f x %.0f" % (minx, miny, maxx, maxy, w, h))


def add_line(msp, a, b, layer):
    ln = msp.add_line((a[0], a[1], 0.0), (b[0], b[1], 0.0))
    ln.dxf.layer = layer
    return ln


def add_text(msp, txt, x, y, h, layer, style="Standard"):
    t = msp.add_text(str(txt), dxfattribs={"height": h, "layer": layer,
                                           "style": style, "insert": (x, y)})
    return t


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--title", default="结构设计总说明")
    ap.add_argument("--drawno", default="结总-1")
    ap.add_argument("--date", default="2026.09.04")
    ap.add_argument("--designer", default="王工")
    a = ap.parse_args()

    s = 100.0
    FW, FH = W_MM * s, H_MM * s
    cx, cy = FW / 2.0, FH / 2.0
    doc = ezdxf.new("R2000", setup=True)
    apply_to_ezdxf(doc)
    doc.header["$INSUNITS"] = 4
    msp = doc.modelspace()

    # 外框 / 内框（留装订边）
    for x0, y0, x1, y1, lyr in (
        (0, 0, FW, FH, "S-PUB_TITLE"),
        (MARG_LT * s, MARG_LT * s, FW - MARG_RB * s, FH - MARG_RB * s, "S-PUB_TITLE"),
    ):
        add_line(msp, (x0, y0), (x1, y0), lyr)
        add_line(msp, (x1, y0), (x1, y1), lyr)
        add_line(msp, (x1, y1), (x0, y1), lyr)
        add_line(msp, (x0, y1), (x0, y0), lyr)

    # 标题栏（右下角）
    tbw = 240.0 * s
    tby0 = MARG_LT * s
    tbx0 = FW - MARG_RB * s - tbw
    tbx1 = FW - MARG_RB * s
    tby1 = tby0 + TB_H * s
    add_line(msp, (tbx0, tby0), (tbx1, tby0), "S-TAB")
    add_line(msp, (tbx1, tby0), (tbx1, tby1), "S-TAB")
    add_line(msp, (tbx1, tby1), (tbx0, tby1), "S-TAB")
    add_line(msp, (tbx0, tby1), (tbx0, tby0), "S-TAB")
    name_h = TB_H * s * 0.45
    y_split = tby0 + name_h
    add_line(msp, (tbx0, y_split), (tbx1, y_split), "S-TAB")
    cw = tbw / 4.0
    for k in range(1, 4):
        xv = tbx0 + cw * k
        add_line(msp, (xv, y_split), (xv, tby1), "S-TAB")
    add_text(msp, a.title, (tbx0 + tbx1) / 2.0, y_split - name_h / 2.0 - 150,
             3.4 * s, "S-TAB_TEXT")
    infos = ["比例 1:100", "图号 %s" % a.drawno, "日期 %s" % a.date, "设计 %s" % a.designer]
    for k, c in enumerate(infos):
        add_text(msp, c, tbx0 + cw * (k + 0.5) - cw / 2.0 + 150,
                 (y_split + tby1) / 2.0 - 150, 2.4 * s, "S-TAB_TEXT")

    # 图头（左上）
    add_text(msp, "%s  %s" % (a.title, a.drawno), MARG_LT * s + 300,
             FH - MARG_LT * s - 420, 4.2 * s, "S-TEXT")

    # 正文说明（左边缘起，逐行）
    x0 = MARG_LT * s + 400
    y0 = FH - MARG_LT * s - 1100
    lh = 460.0
    y = y0
    for line in NOTES:
        if not line:
            y -= lh * 0.5
            continue
        style = "TSSD_Rein" if ("%%" in line or "HRB400" in line or "钢筋" in line) else "Standard"
        add_text(msp, line, x0, y, 300, "S-TEXT", style=style)
        y -= lh
        if y < tby1 + 600:
            # 分栏：换到右半栏（简单两栏布局不足时截断提示）
            y = FH - MARG_LT * s - 1100 - lh * 6  # 简单折行到右栏（二栏）
            x0 = (FW - MARG_RB * s) / 2.0 + 400
            continue

    finalize_view(doc, aspect=FW / FH)
    fname = "结构设计总说明_notes_r2000.dxf"
    path = os.path.join(OUT, fname)
    os.makedirs(OUT, exist_ok=True)
    doc.saveas(path)
    errs = len(doc.audit().errors)
    ne = len(list(msp))
    print("[OK] %s 实体=%d 审计错误=%d  （钢筋默认：%s）" % (path, ne, errs, REBAR_GRADE_CN))


if __name__ == "__main__":
    main()
