# -*- coding: utf-8 -*-
"""结构平面布置图（轴网+柱+梁）——梁配筋图/楼板配筋图共用底图。

沿用 gen_frame_plan_col_detail.py 的平面图框架（2026-08-07 验收稿）：
- 轴网：横向 4000×5、纵向 7500×2；双侧标注（分跨尺寸 + 总尺寸），轴号圈上下/左右成对
- 柱 500×500 不填充，编号 KZ-1 放在柱右上角外侧
- 梁：边跨梁 250×600 靠外侧对齐；内部梁 200×400 居中；每道直线梁一个编号 KL1~
- 图名在图面下侧

本图作为「梁配筋平面图」「楼板配筋平面图」的共用布置底图。

用法：
    python gen_layout_plan.py
    python quick_validate.py ../output/结构平面布置图_梁板配筋底图_r2000.dxf
    python render_preview.py
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cad_standards as STD
import ezdxf
from ezdxf.enums import TextEntityAlignment

_BASE = os.path.dirname(os.path.abspath(__file__))
OUT = os.environ.get("CAD_DXF_OUT") or os.path.join(
    _BASE, os.pardir, "output", "结构平面布置图_梁板配筋底图_r2000.dxf")
OUT = os.path.normpath(OUT)

# ================= 平面图参数 =================
X_GAP, X_SPANS = 4000, 5          # 横向跨度 x 跨数
Y_GAP, Y_SPANS = 7500, 2          # 纵向跨度 x 跨数
COL_W, COL_H = 500, 500           # 柱截面 b x h
COL_TAG = "KZ-1"                  # 柱编号
EDGE_BEAM = (250, 600)            # 边跨梁 b x h（最外侧梁，靠外侧对齐）
INTERNAL_BEAM = (200, 400)        # 内部梁 b x h（居中）
TITLE = "结构平面布置图"             # 图名（图面下侧）
SCALE_TEXT = "1:100"

XS = [i * X_GAP for i in range(X_SPANS + 1)]
YS = [i * Y_GAP for i in range(Y_SPANS + 1)]
XNUM = STD.axis_labels(len(XS), kind="number")
YNUM = STD.axis_labels(len(YS), kind="letter")
COL_HX, COL_HY = COL_W / 2.0, COL_H / 2.0

AXIS_R, AXIS_H = STD.AXIS_R, STD.AXIS_H
DIM1, DIM2 = STD.DIM1, STD.DIM2
AXIS_ENDOFF, AXIS_CENTER = STD.AXIS_ENDOFF, STD.AXIS_CENTER

doc = ezdxf.new("R2000", setup=True)
STD.apply_to_ezdxf(doc)
msp = doc.modelspace()


def aligned_dim(p1, p2, distance, text=""):
    dim = msp.add_aligned_dim(p1=p1, p2=p2, distance=distance,
                              dimstyle=STD.DIMSTYLE_NAME,
                              dxfattribs={"layer": "S-DIM"})
    if text:
        dim.set_text(text)
    dim.render()


def put_text(txt, x, y, layer, height, style="Standard", center=False, color=None):
    attr = {"layer": layer, "height": height, "style": style}
    if color is not None:
        attr["color"] = color
    t = msp.add_text(txt, dxfattribs=attr)
    x0 = x - len(txt) * height * 0.31 if center else x
    t.set_placement((x0, y))
    return t


def draw_axis_grid(oy):
    for x in XS:
        msp.add_line((x, oy - AXIS_ENDOFF), (x, oy + YS[-1] + AXIS_ENDOFF),
                     dxfattribs={"layer": "S-DOTE"})
    for y in YS:
        msp.add_line((-AXIS_ENDOFF, oy + y), (XS[-1] + AXIS_ENDOFF, oy + y),
                     dxfattribs={"layer": "S-DOTE"})


def add_axis_text(text, x, y):
    t = msp.add_text(text, dxfattribs={"layer": "S-AXIS_TEXT", "height": AXIS_H,
                                       "style": "AXIS", "color": 7})
    t.set_placement((x - AXIS_H * 0.25 * len(text), y - AXIS_H * 0.35))


def draw_axis_marks(oy):
    for i, x in enumerate(XS):
        for y in [oy - AXIS_CENTER, oy + YS[-1] + AXIS_CENTER]:
            msp.add_circle((x, y), AXIS_R, dxfattribs={"layer": "S-AXIS"})
            add_axis_text(XNUM[i], x, y)
    for i, y in enumerate(YS):
        for x in [-AXIS_CENTER, XS[-1] + AXIS_CENTER]:
            msp.add_circle((x, oy + y), AXIS_R, dxfattribs={"layer": "S-AXIS"})
            add_axis_text(YNUM[i], x, oy + y)


def draw_dims(oy):
    # 横向：下侧 + 上侧（双侧标注）
    for i in range(len(XS) - 1):
        aligned_dim((XS[i], oy), (XS[i + 1], oy), -DIM1, text=str(XS[i + 1] - XS[i]))
    aligned_dim((XS[0], oy), (XS[-1], oy), -DIM2, text=str(XS[-1] - XS[0]))
    top = oy + YS[-1]
    for i in range(len(XS) - 1):
        aligned_dim((XS[i], top), (XS[i + 1], top), DIM1, text=str(XS[i + 1] - XS[i]))
    aligned_dim((XS[0], top), (XS[-1], top), DIM2, text=str(XS[-1] - XS[0]))
    # 纵向：左侧 + 右侧（双侧标注）
    for i in range(len(YS) - 1):
        aligned_dim((0, oy + YS[i]), (0, oy + YS[i + 1]), DIM1, text=str(YS[i + 1] - YS[i]))
    aligned_dim((0, oy + YS[0]), (0, oy + YS[-1]), DIM2, text=str(YS[-1] - YS[0]))
    right = XS[-1]
    for i in range(len(YS) - 1):
        aligned_dim((right, oy + YS[i]), (right, oy + YS[i + 1]), -DIM1, text=str(YS[i + 1] - YS[i]))
    aligned_dim((right, oy + YS[0]), (right, oy + YS[-1]), -DIM2, text=str(YS[-1] - YS[0]))


def beam_label(txt, x, y, rotation=0.0):
    t = msp.add_text(txt, dxfattribs={"layer": "S-BEAM_TEXT", "height": 250,
                                      "style": "AXIS", "rotation": rotation})
    t.set_placement((x, y), align=TextEntityAlignment.MIDDLE_CENTER)


def add_column(cx, cy, w, h, tag=None):
    hx, hy = w / 2.0, h / 2.0
    pts = [(cx - hx, cy - hy), (cx + hx, cy - hy),
           (cx + hx, cy + hy), (cx - hx, cy + hy), (cx - hx, cy - hy)]
    msp.add_lwpolyline(pts, dxfattribs={"layer": "S-COLU", "closed": True})
    if tag:
        t = msp.add_text(tag, dxfattribs={"layer": "S-COLU_NUM",
                                          "height": 220, "style": "AXIS"})
        t.set_placement((cx + hx + 10, cy + hy + 10),
                        align=TextEntityAlignment.BOTTOM_LEFT)


def draw_columns(oy, tag=COL_TAG):
    for y in YS:
        for x in XS:
            add_column(x, oy + y, COL_W, COL_H, tag)


def draw_beams(oy):
    AT_BEAM = {"layer": "S-BEAM_CON"}
    n_span = len(XS) - 1
    m_span = len(YS) - 1
    num = 0
    for y in reversed(YS):                       # 横梁：上 -> 下，每道梁一个编号
        num += 1
        edge = (y == YS[0] or y == YS[-1])
        bw, bh = EDGE_BEAM if edge else INTERNAL_BEAM
        for i in range(n_span):
            ax, bx = XS[i] + COL_HX, XS[i + 1] - COL_HX
            if bx <= ax:
                continue
            if y == YS[-1]:                      # 顶部边跨梁：靠外侧(上)对齐
                lo, hi = y, y + bw
            elif y == YS[0]:                     # 底部边跨梁：靠外侧(下)对齐
                lo, hi = y - bw, y
            else:                                # 内部梁：居中
                lo, hi = y - bw / 2.0, y + bw / 2.0
            msp.add_line((ax, oy + lo), (bx, oy + lo), AT_BEAM)
            msp.add_line((ax, oy + hi), (bx, oy + hi), AT_BEAM)
        # 标注放在中间跨的跨中；顶部/中间梁在上方、底部梁在下方
        mi = n_span // 2
        mx = (XS[mi] + XS[mi + 1]) / 2.0
        if y == YS[0]:
            beam_label("KL%d %dx%d" % (num, bw, bh), mx, oy + y - bw - 180)
        else:
            beam_label("KL%d %dx%d" % (num, bw, bh), mx,
                       oy + y + (bw if edge else 0) + 180)
    for x in XS:                                 # 竖梁：左 -> 右，每道梁一个编号
        num += 1
        edge = (x == XS[0] or x == XS[-1])
        bw, bh = EDGE_BEAM if edge else INTERNAL_BEAM
        for i in range(m_span):
            ay, by = YS[i] + COL_HY, YS[i + 1] - COL_HY
            if by <= ay:
                continue
            if x == XS[0]:                       # 左边跨梁：靠外侧(左)对齐
                lo, hi = x - bw, x
            elif x == XS[-1]:                    # 右边跨梁：靠外侧(右)对齐
                lo, hi = x, x + bw
            else:                                # 内部梁：居中
                lo, hi = x - bw / 2.0, x + bw / 2.0
            msp.add_line((lo, oy + ay), (lo, oy + by), AT_BEAM)
            msp.add_line((hi, oy + ay), (hi, oy + by), AT_BEAM)
        # 标注放在下边跨的跨中，置于梁左侧（旋转90°）
        ly = (YS[0] + YS[1]) / 2.0
        lx = x - (bw if edge else bw / 2.0) - 160
        beam_label("KL%d %dx%d" % (num, bw, bh), lx, oy + ly, rotation=90.0)


def draw_plan_title(oy):
    name = TITLE
    y = oy - AXIS_CENTER - 1400
    tit_h = 500
    x0 = XS[-1] / 2 - len(name) * tit_h * 0.45
    put_text(name, x0, y, "S-TEXT", tit_h)
    w = len(name) * tit_h * 0.9
    msp.add_line((x0, y - 200), (x0 + w, y - 200), dxfattribs={"layer": "S-TEXT"})
    put_text(SCALE_TEXT, x0 + w + 300, y, "S-TEXT", int(tit_h * 0.7))


OY = 0
draw_axis_grid(OY)
draw_axis_marks(OY)
draw_dims(OY)
draw_columns(OY)
draw_beams(OY)
draw_plan_title(OY)

# 注记
_note = ("注：柱 %s %dx%d（不填充）；梁：边跨 %dx%d（靠外侧对齐）、内部 %dx%d（居中）。" % (
    COL_TAG, COL_W, COL_H, EDGE_BEAM[0], EDGE_BEAM[1],
    INTERNAL_BEAM[0], INTERNAL_BEAM[1]))
put_text(_note, 0, OY + YS[-1] + AXIS_CENTER + 700, "S-TEXT", 260)


# ================= 收尾 =================
def finalize_view(doc, margin_ratio=0.04):
    from ezdxf.bbox import extents as _extents
    msp = doc.modelspace()
    ext = _extents(msp, fast=False)
    if not ext.has_data:
        print("WARN: empty")
        return
    minx, miny = ext.extmin.x, ext.extmin.y
    maxx, maxy = ext.extmax.x, ext.extmax.y
    w, h = maxx - minx, maxy - miny
    mx, my = w * margin_ratio, h * margin_ratio
    lo = (minx - mx, miny - my)
    hi = (maxx + mx, maxy + my)
    msp.dxf.extmin = (lo[0], lo[1], 0.0)
    msp.dxf.extmax = (hi[0], hi[1], 0.0)
    msp.dxf.limmin = lo
    msp.dxf.limmax = hi


finalize_view(doc)
doc.dxfversion = "AC1015"
os.makedirs(os.path.dirname(OUT), exist_ok=True)
doc.saveas(OUT)
print("saved ->", OUT)