# -*- coding: utf-8 -*-
"""离线生成结构标准层楼板配筋平面图 DXF（22G101-1 第 5 章 · 有梁楼盖分离式配筋）。

以结构平面布置图为底（轴网双侧标注 + 柱 + 框架梁），套 A1 图框，复制为楼板配筋模板：
- 板块编号 LBn（S-FLOOR_NUM）；同尺寸同配筋只完整注一块，其余只注板号
- 板底筋（分离式·双向贯通）B: X&Y 8@200（三级钢，S-FLOOR_DOWN_TEXT / S-FLOOR_DOWN_REIN）
- 板面支座负筋（分离式：面筋不贯通、只在支座布置，短筋+S-FLOOR_REIN）Φ8@200
- 图名写在图下方，套 A1 图框（GB/T 50001）

配筋默认 HRB400 三级钢，直径符号 %%132（TSSD_Rein 渲染）。

用法：
    python gen_slab_rebar_plan.py
    python gen_slab_rebar_plan.py --x-gap 4500 --x-spans 4 --y-gap 3000 --y-spans 2 \
        --col 500x500 --edge 250x500 --internal 200x400 --slab-rebar "%%1328@200"
"""
import argparse
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import ezdxf
import cad_standards as STD

_BASE = os.path.dirname(os.path.abspath(__file__))
OUT = (os.environ.get("CAD_DXF_OUT") or os.path.normpath(os.path.join(_BASE, os.pardir, "output")))

# 默认参数（对齐上次结构平面布置图）
X_SPANS, X_GAP = 4, 4500
Y_SPANS, Y_GAP = 2, 3000
COL = (500, 500)
EDGE_BEAM = (250, 500)
INTERNAL_BEAM = (200, 400)
SLAB_REBAR = "%%1328@200"        # 三级钢 8@200
TITLE = "结构标准层楼板配筋平面图"

AXIS_R = STD.AXIS_R
AXIS_H = STD.AXIS_H
DIM1 = STD.DIM1
DIM2 = STD.DIM2
AXIS_ENDOFF = STD.AXIS_ENDOFF
AXIS_CENTER = STD.AXIS_CENTER

# A1 图框（横向）
A1_W, A1_H = 841.0, 594.0
MARG_LT, MARG_RB = 25.0, 10.0
TBH = 60.0


def finalize_view(doc, margin_ratio=0.02, aspect=1.78):
    from ezdxf.bbox import extents as _extents
    msp = doc.modelspace()
    ext = _extents(msp, fast=False)
    if not ext.has_data:
        print("WARN: empty, skip finalize_view"); return
    minx, miny = ext.extmin.x, ext.extmin.y
    maxx, maxy = ext.extmax.x, ext.extmax.y
    w, h = maxx - minx, maxy - miny
    mx, my = w * margin_ratio, h * margin_ratio
    msp.dxf.extmin = (minx - mx, miny - my, 0.0)
    msp.dxf.extmax = (maxx + mx, maxy + my, 0.0)
    msp.dxf.limmin = (minx - mx, miny - my)
    msp.dxf.limmax = (maxx + mx, maxy + my)
    cx, cy = (minx + maxx) / 2.0, (miny + maxy) / 2.0
    vh = max(h * (1 + 2 * margin_ratio), w * (1 + 2 * margin_ratio) / aspect)
    for vp in doc.viewports.get("*Active"):
        vp.dxf.center = (cx, cy); vp.dxf.height = vh; vp.dxf.aspect_ratio = aspect
    print("  extents: (%.0f,%.0f)-(%.0f,%.0f) size %.0f x %.0f" % (minx, miny, maxx, maxy, w, h))


def add_line(msp, a, b, layer):
    ln = msp.add_line((a[0], a[1], 0.0), (b[0], b[1], 0.0)); ln.dxf.layer = layer; return ln


def add_rect(msp, x0, y0, x1, y1, layer):
    add_line(msp, (x0, y0), (x1, y0), layer)
    add_line(msp, (x1, y0), (x1, y1), layer)
    add_line(msp, (x1, y1), (x0, y1), layer)
    add_line(msp, (x0, y1), (x0, y0), layer)


def add_text(msp, txt, x, y, h, layer, style="Standard", center=False, rot=0):
    t = msp.add_text(str(txt), dxfattribs={"height": h, "layer": layer, "style": style,
                                           "insert": (x, y), "rotation": rot})
    if center:
        # 真正的中心居中：MIDDLE_CENTER（valign=2）。之前用 halign=1/valign=1 实为 BOTTOM_CENTER
        # （底边中线），文字在插入点上方展开，视觉不在板跨中心。
        from ezdxf.enums import TextEntityAlignment
        t.set_placement((x, y), align=TextEntityAlignment.MIDDLE_CENTER)
    return t


def axis_grid(msp, xs, ys):
    for x in xs:
        add_line(msp, (x, -AXIS_ENDOFF), (x, ys[-1] + AXIS_ENDOFF), "S-DOTE")
    for y in ys:
        add_line(msp, (-AXIS_ENDOFF, y), (xs[-1] + AXIS_ENDOFF, y), "S-DOTE")


def axis_marks(msp, xs, ys, xn, yn):
    for x, lab in zip(xs, xn):
        for cy in (-AXIS_CENTER, ys[-1] + AXIS_CENTER):
            msp.add_circle((x, cy), AXIS_R, dxfattribs={"layer": "S-AXIS"})
            add_text(msp, lab, x - AXIS_H * 0.25, cy - AXIS_H * 0.35, AXIS_H, "S-AXIS_TEXT", style="AXIS")
    for y, lab in zip(ys, yn):
        for cx in (-AXIS_CENTER, xs[-1] + AXIS_CENTER):
            msp.add_circle((cx, y), AXIS_R, dxfattribs={"layer": "S-AXIS"})
            add_text(msp, lab, cx - AXIS_H * 0.25, y - AXIS_H * 0.35, AXIS_H, "S-AXIS_TEXT", style="AXIS")


def dims(msp, xs, ys):
    top_y, right_x = ys[-1], xs[-1]
    # 双侧标注：底/顶、左/右 各 分跨+总
    for side_y in (0.0, top_y):
        d = -DIM1 if side_y == 0 else DIM1
        d2 = -DIM2 if side_y == 0 else DIM2
        for i in range(len(xs) - 1):
            msp.add_aligned_dim((xs[i], side_y), (xs[i + 1], side_y), d,
                                dimstyle=STD.DIMSTYLE_NAME, dxfattribs={"layer": "S-DIM"}).render()
        msp.add_aligned_dim((xs[0], side_y), (xs[-1], side_y), d2,
                            dimstyle=STD.DIMSTYLE_NAME, dxfattribs={"layer": "S-DIM"}).render()
    for side_x in (0.0, right_x):
        d = DIM1 if side_x == 0 else -DIM1
        d2 = DIM2 if side_x == 0 else -DIM2
        for i in range(len(ys) - 1):
            msp.add_aligned_dim((side_x, ys[i]), (side_x, ys[i + 1]), d,
                                dimstyle=STD.DIMSTYLE_NAME, dxfattribs={"layer": "S-DIM"}).render()
        msp.add_aligned_dim((side_x, ys[0]), (side_x, ys[-1]), d2,
                            dimstyle=STD.DIMSTYLE_NAME, dxfattribs={"layer": "S-DIM"}).render()


def columns(msp, xs, ys, cw, ch):
    hx, hy = cw / 2.0, ch / 2.0
    for y in ys:
        for x in xs:
            pts = [(x - hx, y - hy), (x + hx, y - hy), (x + hx, y + hy), (x - hx, y + hy), (x - hx, y - hy)]
            msp.add_lwpolyline(pts, dxfattribs={"layer": "S-COLU", "closed": True})


def beams(msp, xs, ys, edge_b, int_b):
    # X 向水平梁
    n = len(xs) - 1
    for y in ys:
        for i in range(n):
            bw = edge_b[0] if i == 0 or i == n - 1 else int_b[0]
            ax, bx = xs[i] + COL[0] / 2.0, xs[i + 1] - COL[0] / 2.0
            if bx > ax:
                add_line(msp, (ax, y - bw / 2), (bx, y - bw / 2), "S-BEAM_CON")
                add_line(msp, (ax, y + bw / 2), (bx, y + bw / 2), "S-BEAM_CON")
    # Y 向竖直梁
    m = len(ys) - 1
    for x in xs:
        for i in range(m):
            bw = edge_b[0] if i == 0 or i == m - 1 else int_b[0]
            ay, by = ys[i] + COL[1] / 2.0, ys[i + 1] - COL[1] / 2.0
            if by > ay:
                add_line(msp, (x - bw / 2, ay), (x - bw / 2, by), "S-BEAM_CON")
                add_line(msp, (x + bw / 2, ay), (x + bw / 2, by), "S-BEAM_CON")


def slab_rebar(msp, xs, ys, rb, slab_h, edge_bw):
    """分离式配筋（22G101-1 §5.2），2026-09-04 王工规范：
    1) 小说明放在图纸名称正下方（在 main 中处理）。
    2) 板编号去重：每个相同尺寸的板仅一块注全（名称+板厚+板底筋配筋），
       其余同尺寸板只注板名称。
    3) 上部钢筋（支座负筋·分离式）参考 22G101-1：
       画在梁中心线位置，自梁边向板内延伸 0.25×本跨短边长度，
       并在钢筋下侧标注延伸长度。
    （2026-09-16 王工调整：配筋标与延伸长度标字高统一 200；
      所有钢筋标注距钢筋边缘统一距离，配筋标/长度标分居钢筋两侧对称。）
    """
    UP_REIN_HALF = 30.0   # 钢筋半宽（SOLID 条半宽）
    TEXT_H = 200.0         # 配筋标+长度标统一字高
    TEXT_GAP = 100.0       # 标注距钢筋边缘统一距离
    REIN_W = 80.0
    # ---- 板编号去重·共享编号（2026-09-16 王工最终：同尺寸同配筋编号一致）----
    # 同尺寸同配筋的板【共享同一编号】：首次遇到某尺寸分配 Bn（该尺寸代表板完整注
    # 板号+板厚+X/Y配筋），后续同尺寸同配筋的板【也标注同一编号 Bn】（不递增、不重复 X/Y）。
    # 用 size_no 字典（尺寸 -> 编号），居中用 MIDDLE_CENTER。
    size_no = {}
    bno = 1
    for j in range(len(ys) - 1):
        for i in range(len(xs) - 1):
            cx0 = (xs[i] + xs[i + 1]) / 2.0
            cy0 = (ys[j] + ys[j + 1]) / 2.0
            span = (xs[i + 1] - xs[i], ys[j + 1] - ys[j])
            if span not in size_no:
                size_no[span] = bno   # 记录该尺寸的编号
                add_text(msp, "B%d  h=%d" % (bno, slab_h), cx0, cy0 + 320, 260,
                         "S-FLOOR_DOWN_TEXT", center=True)
                add_text(msp, "X%s" % rb, cx0, cy0 + 46, TEXT_H,
                         "S-FLOOR_DOWN_TEXT", style="TSSD_Rein", center=True)
                add_text(msp, "Y%s" % rb, cx0, cy0 - 234, TEXT_H,
                         "S-FLOOR_DOWN_TEXT", style="TSSD_Rein", center=True)
            else:
                # 同尺寸同配筋：复用同一编号（与代表板一致，不递增）
                nb = size_no[span]
                add_text(msp, "B%d" % nb, cx0, cy0, 260,
                         "S-FLOOR_DOWN_TEXT", center=True)
            bno += 1
    # ---- 上部附加负筋（分离式，参考 22G101-1 + TEST B 真图）：----
    # 自支座梁边向相邻两侧板各延伸 0.25×该板短跨；段位于每道支座梁、每跨跨中；
    # 加粗短筋(S-FLOOR_UP_REIN) + 文字"附加Φ8@200"；文字标注与钢筋平行
    # （竖筋段 rot=90，横筋段 rot=0）；长度只标最终结果（如 750），不标算式。
    LABEL = "%s" % rb
    # 横向支座梁（沿 X，负筋段为竖直）：标注与竖筋平行(rot=90)
    for jj, ya in enumerate(ys):
        for ii in range(len(xs) - 1):
            xm = (xs[ii] + xs[ii + 1]) / 2.0
            sx = xs[ii + 1] - xs[ii]
            eb = 0.25 * min(sx, ys[jj] - ys[jj - 1]) if jj > 0 else 0.0
            ea = 0.25 * min(sx, ys[jj + 1] - ys[jj]) if jj < len(ys) - 1 else 0.0
            if eb or ea:
                # 实心红色附加钢筋条（SOLID 填充，对齐目标图：红色条+旁标长度）
                msp.add_solid([(xm - 30, ya - eb), (xm + 30, ya - eb),
                               (xm - 30, ya + ea), (xm + 30, ya + ea)],
                              dxfattribs={"layer": "S-FLOOR_UP_REIN"})
                # 纵向负筋标文/长度同样贴近钢筋（参考横向调整）：标文紧贴左侧、长度紧贴右侧
                # D轴(最上横向梁 ys[-1])配筋标向下移1100躲避顶部轴圈
                lab_y = ya - 1100 if jj == len(ys) - 1 else ya
                add_text(msp, LABEL, xm - (UP_REIN_HALF + TEXT_GAP), lab_y, TEXT_H, "S-FLOOR_UP_TEXT", style="TSSD_Rein", rot=90)
                # 纵向尺寸标在竖筋中部、右侧（ya±120，贴近钢筋中部）
                # 纵向尺寸标在竖筋中部、右侧（以钢筋几何中线为基准）
                y_mid = ya + (ea - eb) / 2.0
                # 纵向长度右移100(xm+220)、两尺寸间距=钢筋长度一半(L/2)
                L = eb + ea
                if eb:
                    add_text(msp, "%d" % int(eb), xm + (UP_REIN_HALF + TEXT_GAP) + 200, y_mid - L / 4.0, TEXT_H, "S-FLOOR_UP_TEXT", rot=90)
                if ea:
                    add_text(msp, "%d" % int(ea), xm + (UP_REIN_HALF + TEXT_GAP) + 200, y_mid + L / 4.0, TEXT_H, "S-FLOOR_UP_TEXT", rot=90)
    # 纵向支座梁（沿 Y，负筋段为水平）：标注与横筋平行(rot=0)
    for ii, xa in enumerate(xs):
        for jj in range(len(ys) - 1):
            ym = (ys[jj] + ys[jj + 1]) / 2.0
            sy = ys[jj + 1] - ys[jj]
            el = 0.25 * min(xa - xs[ii - 1], sy) if ii > 0 else 0.0
            er = 0.25 * min(xs[ii + 1] - xa, sy) if ii < len(xs) - 1 else 0.0
            if el or er:
                msp.add_solid([(xa - el, ym - 30), (xa + er, ym - 30),
                               (xa - el, ym + 30), (xa + er, ym + 30)],
                              dxfattribs={"layer": "S-FLOOR_UP_REIN"})
                # 标文贴近钢筋：Φ8@200 在钢筋正上方(延伸段中心)，长度在正下方
                add_text(msp, LABEL, xa + (er - el) * 0.5, ym + (UP_REIN_HALF + TEXT_GAP), TEXT_H,
                         "S-FLOOR_UP_TEXT", style="TSSD_Rein", rot=0)
                # 横向长度标在钢筋下侧、距半个字高(90)
                if el:
                    add_text(msp, "%d" % int(el), xa - el * 0.5, ym - (UP_REIN_HALF + TEXT_GAP) - 200, TEXT_H,
                             "S-FLOOR_UP_TEXT")
                if er:
                    add_text(msp, "%d" % int(er), xa + er * 0.5, ym - (UP_REIN_HALF + TEXT_GAP) - 200, TEXT_H,
                             "S-FLOOR_UP_TEXT")


def plan_title(msp, xs, ys, title, scale):
    """图名写在图下方（底部轴圈之下）。"""
    name = title
    y = ys[0] - AXIS_CENTER - 1700
    tit_h = 500
    x0 = xs[-1] / 2 - len(name) * tit_h * 0.45
    msp.add_text(name, dxfattribs={"layer": "S-TEXT", "height": tit_h, "insert": (x0, y)})
    w = len(name) * tit_h * 0.9
    add_line(msp, (x0, y - 200), (x0 + w, y - 200), "S-TEXT")
    add_text(msp, scale, x0 + w + 300, y, int(tit_h * 0.7), "S-TEXT")


def a1_frame(msp, s):
    """A1 图框（居中于内容）：外框/内框 + 右下角标题栏。"""
    FW, FH = A1_W * s, A1_H * s
    from ezdxf.bbox import extents as _extents
    ex = _extents(msp, fast=False)
    minx, miny = ex.extmin.x, ex.extmin.y
    maxx, maxy = ex.extmax.x, ex.extmax.y
    cx0, cy0 = (minx + maxx) / 2.0, (miny + maxy) / 2.0
    x0, y0 = cx0 - FW / 2.0, cy0 - FH / 2.0
    add_rect(msp, x0, y0, x0 + FW, y0 + FH, "S-PUB_TITLE")
    ix0, iy0 = x0 + MARG_LT * s, y0 + MARG_LT * s
    iw, ih = FW - (MARG_LT + MARG_RB) * s, FH - (MARG_LT + MARG_RB) * s
    add_rect(msp, ix0, iy0, ix0 + iw, iy0 + ih, "S-PUB_TITLE")
    # 标题栏
    tbw, tbh = 240.0 * s, TBH * s
    bx0, by0 = ix0 + iw - tbw, iy0
    add_rect(msp, bx0, by0, bx0 + tbw, by0 + tbh, "S-TAB")
    yspl = by0 + tbh * 0.45
    add_line(msp, (bx0, yspl), (bx0 + tbw, yspl), "S-TAB")
    cw = tbw / 4.0
    for k in range(1, 4):
        add_line(msp, (bx0 + cw * k, yspl), (bx0 + cw * k, by0 + tbh), "S-TAB")
    add_text(msp, "楼板配筋平面图", bx0 + tbw / 2, yspl - tbh * 0.45 / 2 - 150, 3.4 * s,
             "S-TAB_TEXT", center=True)
    cells = ["比例 1:%d" % int(s), "图号 结构标准层楼板配筋平面图", "日期 2026.09.04", "设计 王工"]
    for k, c in enumerate(cells):
        add_text(msp, c, bx0 + cw * (k + 0.5) - cw / 2 + 150, (yspl + by0 + tbh) / 2 - 150,
                 2.4 * s, "S-TAB_TEXT")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--x-gap", type=int, default=X_GAP)
    ap.add_argument("--x-spans", type=int, default=X_SPANS)
    ap.add_argument("--y-gap", type=int, default=Y_GAP)
    ap.add_argument("--y-spans", type=int, default=Y_SPANS)
    ap.add_argument("--col", default="%dx%d" % COL)
    ap.add_argument("--edge", default="%dx%d" % EDGE_BEAM)
    ap.add_argument("--internal", default="%dx%d" % INTERNAL_BEAM)
    ap.add_argument("--slab-rebar", default=SLAB_REBAR)
    ap.add_argument("--slab-h", type=int, default=120, help="板厚 mm")
    ap.add_argument("--title", default=TITLE)
    ap.add_argument("--scale", type=float, default=100.0)
    a = ap.parse_args()

    cw, ch = (int(v) for v in a.col.lower().split("x"))
    eb = tuple(int(v) for v in a.edge.lower().split("x"))
    ib = tuple(int(v) for v in a.internal.lower().split("x"))
    xs = [i * a.x_gap for i in range(a.x_spans + 1)]
    ys = [i * a.y_gap for i in range(a.y_spans + 1)]
    xn = STD.axis_labels(len(xs), kind="number")
    yn = STD.axis_labels(len(ys), kind="letter")

    doc = ezdxf.new("R2000", setup=True)
    STD.apply_to_ezdxf(doc)
    doc.header["$INSUNITS"] = 4
    msp = doc.modelspace()

    axis_grid(msp, xs, ys)
    axis_marks(msp, xs, ys, xn, yn)
    dims(msp, xs, ys)
    columns(msp, xs, ys, cw, ch)
    beams(msp, xs, ys, eb, ib)
    slab_rebar(msp, xs, ys, a.slab_rebar, a.slab_h, EDGE_BEAM[0])
    plan_title(msp, xs, ys, TITLE, "1:100")
    # 小说明：放在图纸名称正下方（图名下方约 -800 处，居中）
    note_y = -AXIS_CENTER - 1700 - 800
    note_x = xs[-1] / 2
    add_text(msp, "未注明板钢筋均为%s; 未注明板编号均为B1" % a.slab_rebar,
             note_x - 2000, note_y, 260, "S-TEXT", style="TSSD_Rein")
    a1_frame(msp, a.scale)

    finalize_view(doc, aspect=1.48)
    doc.dxfversion = "AC1015"
    fname = "楼板配筋平面图_slab_%dx%d_%dx%d_r2000.dxf" % (a.x_gap, a.x_spans, a.y_gap, a.y_spans)
    path = os.path.join(OUT, fname)
    os.makedirs(OUT, exist_ok=True)
    doc.saveas(path)
    errs = len(doc.audit().errors)
    ne = len(list(msp))
    print("[OK] %s 实体=%d 审计错误=%d 板筋=%s" % (path, ne, errs, a.slab_rebar))


if __name__ == "__main__":
    main()
