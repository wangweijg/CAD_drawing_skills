# -*- coding: utf-8 -*-
"""最小 DXF 冒烟测试：确认 CAD 能否显示基本实体。"""
import ezdxf, os

OUT_DIR = os.path.normpath(
    os.path.join(os.path.dirname(os.path.abspath(__file__)), os.pardir, "output")
)
os.makedirs(OUT_DIR, exist_ok=True)

def make_test(version, filename):
    doc = ezdxf.new(version, setup=True)
    msp = doc.modelspace()
    doc.layers.add("TEST-RED", color=1)
    doc.layers.add("TEST-WHITE", color=7)
    doc.layers.add("TEST-GREEN", color=3)

    # 大十字线，确保跨越常见视口
    msp.add_line((-5000, 0), (25000, 0), dxfattribs={"layer": "TEST-RED", "lineweight": 30})
    msp.add_line((0, -5000), (0, 15000), dxfattribs={"layer": "TEST-RED", "lineweight": 30})
    # 对角大方框
    msp.add_lwpolyline([(0, 0), (20000, 0), (20000, 10000), (0, 10000), (0, 0)],
                       close=True, dxfattribs={"layer": "TEST-WHITE", "lineweight": 25})
    # 文字
    msp.add_text("SMOKE TEST - 如果能看到这条线，DXF 本身正常",
                 dxfattribs={"layer": "TEST-GREEN", "height": 500, "insert": (500, 5000)})
    msp.add_text("version: " + version, dxfattribs={"layer": "TEST-WHITE", "height": 400, "insert": (500, 4000)})
    # 圆
    msp.add_circle((10000, 5000), 2000, dxfattribs={"layer": "TEST-WHITE"})

    # 设置范围
    msp.dxf.extmin = (-6000, -6000, 0)
    msp.dxf.extmax = (26000, 12000, 0)
    doc.header["$LIMMIN"] = (-6000, -6000)
    doc.header["$LIMMAX"] = (26000, 12000)
    doc.header["$INSUNITS"] = 4  # mm
    doc.header["$LTSCALE"] = 100.0

    for vp in doc.viewports.get("*Active"):
        vp.dxf.center = (10000, 3000)
        vp.dxf.height = 20000
        vp.dxf.aspect_ratio = 1.5

    path = os.path.join(OUT_DIR, filename)
    doc.saveas(path)
    print(f"saved {version} -> {path}")

for v, fn in [("R12", "smoke_test_r12.dxf"), ("R2000", "smoke_test_r2000.dxf"), ("R2010", "smoke_test_r2010.dxf"), ("R2018", "smoke_test_r2018.dxf")]:
    try:
        make_test(v, fn)
    except Exception as e:
        print(f"FAIL {v}: {e}")

# 同时把 v7 另存为 R12/R2000 老格式做兼容测试（v7 源文件不存在时跳过，不影响冒烟）
src_path = os.path.join(OUT_DIR, "structural_demo_v7.dxf")
if not os.path.isfile(src_path):
    print("skip v7 兼容转换：先运行 structural_demo_template.py 生成 structural_demo_v7.dxf")
else:
    src = ezdxf.readfile(src_path)
    for v, fn in [("R2000", "structural_demo_v7_r2000.dxf"), ("R12", "structural_demo_v7_r12.dxf")]:
        try:
            src.dxfversion = {"R2000": "AC1015", "R12": "AC1009"}[v]
            out = os.path.join(OUT_DIR, fn)
            src.saveas(out)
            print(f"converted v7 -> {v} {out}")
        except Exception as e:
            print(f"convert fail {v}: {e}")
