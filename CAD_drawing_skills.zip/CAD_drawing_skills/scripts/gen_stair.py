# -*- coding: utf-8 -*-
"""离线生成楼梯平法施工图 DXF（22G101-2 板式楼梯 AT 平法）。

图面组成（上下两张）：
- 上图：楼梯平面图 —— 梯段(踏步线) + 上/下箭头 + 休息平台 + 梯段编号 AT1 + 轴网尺寸
- 下图：楼梯剖面图 —— 踏步(h×b) + 梯板厚 h + AT 平法标注（上部/下部/分布筋）+ 平台梁/平台板

22G101-2 AT 型板式楼梯平法注写示例：
    AT1  h=110                        （梯板型号 + 梯板厚度）
    12x150  300x150                   （踏步数 x 踏步高  踏步宽 x 踏步高）
    C10@200 (下部纵筋)  C8@200 (上部纵筋)  C8@250 (分布筋)

图层：S-DETAIL(轮廓) S-REIN(配筋) S-STIRRUP(分布) S-TEXT S-DIM  + 轴网层
复用 cad_standards.apply_to_ezdxf() 单源标准 + TSSD_Rein 配筋字体。

用法：
  python gen_stair.py
  python gen_stair.py --tread-w 300 --riser-h 150 --step-n 10 --slab-thick 110
"""
import argparse
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import ezdxf
from cad_standards import apply_to_ezdxf

_BASE = os.path.dirname(os.path.abspath(__file__))
OUT = (os.environ.get("CAD_DXF_OUT") or
       os.path.normpath(os.path.join(_BASE, os.pardir, "output")))

TREAD_W = 300.0      # 踏步宽 b
RISER_H = 150.0      # 踏步高 h
STEP_N = 10          # 踏步数
SLAB_THICK = 110.0   # 梯板厚
STAIR_WIDTH = 1200.0 # 梯段宽
PLATE_W = 600.0      # 平台板


def finalize_view(doc, margin_ratio=0.04, aspect=1.78):
    from ezdxf.bbox import extents as _extents
    msp = doc.modelspace()
    ext = _extents(msp, fast=False)
    if not ext.has_data:
        print("WARN: empty, skip finalize_view")
        return
    minx, miny = ext.extmin.x, ext.extmin.y
    maxx, maxy = ext.extmax.x, ext.extmax.y
    w, h = maxx - minx, maxy - miny
    mx, my = w * margin_ratio, h * margin_ratio
    msp.dxf.extmin = (minx - mx, miny - my, 0.0)
    msp.dxf.extmax = (maxx + mx, maxy + my, 0.0)
    msp.dxf.limmin = (minx - mx, miny - my)
    msp.dxf.limmax = (maxx + mx, maxy + my)
    cx, cy = (minx + maxx) / 2.0, (miny + maxy) / 2.0
    vh = max(h * (1 + 2 * margin_ratio), w * (1 + 2 * margin_ratio) / aspect)
    for vp in doc.viewports.get("*Active"):
        vp.dxf.center = (cx, cy)
        vp.dxf.height = vh
        vp.dxf.aspect_ratio = aspect
    print("  extents: (%.0f,%.0f)-(%.0f,%.0f) size %.0f x %.0f" % (minx, miny, maxx, maxy, w, h))


def add_line(msp, a, b, layer):
    ln = msp.add_line((a[0], a[1], 0.0), (b[0], b[1], 0.0))
    ln.dxf.layer = layer
    return ln


def add_rect(msp, cx, cy, w, h, layer):
    x0, y0 = cx - w / 2.0, cy - h / 2.0
    add_line(msp, (x0, y0), (x0 + w, y0), layer)
    add_line(msp, (x0 + w, y0), (x0 + w, y0 + h), layer)
    add_line(msp, (x0 + w, y0 + h), (x0, y0 + h), layer)
    add_line(msp, (x0, y0 + h), (x0, y0), layer)


def add_text(msp, txt, x, y, h, layer, style="Standard", rot=0, center=False):
    t = msp.add_text(str(txt), dxfattribs={
        "height": h, "layer": layer, "style": style,
        "insert": (x, y), "rotation": rot})
    if center:
        t.dxf.halign = 1
        t.dxf.valign = 1
    return t


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tread-w", type=float, default=TREAD_W)
    ap.add_argument("--riser-h", type=float, default=RISER_H)
    ap.add_argument("--step-n", type=int, default=STEP_N)
    ap.add_argument("--slab-thick", type=float, default=SLAB_THICK)
    a = ap.parse_args()

    tb, th2, n = a.tread_w, a.riser_h, a.step_n
    ht = a.slab_thick
    run = tb * n                  # 水平投影长
    rise = th2 * n                # 总提升
    sw = STAIR_WIDTH

    doc = ezdxf.new("R2000", setup=True)
    apply_to_ezdxf(doc)
    doc.header["$INSUNITS"] = 4
    msp = doc.modelspace()

    # ============ 上图：楼梯平面图 ============
    # 梯段轮廓（矩形）
    add_rect(msp, run / 2.0, 500.0, run, sw, "S-DETAIL")
    # 踏步线（垂直于梯段方向）
    for k in range(1, n):
        x = k * tb
        add_line(msp, (x, 500.0 - sw / 2.0), (x, 500.0 + sw / 2.0), "S-DETAIL")
    # 休息平台
    add_rect(msp, run + PLATE_W / 2.0, 500.0, PLATE_W, sw, "S-DETAIL")
    # 上/下箭头
    add_text(msp, "上", run * 0.25, 500.0 + sw / 2.0 + 250, 300, "S-TEXT", center=True)
    add_text(msp, "下", run * 0.75, 500.0 - sw / 2.0 - 250, 300, "S-TEXT", center=True)
    # 梯段编号
    add_text(msp, "AT1", run / 2.0, 500.0, 280, "S-TEXT", center=True)
    add_text(msp, "楼梯平面图  1:100", run / 2.0, 500.0 + sw / 2.0 + 900, 420,
             "S-TEXT", center=True)

    # ============ 下图：楼梯剖面图 ============
    dy = -4500.0
    # 支座 (下方平台梁)
    x0 = 200.0
    y_base = dy
    # 踏步轮廓：从 y_base 起，每步先平(tb)再升(th2)
    pt = [(x0, y_base)]
    cx_, cy_ = x0, y_base
    for k in range(n):
        cx_ += tb
        pt.append((cx_, cy_))
        cy_ += th2
        pt.append((cx_, cy_))
    # 上部平台梁位置
    x_top = cx_ + PLATE_W
    # 画梯板外轮廓线（沿踏步下缘 + 厚度方向）
    for a_, b_ in zip(pt, pt[1:]):
        add_line(msp, a_, b_, "S-DETAIL")
    # 梯板厚：踏步轮廓下移 ht 平行线（用与总斜线平行近似）
    # 直接从串底部做第二条轮廓（简化为底边水平 + 上边沿踏步）
    # 踏步水平筋线
    for yv in range(int(th2), int(rise), int(th2)):
        add_line(msp, (x0, y_base + yv), (x0 + run, y_base + yv), "S-STIRRUP")
    # 平台梁（矩形）
    add_rect(msp, x0 - 100.0, y_base + 100.0, 400.0, 300.0, "S-DETAIL")
    add_text(msp, "TL1", x0 - 100.0, y_base + 260.0, 220, "S-TEXT", center=True)
    # 平台（上方）
    add_rect(msp, x0 + run + PLATE_W / 2.0, y_base + rise + 60.0,
             PLATE_W, 200.0, "S-DETAIL")
    # 配筋符号沿下缘
    add_text(msp, "%%13210@200 (下部)  %%1328@200 (上部)  %%1328@250 (分布筋)",
             x0 + run / 2.0, y_base - 500, 220, "S-TEXT", style="TSSD_Rein", center=True)
    # AT 平法标注
    add_text(msp, "AT1  h=%d" % int(ht), x0 + run + 900.0, y_base + rise / 2.0,
             280, "S-TEXT", center=True)
    add_text(msp, "%dx%g  %gx%g" % (n, th2, tb, th2),
             x0 + run + 900.0, y_base + rise / 2.0 - 380, 260, "S-TEXT", center=True)
    # 尺寸：阶梯宽、总高
    add_text(msp, "水平净长 %d  总提升 %d" % (int(run), int(rise)),
             x0 + run / 2.0, y_base - 1400, 240, "S-DIM", center=True)
    add_text(msp, "楼梯剖面图  1:100", x0 + run / 2.0, y_base - 2100, 420,
             "S-TEXT", center=True)

    finalize_view(doc, margin_ratio=0.04, aspect=1.78)
    fname = "楼梯平法施工图_stair_r2000.dxf"
    path = os.path.join(OUT, fname)
    os.makedirs(OUT, exist_ok=True)
    doc.saveas(path)
    errs = len(doc.audit().errors)
    ne = len(list(msp))
    print("[OK] %s 实体=%d 审计错误=%d" % (path, ne, errs))


if __name__ == "__main__":
    main()
