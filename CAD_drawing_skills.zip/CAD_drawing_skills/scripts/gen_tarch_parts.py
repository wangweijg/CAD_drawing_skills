"""天正构件静态块库融合生成器（路线 A：离线复用，不依赖天正运行）。

把天正「图库管理 → 图块导出」得到的标准 .dwg 构件，按真实建筑尺寸插入到
新建或已有的 DXF 图纸中，支持缩放、旋转（改开向）、批量布置。

底层复用 scripts/tarch_block_bridge.py（ezdxf 侧 BLOCK 导入 + INSERT 复用）。

目录：tarch_parts/parts_catalog.json 记录每个构件的来源文件 / 块名 / 真实尺寸 /
默认图层。新增构件只需在天正导出 .dwg 入库 + 在目录加一条。

用法：
  python gen_tarch_parts.py --list
  python gen_tarch_parts.py insert M0920-单扇平开 3000 0 --out output/门测试.dxf --preview
  python gen_tarch_parts.py insert M0920-单扇平开 3000 0 --rotation 90 --scale 1.0 --out output/门旋转.dxf
  python gen_tarch_parts.py bench --out output/门bench.dxf --preview
  python gen_tarch_parts.py batch '[{"name":"M0920-单扇平开","x":3000,"y":0},{"name":"M0920-单扇平开","x":6000,"y":0,"rotation":90}]' --out output/门batch.dxf --preview
  python gen_tarch_parts.py insert M0920-单扇平开 3000 0 --base output/建筑平面_小户型_5600x6800_r2000.dxf --out output/建筑加门.dxf
"""
from __future__ import annotations

import argparse
import json
import math
import sys
from pathlib import Path

import ezdxf
from ezdxf.math import Matrix44

# 让本脚本能 import 同目录的 tarch_block_bridge.py
SCRIPT_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPT_DIR))
from tarch_block_bridge import import_blocks, insert_block, list_blocks  # noqa: E402

SKILL_DIR = SCRIPT_DIR.parent
PARTS_DIR = SKILL_DIR / "tarch_parts"
CATALOG = PARTS_DIR / "parts_catalog.json"


# ----------------------------------------------------------------------------
# 目录读写
# ----------------------------------------------------------------------------
def load_catalog() -> dict:
    if not CATALOG.exists():
        raise FileNotFoundError(f"找不到构件目录：{CATALOG}")
    data = json.loads(CATALOG.read_text(encoding="utf-8"))
    return data.get("parts", {})


def part_path(part: dict) -> Path:
    return PARTS_DIR / part["file"]


def list_parts() -> None:
    parts = load_catalog()
    print(f"构件目录（{len(parts)} 项）：")
    for name, p in parts.items():
        sc = p.get("scale", "auto")
        print(f"  - {name:24s} [{p.get('category','?')}]  块={p.get('block','(auto 2D)')}  放大={sc}  层={p.get('layer','-')}")
        print(f"      {p.get('note', '')}")


# ----------------------------------------------------------------------------
# 几何测量 + 缩放换算（把天正导出几何 → 建筑真实尺寸）
# ----------------------------------------------------------------------------
def measure_block_bbox(dwg_path: Path, block_name: str) -> tuple[float, float]:
    """测 2D 块的真实几何包围盒（Line/Arc/Circle/Lwpolyline），返回 (w, h)。"""
    doc = ezdxf.readfile(str(dwg_path))
    b = doc.blocks.get(block_name)
    if b is None:
        raise KeyError(f"块 {block_name} 不在 {dwg_path.name}")
    xs, ys = [], []
    for e in b:
        t = e.dxftype()
        if t == "LINE":
            xs += [e.dxf.start.x, e.dxf.end.x]
            ys += [e.dxf.start.y, e.dxf.end.y]
        elif t in ("ARC", "CIRCLE"):
            c = e.dxf.center
            r = e.dxf.radius
            xs += [c.x - r, c.x + r]
            ys += [c.y - r, c.y + r]
        elif t == "LWPOLYLINE":
            for pt in e.get_points("xy"):
                xs.append(pt[0])
                ys.append(pt[1])
    if not xs:
        return 1.0, 1.0
    return (max(xs) - min(xs)), (max(ys) - min(ys))


def measure_characteristic_length(dwg_path: Path, block_name: str) -> float:
    """测 2D 块的"特征长度"：门/窗叶长，取最长直线段或 ARC 半径（二者较大者）。

    门块里门叶长 = 弧线半径 = 最长竖直线段；bbox 宽会包含弧线外包，容易偏大，
    所以特征长度比 bbox 更适合做真实尺寸换算。
    """
    import math as _math
    doc = ezdxf.readfile(str(dwg_path))
    b = doc.blocks.get(block_name)
    if b is None:
        raise KeyError(f"块 {block_name} 不在 {dwg_path.name}")
    lengths = []
    for e in b:
        t = e.dxftype()
        if t == "LINE":
            lengths.append(_math.hypot(e.dxf.end.x - e.dxf.start.x,
                                       e.dxf.end.y - e.dxf.start.y))
        elif t == "LWPOLYLINE":
            pts = e.get_points("xy")
            for i in range(len(pts) - (0 if e.closed else 1)):
                a, bb = pts[i], pts[(i + 1) % len(pts)]
                lengths.append(_math.hypot(bb[0] - a[0], bb[1] - a[1]))
        elif t in ("ARC", "CIRCLE"):
            lengths.append(e.dxf.radius)
    return max(lengths) if lengths else 1.0


def auto_block_name(dwg_path: Path) -> str:
    """不指定块名时，选含 '2D' 的非匿名块（优先 2D 平面符号）。"""
    names = list_blocks(dwg_path)
    for n in names:
        if "2D" in n.upper():
            return n
    return names[0] if names else "$TCHSYS$DOOR2D"


def compute_scale(part: dict, dwg_path: Path, block_name: str) -> float:
    """返回插入缩放系数。

    优先：1) 目录显式 scale；2) nominal_mm / 特征长度（最长直线段或 ARC 半径）。
    """
    if "scale" in part and part["scale"]:
        return float(part["scale"])
    nominal = part.get("nominal_mm")
    if nominal:
        L = measure_characteristic_length(dwg_path, block_name)
        return float(nominal) / L if L else 1.0
    return 1.0


# ----------------------------------------------------------------------------
# 放置
# ----------------------------------------------------------------------------
def place(target_doc, name: str, x: float, y: float,
          rotation: float = 0.0, scale_override: float | None = None,
          scale_mul: float | None = None, layer: str | None = None) -> float:
    """在 target_doc 放置一个构件实例，返回实际使用的 scale。

    scale_override：绝对缩放值，直接覆盖目录真实尺寸（慎用，会丢失真实比例）。
    scale_mul：在目录真实尺寸上乘倍（如 1.1=放大 10%），推荐用它做"微调大小"。
    """
    parts = load_catalog()
    if name not in parts:
        raise KeyError(f"构件目录无 {name}；先 --list 查看可用项")
    p = parts[name]
    src = part_path(p)
    block = p.get("block") or auto_block_name(src)
    scale = compute_scale(p, src, block)
    if scale_override is not None:
        scale = float(scale_override)
    elif scale_mul is not None:
        scale = scale * float(scale_mul)
    import_blocks(src, target_doc, block_names=[block])
    layer = layer or p.get("layer")
    insert_block(target_doc, block, insert=(x, y), scale=scale, rotation=rotation, layer=layer)
    return scale


# ----------------------------------------------------------------------------
# 预览（手动展开 INSERT，scale→rotate→translate 顺序，避免 backend 缩放坑）
# ----------------------------------------------------------------------------
def _entity_to_segs(e, transform=None):
    """把单个实体 (LINE/LWPOLYLINE/ARC/CIRCLE) 转成线段列表；transform 为 Matrix44。"""
    segs = []
    if transform is None:
        def transform(p): return p
    t = e.dxftype()
    if t == "LINE":
        a = transform((e.dxf.start.x, e.dxf.start.y, 0.0))
        b = transform((e.dxf.end.x, e.dxf.end.y, 0.0))
        segs.append(((a[0], a[1]), (b[0], b[1])))
    elif t in ("ARC", "CIRCLE"):
        c = e.dxf.center
        r = e.dxf.radius
        a0, a1 = 0.0, math.tau
        if t == "ARC":
            a0, a1 = math.radians(e.dxf.start_angle), math.radians(e.dxf.end_angle)
        pts = [transform((c.x + r * math.cos(a), c.y + r * math.sin(a), 0.0))
               for a in [a0 + (a1 - a0) * i / 24 for i in range(25)]]
        for i in range(len(pts) - 1):
            segs.append(((pts[i][0], pts[i][1]), (pts[i + 1][0], pts[i + 1][1])))
    elif t == "LWPOLYLINE":
        pts = [transform((pp[0], pp[1], 0.0)) for pp in e.get_points("xy")]
        if e.closed:
            pts.append(pts[0])
        for i in range(len(pts) - 1):
            segs.append(((pts[i][0], pts[i][1]), (pts[i + 1][0], pts[i + 1][1])))
    return segs


def _collect_lines(target_doc):
    """收集模型空间里原有实体 + 所有 INSERT 展开后的几何，用于预览。"""
    segs = []
    for ent in target_doc.modelspace():
        t = ent.dxftype()
        if t == "INSERT":
            ins = ent
            block = target_doc.blocks.get(ins.dxf.name)
            if block is None:
                continue
            sx = ins.dxf.xscale if ins.dxf.xscale else 1.0
            sy = ins.dxf.yscale if ins.dxf.yscale else 1.0
            rot = math.radians(ins.dxf.rotation or 0.0)
            m = Matrix44.chain(
                Matrix44.scale(sx, sy, 1.0),
                Matrix44.z_rotate(rot),
                Matrix44.translate(ins.dxf.insert.x, ins.dxf.insert.y, 0.0),
            )
            for e in block:
                segs.extend(_entity_to_segs(e, transform=m.transform))
        else:
            segs.extend(_entity_to_segs(ent))
    return segs


def render_preview(target_doc, png_path: Path, title: str = "") -> None:
    import matplotlib
    matplotlib.use("Agg")
    matplotlib.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei']
    matplotlib.rcParams['axes.unicode_minus'] = False
    import matplotlib.pyplot as plt
    from matplotlib.font_manager import FontProperties

    segs = _collect_lines(target_doc)
    fig = plt.figure(figsize=(11, 5))
    ax = fig.add_axes([0.03, 0.08, 0.94, 0.84])
    for (a, b) in segs:
        ax.plot([a[0], b[0]], [a[1], b[1]], color="#222", lw=1.0)
    ax.set_aspect("equal")
    ax.autoscale()
    ax.margins(0.08)
    ax.set_axis_off()
    if title:
        fp = FontProperties(fname='C:/Windows/Fonts/simhei.ttf', size=12)
        fig.suptitle(title, fontproperties=fp)
    fig.savefig(str(png_path), dpi=120)
    plt.close(fig)


# ----------------------------------------------------------------------------
# 构建图纸
# ----------------------------------------------------------------------------
def new_doc(version: str = "R2018"):
    return ezdxf.new(version)


def build(placements: list[dict], out: Path, base: Path | None = None,
          preview: bool = False, title: str = "") -> None:
    """placements: [{"name","x","y","rotation","scale"(绝对覆盖),"scale_mul"(真实×倍),"layer"}, ...]"""
    doc = ezdxf.readfile(str(base)) if base else new_doc()
    used = []
    for pl in placements:
        s = place(doc, pl["name"], float(pl["x"]), float(pl["y"]),
                  rotation=float(pl.get("rotation", 0.0)),
                  scale_override=pl.get("scale"),
                  scale_mul=pl.get("scale_mul"),
                  layer=pl.get("layer"))
        used.append(f"{pl['name']}@({pl['x']},{pl['y']}) rot={pl.get('rotation',0)} scale={s:.2f}")
    doc.saveas(str(out))
    print(f"[OK] 已生成 {out}（{len(placements)} 个构件实例）")
    for u in used:
        print("     ", u)
    if preview:
        png = out.with_suffix(".png")
        render_preview(doc, png, title or out.stem)
        print(f"[OK] 预览 {png}")


# ----------------------------------------------------------------------------
# CLI
# ----------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser(description="天正构件静态块库融合生成器")
    ap.add_argument("--list", action="store_true", help="列出构件目录")
    ap.add_argument("cmd", nargs="?", help="insert / batch / bench")
    ap.add_argument("name", nargs="?", help="构件名（insert 用）")
    ap.add_argument("x", nargs="?", type=float, help="插入 x（insert 用）")
    ap.add_argument("y", nargs="?", type=float, help="插入 y（insert 用）")
    ap.add_argument("--rotation", type=float, default=0.0, help="旋转角（度），改开向")
    ap.add_argument("--scale", type=float, default=None, help="绝对缩放覆盖；不填用目录真实尺寸（慎用）")
    ap.add_argument("--scale-mul", type=float, default=None, help="在真实尺寸上乘倍（如 1.1=放大10%）")
    ap.add_argument("--layer", default=None, help="图层覆盖")
    ap.add_argument("--base", default=None, help="在已有 dxf 上叠加（不填则新建）")
    ap.add_argument("--out", default=None, help="输出 dxf 路径")
    ap.add_argument("--preview", action="store_true", help="同时渲染 PNG 预览")
    ap.add_argument("--title", default="", help="预览标题")
    ap.add_argument("rest", nargs="*", help="batch 的 json 串")
    args = ap.parse_args()

    if args.list or args.cmd is None and not args.name:
        if args.list:
            list_parts()
            return

    out_root = SKILL_DIR / "output"
    out_root.mkdir(exist_ok=True)

    if args.cmd == "insert":
        if not args.name:
            print("insert 需要构件名"); return
        out = Path(args.out) if args.out else out_root / "门测试.dxf"
        base = Path(args.base) if args.base else None
        build([{"name": args.name, "x": args.x or 0, "y": args.y or 0,
                "rotation": args.rotation, "scale": args.scale,
                "scale_mul": args.scale_mul, "layer": args.layer}],
              out, base=base, preview=args.preview,
              title=args.title or f"{args.name} @({args.x},{args.y}) rot={args.rotation}")
    elif args.cmd == "batch":
        import json as _json
        spec = args.rest[0] if args.rest else '[]'
        pls = _json.loads(spec)
        out = Path(args.out) if args.out else out_root / "门batch.dxf"
        build(pls, out, preview=args.preview, title=args.title or "批量构件布置")
    elif args.cmd == "bench":
        out = Path(args.out) if args.out else out_root / "门bench.dxf"
        build([
            {"name": "M0920-单扇平开", "x": 0,    "y": 0, "rotation": 0},
            {"name": "M0920-单扇平开", "x": 1500, "y": 0, "rotation": 0, "scale_mul": 1.2},
            {"name": "M0920-单扇平开", "x": 3000, "y": 0, "rotation": 90},
        ], out, preview=args.preview, title="天正门(M0920)→ezdxf 复用：原始 / 放大1.2× / 旋转90°改开向")
    else:
        list_parts()


if __name__ == "__main__":
    main()
