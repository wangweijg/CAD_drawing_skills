# -*- coding: utf-8 -*-
"""一张 DXF 内绘制两张图：
  图1 梁配筋平面图  (原点)    —— 轴网+柱+梁 + 平法集中标注/原位标注
  图2 楼板配筋平面图 (+100000) —— 轴网+柱+梁 + 板底筋注写 + 支座负筋
样式对齐技能包 cad_standards 与参考 liangpeijin.dxf / loubanpeijin.dxf。
布局要点（坐标级验证过无文字重叠）：
  - 柱号在柱右上角 (+480,+330)，字高 200
  - X 梁集中标注在梁旁竖排(rot=0)；Y 梁集中标注 rot=90 横排，KL9 在梁左、其余在梁右
  - X 梁原位标注行在梁面+600；Y 梁原位标注 rot=90 在梁右(+450)/KL9 梁左(-500)
"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cad_standards as STD
import ezdxf
from ezdxf.enums import TextEntityAlignment

OUT_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'output')
OUT_BEAM = os.path.join(OUT_DIR, '梁配筋平面图.dxf')
OUT_SLAB = os.path.join(OUT_DIR, '楼板配筋平面图.dxf')

# ---------------- 平面图参数 ----------------
X_GAP, X_SPANS = 4000, 5
Y_GAP, Y_SPANS = 7500, 2
COL_W, COL_H = 500, 500
EDGE_BEAM = (250, 600)
INT_BEAM = (200, 400)
OFF2 = 100000.0            # 图2 X 偏移
REBAR_H = 300.0            # 配筋文字字高 (对齐参考 300)
LINE_SP = 312.5            # 标注行距 (对齐参考)

XS = [i * X_GAP for i in range(X_SPANS + 1)]
YS = [i * Y_GAP for i in range(Y_SPANS + 1)]
XNUM = STD.axis_labels(len(XS), kind="number")
YNUM = STD.axis_labels(len(YS), kind="letter")

# 梁定义: (编号, 方向, 轴线位置, 宽, 高, 跨数)
BEAMS = [
    ("KL1", "X", 15000, 250, 600, 5),
    ("KL2", "X",  7500, 200, 400, 5),
    ("KL3", "X",     0, 250, 600, 5),
    ("KL4", "Y",     0, 250, 600, 2),
    ("KL5", "Y",  4000, 200, 400, 2),
    ("KL6", "Y",  8000, 200, 400, 2),
    ("KL7", "Y", 12000, 200, 400, 2),
    ("KL8", "Y", 16000, 200, 400, 2),
    ("KL9", "Y", 20000, 250, 600, 2),
]

# 配筋方案
EDGE_REBAR = "2%%13222+1%%13220;4%%13222"
INT_REBAR = "2%%13218;3%%13216"
EDGE_STIRRUP = "%%1328@100/200(2)"
INT_STIRRUP = "%%1328@200(2)"
EDGE_SIDE = "N4%%13212"
# 原位标注: (端支座, 中间支座)
EDGE_IP = ("3%%13218", "4%%13222")
INT_IP = ("2%%13218", "3%%13218")
EDGE_MID = "2%%13222"
INT_MID = "2%%13216"

doc = None
msp = None

def new_doc():
    global doc, msp
    doc = ezdxf.new("R2000", setup=True)
    STD.apply_to_ezdxf(doc)
    msp = doc.modelspace()

def aligned_dim(p1, p2, distance, text=""):
    dim = msp.add_aligned_dim(p1=p1, p2=p2, distance=distance,
                              dimstyle=STD.DIMSTYLE_NAME,
                              dxfattribs={"layer": "S-DIM"})
    if text:
        dim.set_text(text)
    dim.render()

def add_text(txt, x, y, layer, height, style="Standard", rot=0.0,
             align=None, color=None):
    attr = {"layer": layer, "height": height, "style": style}
    if color is not None:
        attr["color"] = color
    t = msp.add_text(txt, dxfattribs=attr)
    t.dxf.rotation = rot
    if align:
        t.set_placement((x, y), align=align)
    else:
        t.set_placement((x, y))
    return t

def put_mid(txt, x, y, layer, height, style="Standard", rot=0.0):
    return add_text(txt, x, y, layer, height, style, rot,
                    align=TextEntityAlignment.MIDDLE_CENTER)

def draw_axis_grid(ox, oy):
    for x in XS:
        msp.add_line((ox + x, oy - STD.AXIS_ENDOFF), (ox + x, oy + YS[-1] + STD.AXIS_ENDOFF),
                     dxfattribs={"layer": "S-DOTE"})
    for y in YS:
        msp.add_line((ox - STD.AXIS_ENDOFF, oy + y), (ox + XS[-1] + STD.AXIS_ENDOFF, oy + y),
                     dxfattribs={"layer": "S-DOTE"})

def add_axis_text(text, x, y):
    t = msp.add_text(text, dxfattribs={"layer": "S-AXIS_TEXT", "height": STD.AXIS_H,
                                       "style": "AXIS", "color": 7})
    t.set_placement((x - STD.AXIS_H * 0.25 * len(text), y - STD.AXIS_H * 0.35))

def draw_axis_marks(ox, oy):
    for i, x in enumerate(XS):
        for y in [oy - STD.AXIS_CENTER, oy + YS[-1] + STD.AXIS_CENTER]:
            msp.add_circle((ox + x, y), STD.AXIS_R, dxfattribs={"layer": "S-AXIS"})
            add_axis_text(XNUM[i], ox + x, y)
    for i, y in enumerate(YS):
        for x in [ox - STD.AXIS_CENTER, ox + XS[-1] + STD.AXIS_CENTER]:
            msp.add_circle((x, oy + y), STD.AXIS_R, dxfattribs={"layer": "S-AXIS"})
            add_axis_text(YNUM[i], x, oy + y)

def draw_dims(ox, oy):
    for i in range(len(XS) - 1):
        aligned_dim((ox + XS[i], oy), (ox + XS[i + 1], oy), -STD.DIM1, text=str(XS[i + 1] - XS[i]))
    aligned_dim((ox + XS[0], oy), (ox + XS[-1], oy), -STD.DIM2, text=str(XS[-1] - XS[0]))
    top = oy + YS[-1]
    for i in range(len(XS) - 1):
        aligned_dim((ox + XS[i], top), (ox + XS[i + 1], top), STD.DIM1, text=str(XS[i + 1] - XS[i]))
    aligned_dim((ox + XS[0], top), (ox + XS[-1], top), STD.DIM2, text=str(XS[-1] - XS[0]))
    for i in range(len(YS) - 1):
        aligned_dim((ox, oy + YS[i]), (ox, oy + YS[i + 1]), STD.DIM1, text=str(YS[i + 1] - YS[i]))
    aligned_dim((ox, oy + YS[0]), (ox, oy + YS[-1]), STD.DIM2, text=str(YS[-1] - YS[0]))
    right = ox + XS[-1]
    for i in range(len(YS) - 1):
        aligned_dim((right, oy + YS[i]), (right, oy + YS[i + 1]), -STD.DIM1, text=str(YS[i + 1] - YS[i]))
    aligned_dim((right, oy + YS[0]), (right, oy + YS[-1]), -STD.DIM2, text=str(YS[-1] - YS[0]))

def add_column(ox, oy, cx, cy, tag="KZ-1"):
    hx, hy = COL_W / 2.0, COL_H / 2.0
    pts = [(ox + cx - hx, oy + cy - hy), (ox + cx + hx, oy + cy - hy),
           (ox + cx + hx, oy + cy + hy), (ox + cx - hx, oy + cy + hy)]
    msp.add_lwpolyline(pts, dxfattribs={"layer": "S-COLU", "closed": True})
    # 柱号在柱右上角，避开梁标注
    add_text(tag, ox + cx + 480, oy + cy + 330, "S-COLU_NUM", 200)

def beam_rects(ox, oy):
    """返回梁双线轮廓线段 (layer S-BEAM_CON)。"""
    col_hw = COL_W / 2.0
    for name, direction, axis, bw, bh, spans in BEAMS:
        if direction == "X":
            y0, y1 = axis, axis + bw
            if axis == 0:                 # 下边跨: 靠外侧(向下)
                y0, y1 = axis - bw, axis
            x0, x1 = XS[0] + col_hw, XS[-1] - col_hw
            for yy in (y0, y1):
                msp.add_line((ox + x0, oy + yy), (ox + x1, oy + yy),
                             dxfattribs={"layer": "S-BEAM_CON"})
        else:
            x0, x1 = axis, axis + bw
            if axis == 0:
                x0, x1 = axis - bw, axis
            y0, y1 = YS[0] + col_hw, YS[-1] - col_hw
            for xx in (x0, x1):
                msp.add_line((ox + xx, oy + y0), (ox + xx, oy + y1),
                             dxfattribs={"layer": "S-BEAM_CON"})

def beam_face(direction, axis, bw):
    """梁两侧面 y/x 坐标 (内侧在下/左)."""
    if direction == "X":
        if axis == 0:
            return (axis - bw, axis)
        return (axis, axis + bw)
    else:
        if axis == 0:
            return (axis - bw, axis)
        return (axis, axis + bw)

def draw_plan(ox, oy, with_beam_labels=False):
    draw_axis_grid(ox, oy)
    draw_axis_marks(ox, oy)
    draw_dims(ox, oy)
    for cx in XS:
        for cy in YS:
            add_column(ox, oy, cx, cy)
    beam_rects(ox, oy)
    if with_beam_labels:
        for name, direction, axis, bw, bh, spans in BEAMS:
            if direction == "X":
                txt_y = axis + bw + 430 if axis else axis - 430
                put_mid("%s %dx%d" % (name, bw, bh), ox + 10000, oy + txt_y,
                        "S-BEAM_TEXT", 250)
            else:
                txt_x = axis - 410 if axis == XS[-1] else axis + 200
                put_mid("%s %dx%d" % (name, bw, bh), ox + txt_x, oy + 3750,
                        "S-BEAM_TEXT", 250, rot=90.0)

# ================= 图1: 梁配筋平面图 =================
def draw_beam_rebar(ox, oy):
    # X 向梁集中标注: 4 行竖排 rot=0 (梁号→箍筋→纵筋→侧面筋)
    # KL1 在梁下侧 (避开 Y 梁原位标注 sy=14750)；KL2 在梁下侧；KL3 在梁下侧(梁外, 避开底部总尺寸文字)
    x_stacks = {
        15000: [14400, 14088, 13775, 13463],
        7500:  [7000, 6688, 6375, 6063],
        0:     [-330, -643, -955, -1268],   # x 用 7000，避开总尺寸 "20000"
    }
    x_stack_x = {15000: 10000, 7500: 10000, 0: 7000}
    for axis, ys in x_stacks.items():
        if axis == 15000:
            num, bw, bh, spans = "KL1", 250, 600, 5
            rebar, stir, side = EDGE_REBAR, EDGE_STIRRUP, EDGE_SIDE
        elif axis == 7500:
            num, bw, bh, spans = "KL2", 200, 400, 5
            rebar, stir, side = INT_REBAR, INT_STIRRUP, None
        else:
            num, bw, bh, spans = "KL3", 250, 600, 5
            rebar, stir, side = EDGE_REBAR, EDGE_STIRRUP, EDGE_SIDE
        lines = ["%s(%d) %dx%d" % (num, spans, bw, bh), stir, rebar]
        if side:
            lines.append(side)
        for txt, yy in zip(lines, ys):
            add_text(txt, ox + x_stack_x[axis], oy + yy, "S-BEAM_TEXT", REBAR_H)

    # Y 向梁集中标注: 4 条 rot=90 横排，y=10000 (避开 X 梁原位标注行)
    # KL4-KL8 在梁右侧，KL9 在梁左侧
    y_stack_y = 10000
    for name, direction, axis, bw, bh, spans in BEAMS:
        if direction != "Y":
            continue
        if axis in (0, XS[-1]):
            num, bw, bh, spans = "KL4" if axis == 0 else "KL9", 250, 600, 2
            rebar, stir, side = EDGE_REBAR, EDGE_STIRRUP, EDGE_SIDE
        else:
            num = {4000: "KL5", 8000: "KL6", 12000: "KL7", 16000: "KL8"}[axis]
            bw, bh, spans = 200, 400, 2
            rebar, stir, side = INT_REBAR, INT_STIRRUP, None
        lines = ["%s(%d) %dx%d" % (num, spans, bw, bh), stir, rebar]
        if side:
            lines.append(side)
        if axis == XS[-1]:
            xs = [axis - 1188, axis - 875, axis - 563, axis - 250]
        else:
            xs = [axis + 250, axis + 563, axis + 875, axis + 1188]
        for txt, xx in zip(lines, xs):
            add_text(txt, ox + xx, oy + y_stack_y, "S-BEAM_TEXT", REBAR_H, rot=90.0)

    # 原位标注: X 梁支座上部筋 (rot=0, 梁面+600)
    sup_x = [250, 4250, 8250, 12250, 16250, 19750]
    xbeam_info = {b[2]: b for b in BEAMS if b[1] == "X"}
    for axis, edge in ((15000, True), (7500, False), (0, True)):
        bw = xbeam_info[axis][3]
        end_txt, mid_txt = EDGE_IP if edge else INT_IP
        face_hi = axis + bw if axis else 0          # 梁上边
        yy = face_hi + 600
        for i, sx in enumerate(sup_x):
            if i == 0:
                add_text(end_txt, ox + sx + 700, oy + yy, "S-BEAM_TEXT", REBAR_H)
            elif i == len(sup_x) - 1:
                t = add_text(end_txt, ox + sx - 700, oy + yy, "S-BEAM_TEXT", REBAR_H)
                t.set_placement((ox + sx - 700, oy + yy), align=TextEntityAlignment.RIGHT)
            else:
                # 中间支座文字右对齐放支座左侧，避免与 Y 梁原位标注(梁右)冲突
                t = add_text(mid_txt, ox + sx - 400, oy + yy, "S-BEAM_TEXT", REBAR_H)
                t.set_placement((ox + sx - 400, oy + yy), align=TextEntityAlignment.RIGHT)

    # 原位标注: Y 梁支座上部筋 (rot=90, 梁右+450 / KL9 梁左-500)
    sup_y = [250, 7750, 14750]
    for name, direction, axis, bw, bh, spans in BEAMS:
        if direction != "Y":
            continue
        edge = axis in (0, XS[-1])
        end_txt, mid_txt = EDGE_IP if edge else INT_IP
        ix = axis - 500 if axis == XS[-1] else axis + 450
        for i, sy in enumerate(sup_y):
            txt = end_txt if i in (0, len(sup_y) - 1) else mid_txt
            add_text(txt, ox + ix, oy + sy, "S-BEAM_TEXT", REBAR_H, rot=90.0)

    # 跨中下部筋 (X 梁, 每道两处)
    for axis, edge in ((15000, True), (7500, False), (0, True)):
        bw = xbeam_info[axis][3]
        mid_txt = EDGE_MID if edge else INT_MID
        if axis == 15000:
            yy = 14300
        elif axis == 7500:
            yy = 6500
        else:
            yy = -350
        for mx in (3000, 17000):
            add_text(mid_txt, ox + mx, oy + yy, "S-BEAM_TEXT", REBAR_H)

    put_mid("注：未注明钢筋均采用三级钢（HRB400）。梁：边跨250x600（靠外侧对齐）、内部200x400（居中）。",
            ox + 0, oy + 18800, "S-TEXT", 260)
    put_mid("梁配筋平面图", ox + 8425, oy - 4500, "S-TEXT", 500)
    put_mid("1:100", ox + 12500, oy - 4500, "S-TEXT", 350)

# ================= 图2: 楼板配筋平面图 =================
def neg_bar(ox, oy, p1, p2, hook):
    """支座负筋: 主线段 + 板内端弯钩 (S-FLOOR_UP_REIN)."""
    pts = [p1, p2, (p2[0] + hook[0], p2[1] + hook[1])]
    msp.add_lwpolyline(pts, dxfattribs={"layer": "S-FLOOR_UP_REIN"})

def draw_slab_rebar(ox, oy):
    col_hw = COL_W / 2.0
    # --- 支座负筋: X 向梁 (竖直负筋, 伸出 ln/4=1750) ---
    ext_x = 1750
    bar_xs = []
    for i in range(X_SPANS):
        x0 = XS[i] + 250
        for dx in (750, 2000, 3250):
            bar_xs.append(x0 + dx)
    for axis, bw in ((15000, 250), (7500, 200), (0, 250)):
        lo, hi = beam_face("X", axis, bw) if axis else (-bw, 0)
        if axis == 0:
            for x in bar_xs:
                neg_bar(ox, oy, (x, 0), (x, ext_x), (300, 0))
        elif axis == 15000:
            for x in bar_xs:
                neg_bar(ox, oy, (x, lo), (x, lo - ext_x), (300, 0))
        else:
            for x in bar_xs:
                neg_bar(ox, oy, (x, lo), (x, lo - ext_x), (300, 0))
                neg_bar(ox, oy, (x, hi), (x, hi + ext_x), (300, 0))
    # --- 支座负筋: Y 向梁 (水平负筋, 伸出 ln/4=875, 弯钩向下) ---
    ext_y = 875
    bar_ys = []
    for j in range(Y_SPANS):
        y0 = YS[j] + 250
        for dy in (1000, 3750, 6500):
            bar_ys.append(y0 + dy)
    for axis, bw in ((0, 250), (4000, 200), (8000, 200), (12000, 200),
                     (16000, 200), (20000, 250)):
        lo, hi = beam_face("Y", axis, bw) if axis else (-bw, 0)
        if axis == 0:
            for y in bar_ys:
                neg_bar(ox, oy, (0, y), (ext_y, y), (0, -300))
        elif axis == XS[-1]:
            for y in bar_ys:
                neg_bar(ox, oy, (axis, y), (axis - ext_y, y), (0, -300))
        else:
            for y in bar_ys:
                neg_bar(ox, oy, (lo, y), (lo - ext_y, y), (0, -300))
                neg_bar(ox, oy, (hi, y), (hi + ext_y, y), (0, -300))

    # --- 负筋配筋值 + 伸出长度 (代表标注, 逐梁写清) ---
    # X 向梁负筋 (rot=0)
    put_mid("%%1328@150", ox + 1350, oy + 14000, "S-FLOOR_UP_TEXT", REBAR_H)  # KL1
    put_mid("1750", ox + 1350, oy + 13000, "S-FLOOR_UP_TEXT", REBAR_H)
    put_mid("%%1328@150", ox + 5350, oy + 8550, "S-FLOOR_UP_TEXT", REBAR_H)   # KL2 上排
    put_mid("1750", ox + 5350, oy + 9550, "S-FLOOR_UP_TEXT", REBAR_H)
    put_mid("%%1328@150", ox + 5350, oy + 6650, "S-FLOOR_UP_TEXT", REBAR_H)   # KL2 下排
    put_mid("1750", ox + 5350, oy + 5650, "S-FLOOR_UP_TEXT", REBAR_H)
    put_mid("%%1328@150", ox + 1350, oy + 900, "S-FLOOR_UP_TEXT", REBAR_H)    # KL3
    put_mid("1750", ox + 1350, oy + 1900, "S-FLOOR_UP_TEXT", REBAR_H)
    # Y 向梁负筋 (rot=90, 统一放在 y=4000 排, 避开柱号/板注写)
    put_mid("%%1328@150", ox + 500, oy + 4000, "S-FLOOR_UP_TEXT", REBAR_H, rot=90.0)    # KL4
    put_mid("875", ox + 1000, oy + 4000, "S-FLOOR_UP_TEXT", REBAR_H, rot=90.0)
    put_mid("%%1328@150", ox + 4625, oy + 4000, "S-FLOOR_UP_TEXT", REBAR_H, rot=90.0)   # KL5
    put_mid("875", ox + 5350, oy + 4000, "S-FLOOR_UP_TEXT", REBAR_H, rot=90.0)
    put_mid("%%1328@150", ox + 8625, oy + 4000, "S-FLOOR_UP_TEXT", REBAR_H, rot=90.0)   # KL6
    put_mid("875", ox + 9350, oy + 4000, "S-FLOOR_UP_TEXT", REBAR_H, rot=90.0)
    put_mid("%%1328@150", ox + 19562, oy + 4000, "S-FLOOR_UP_TEXT", REBAR_H, rot=90.0)  # KL9
    put_mid("875", ox + 18875, oy + 4000, "S-FLOOR_UP_TEXT", REBAR_H, rot=90.0)

    # --- 板块集中标注 (一处详注) ---
    put_mid("WB1  h=120", ox + 2000, oy + 11700, "S-FLOOR_DOWN_TEXT", REBAR_H)
    put_mid("B:X%%1328@200", ox + 2000, oy + 11350, "S-FLOOR_DOWN_TEXT", REBAR_H)
    put_mid("Y:%%1328@200", ox + 2000, oy + 11000, "S-FLOOR_DOWN_TEXT", REBAR_H)

    put_mid("注：未注明板底筋均为%%1328@200，未注明支座负筋均为%%1328@150，板厚h=120，板编号WB1。",
            ox + 0, oy + 18800, "S-TEXT", 260)
    put_mid("楼板配筋平面图", ox + 8425, oy - 4500, "S-TEXT", 500)
    put_mid("1:100", ox + 12500, oy - 4500, "S-TEXT", 350)

# ================= 绘制 =================
def build_drawing(ox, draw_rebar_fn, out_path):
    new_doc()
    draw_plan(ox, 0)
    draw_rebar_fn(ox, 0)

    from ezdxf.bbox import extents as _extents
    ext = _extents(msp, fast=False)
    if ext.has_data:
        minx, miny = ext.extmin.x, ext.extmin.y
        maxx, maxy = ext.extmax.x, ext.extmax.y
        w, h = maxx - minx, maxy - miny
        mx, my = w * 0.03, h * 0.03
        msp.dxf.extmin = (minx - mx, miny - my, 0.0)
        msp.dxf.extmax = (maxx + mx, maxy + my, 0.0)
        msp.dxf.limmin = (minx - mx, miny - my)
        msp.dxf.limmax = (maxx + mx, maxy + my)

    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    doc.saveas(out_path)
    print("saved ->", out_path)

build_drawing(0, draw_beam_rebar, OUT_BEAM)
build_drawing(0, draw_slab_rebar, OUT_SLAB)
