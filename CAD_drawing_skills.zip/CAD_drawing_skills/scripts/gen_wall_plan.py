# -*- coding: utf-8 -*-
"""离线生成剪力墙平法施工图 DXF（22G101-1 第 3.2 章剪力墙平法）。

图面组成（上下两张，轴网相同）：
- 上图：剪力墙平面布置图 —— 四边墙双线(S-WALL 黄2) + 边缘构件(GBZ/YBZ 填充)
         + 连梁 LL + 连梁集中标注 + 墙身 Q 编号 + 洞口 + 轴网尺寸
- 下图：墙身详图（1 号节点）—— 墙身立面，示水平/竖向分布筋 + 拉筋 + 墙厚

★几何参数化（2026-09-04，第⑤步）：洞口/边缘构件/连梁不再写死于默认轴网，
默认在每个周边墙上按跨中自动开洞（随 --x-gaps/--y-gaps 定位），
--openings 可覆盖为 [方向:位置:宽度]，方向 y=水平墙,x=垂直墙，位置为主向坐标。

新增：--ybz N 把前 N 个角部边缘构件标为 YBZ（约束边缘构件）；
连梁集中标注（LLx(跨数) 截面 | 箍筋 | 上/下部纵筋 | 腰筋）。

图层对齐真实剪力墙图（S-WALL 黄2 / S-WALL_NUM 220）。

用法：
  python gen_wall_plan.py
  python gen_wall_plan.py --x-gaps 8400,8400,8400 --y-gaps 8400,8400 --wall-thick 250
  python gen_wall_plan.py --ybz 2 --openings y:0:8400:1800,x:0:4200:1800
"""
import argparse
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import ezdxf
from cad_standards import apply_to_ezdxf, axis_labels

_BASE = os.path.dirname(os.path.abspath(__file__))
OUT = (os.environ.get("CAD_DXF_OUT") or
       os.path.normpath(os.path.join(_BASE, os.pardir, "output")))

AXIS_R = 350.0
AXIS_H = 280.0
DIM1 = 1500.0
DIM2 = DIM1 + 750.0
AXIS_CENTER = DIM2 + 500.0 + AXIS_R

X_GAPS = [3600.0, 4200.0, 4200.0, 3600.0]
Y_GAPS = [4200.0, 4800.0, 4200.0]
WALL_TH = 200.0          # 墙厚
COUP_H = 800.0           # 连梁高
GBZ_W = 400.0            # 边缘构件宽
GBZ_T = 260.0            # 边缘构件厚
OPEN_W = 1800.0          # 默认洞口宽


def finalize_view(doc, margin_ratio=0.04, aspect=1.78):
    from ezdxf.bbox import extents as _extents
    msp = doc.modelspace()
    ext = _extents(msp, fast=False)
    if not ext.has_data:
        print("WARN: empty, skip finalize_view"); return
    minx, miny = ext.extmin.x, ext.extmin.y
    maxx, maxy = ext.extmax.x, ext.extmax.y
    w, h = maxx - minx, maxy - miny
    mx, my = w * margin_ratio, h * margin_ratio
    msp.dxf.extmin = (minx - mx, miny - my, 0.0)
    msp.dxf.extmax = (maxx + mx, maxy + my, 0.0)
    msp.dxf.limmin = (minx - mx, miny - my)
    msp.dxf.limmax = (maxx + mx, maxy + my)
    cx, cy = (minx + maxx) / 2.0, (miny + maxy) / 2.0
    vh = max(h * (1 + 2 * margin_ratio), w * (1 + 2 * margin_ratio) / aspect)
    for vp in doc.viewports.get("*Active"):
        vp.dxf.center = (cx, cy); vp.dxf.height = vh; vp.dxf.aspect_ratio = aspect
    print("  extents: (%.0f,%.0f)-(%.0f,%.0f) size %.0f x %.0f" % (minx, miny, maxx, maxy, w, h))


def add_line(msp, a, b, layer):
    ln = msp.add_line((a[0], a[1], 0.0), (b[0], b[1], 0.0)); ln.dxf.layer = layer; return ln


def add_rect(msp, x0, y0, x1, y1, layer, inflate=0.0):
    add_line(msp, (x0 - inflate, y0 - inflate), (x1 + inflate, y0 - inflate), layer)
    add_line(msp, (x1 + inflate, y0 - inflate), (x1 + inflate, y1 + inflate), layer)
    add_line(msp, (x1 + inflate, y1 + inflate), (x0 - inflate, y1 + inflate), layer)
    add_line(msp, (x0 - inflate, y1 + inflate), (x0 - inflate, y0 - inflate), layer)


def add_fill(msp, x0, y0, x1, y1, layer):
    msp.add_solid([(x0, y0), (x1, y0), (x0, y1), (x1, y1)], dxfattribs={"layer": layer})


def add_text(msp, txt, x, y, h, layer, style="Standard", center=False):
    t = msp.add_text(str(txt), dxfattribs={"height": h, "layer": layer, "style": style,
                                           "insert": (x, y)})
    if center:
        t.dxf.halign = 1; t.dxf.valign = 1
    return t


def draw_wall_run(msp, p1, p2, th, layer="S-WALL"):
    dx, dy = p2[0] - p1[0], p2[1] - p1[1]
    L = (dx * dx + dy * dy) ** 0.5
    if L < 1: return
    nx, ny = -dy / L, dx / L
    h2 = th / 2.0
    add_line(msp, (p1[0] + nx * h2, p1[1] + ny * h2), (p2[0] + nx * h2, p2[1] + ny * h2), layer)
    add_line(msp, (p1[0] - nx * h2, p1[1] - ny * h2), (p2[0] - nx * h2, p2[1] - ny * h2), layer)


def axis_draw(msp, xs, ys, xn, yn):
    xmax, ymax = xs[-1], ys[-1]
    for x in xs:
        add_line(msp, (x, -DIM1), (x, ymax + DIM2 + 500), "S-DOTE")
    for y in ys:
        add_line(msp, (-DIM1, y), (xmax + DIM2 + 500, y), "S-DOTE")
    for x, lab in zip(xs, xn):
        for cy in (-AXIS_CENTER, ymax + AXIS_CENTER):
            msp.add_circle((x, cy), AXIS_R, dxfattribs={"layer": "S-AXIS"})
            add_text(msp, lab, x, cy - AXIS_H / 2.0, AXIS_H, "S-AXIS_TEXT", style="AXIS", center=True)
    for y, lab in zip(ys, yn):
        for cx in (-AXIS_CENTER, xmax + AXIS_CENTER):
            msp.add_circle((cx, y), AXIS_R, dxfattribs={"layer": "S-AXIS"})
            add_text(msp, lab, cx - AXIS_H / 2.0, y, AXIS_H, "S-AXIS_TEXT", style="AXIS", center=True)


def auto_openings(xs, ys, ow):
    """每个周边墙在相邻两轴跨中自动开一个洞（洞口随轴网定位）。"""
    opens = []
    if len(xs) >= 3:
        m1 = (xs[1] + xs[2]) / 2.0 - ow / 2.0
        opens.append(("y", 0.0, m1, ow))
        opens.append(("y", ys[-1], m1, ow))
    else:
        cx = xs[-1] / 2.0 - ow / 2.0
        opens.append(("y", 0.0, cx, ow)); opens.append(("y", ys[-1], cx, ow))
    if len(ys) >= 3:
        m2 = (ys[1] + ys[2]) / 2.0 - ow / 2.0
        opens.append(("x", 0.0, m2, ow))
        opens.append(("x", xs[-1], m2, ow))
    else:
        cy = ys[-1] / 2.0 - ow / 2.0
        opens.append(("x", 0.0, cy, ow)); opens.append(("x", xs[-1], cy, ow))
    return opens


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--x-gaps", default=",".join(str(int(g)) for g in X_GAPS))
    ap.add_argument("--y-gaps", default=",".join(str(int(g)) for g in Y_GAPS))
    ap.add_argument("--wall-thick", type=float, default=WALL_TH)
    ap.add_argument("--coupling-h", type=float, default=COUP_H)
    ap.add_argument("--open-w", type=float, default=OPEN_W, help="洞口宽")
    ap.add_argument("--openings", default="", help="覆盖洞口：方向:坐标:起点:宽 逗号多段")
    ap.add_argument("--ybz", type=int, default=0, help="把前 N 个角部边缘构件标为 YBZ 约束边缘构件")
    a = ap.parse_args()

    xg = [float(x) for x in a.x_gaps.split(",") if x.strip()]
    yg = [float(y) for y in a.y_gaps.split(",") if y.strip()]
    th = a.wall_thick
    xs = [0.0]
    for g in xg: xs.append(xs[-1] + g)
    ys = [0.0]
    for g in yg: ys.append(ys[-1] + g)
    xn = axis_labels(len(xg) + 1, kind="number")
    yn = axis_labels(len(yg) + 1, kind="letter")
    xmax, ymax = xs[-1], ys[-1]

    # 洞口
    if a.openings.strip():
        ops = []
        for tok in a.openings.split(","):
            tok = tok.strip()
            if not tok: continue
            orient, coord, t0, w = tok.split(":")
            ops.append((orient, float(coord), float(t0), float(w)))
    else:
        ops = auto_openings(xs, ys, a.open_w)
    opens = [(orient, coord, t0, t0 + w, "LL%d" % (i + 1)) for i, (orient, coord, t0, w) in enumerate(ops, 1)]

    doc = ezdxf.new("R2000", setup=True)
    apply_to_ezdxf(doc)
    doc.header["$INSUNITS"] = 4
    msp = doc.modelspace()

    # 四边墙
    for p1, p2 in (((0, 0), (xmax, 0)), ((0, ymax), (xmax, ymax)), ((0, 0), (0, ymax)), ((xmax, 0), (xmax, ymax))):
        draw_wall_run(msp, p1, p2, th, "S-WALL")

    # 洞口 + 连梁 + 连梁集中标注
    for orient, coord, t0a, t1a, ld in opens:
        if orient == "y":
            y = coord
            add_fill(msp, t0a, y - th / 2.0, t1a, y + th / 2.0, "S-WALL_HATCH")
            add_rect(msp, t0a, y + th / 2.0, t1a, y + th / 2.0 + a.coupling_h, "S-COUP")
            # 集中标注（连梁下方/侧）
            xl = (t0a + t1a) / 2.0
            yl = y - th / 2.0 - 420
            add_text(msp, "%s (1) 200x800" % ld, xl, yl, 230, "S-COUP_TEXT", center=True)
            add_text(msp, "%%1328@100/200(2)", xl, yl - 300, 220, "S-COUP_TEXT", style="TSSD_Rein", center=True)
            add_text(msp, "2%%13220;2%%13220", xl, yl - 600, 220, "S-COUP_TEXT", style="TSSD_Rein", center=True)
        else:
            x = coord
            add_fill(msp, x - th / 2.0, t0a, x + th / 2.0, t1a, "S-WALL_HATCH")
            add_rect(msp, x + th / 2.0, t0a, x + th / 2.0 + a.coupling_h, t1a, "S-COUP")
            xl = x + th / 2.0 + a.coupling_h + 320
            yl = (t0a + t1a) / 2.0
            add_text(msp, "%s (1) 200x800" % ld, xl, yl, 230, "S-COUP_TEXT", center=True)
            add_text(msp, "%%1328@100/200(2)", xl, yl + 320, 220, "S-COUP_TEXT", style="TSSD_Rein", center=True)

    # 边缘构件：四角 + 洞口两侧；前 N 个角部标 YBZ
    corner = [(0, 0), (xmax, 0), (0, ymax), (xmax, ymax)]
    sides = []
    for orient, coord, t0a, t1a, _ld in opens:
        if orient == "y":
            sides += [(t0a, coord), (t1a, coord)]
        else:
            sides += [(coord, t0a), (coord, t1a)]
    ybz_n = min(a.ybz, len(corner))
    g = 1
    for i, (px, py) in enumerate(corner):
        pref = "YBZ" if i < ybz_n else "GBZ"
        add_fill(msp, px - GBZ_W / 2.0, py - GBZ_T / 2.0, px + GBZ_W / 2.0, py + GBZ_T / 2.0, "S-WALL_HATCH")
        add_rect(msp, px - GBZ_W / 2.0, py - GBZ_T / 2.0, px + GBZ_W / 2.0, py + GBZ_T / 2.0, "S-WALL_EDGE", inflate=20)
        add_text(msp, "%s%d" % (pref, g), px + GBZ_W / 2.0 + 400, py + 400, 260, "S-WALL_NUM")
        g += 1
    for (px, py) in sides:
        add_fill(msp, px - GBZ_W / 2.0, py - GBZ_T / 2.0, px + GBZ_W / 2.0, py + GBZ_T / 2.0, "S-WALL_HATCH")
        add_rect(msp, px - GBZ_W / 2.0, py - GBZ_T / 2.0, px + GBZ_W / 2.0, py + GBZ_T / 2.0, "S-WALL_EDGE", inflate=20)
        add_text(msp, "GBZ%d" % g, px + GBZ_W / 2.0 + 400, py + 400, 260, "S-WALL_NUM")
        g += 1

    # 墙身编号 + 配筋
    add_text(msp, "Q1", xmax / 2.0 - 900, th / 2.0 + 600, 260, "S-WALL_NUM", center=True)
    add_text(msp, "Q2", xmax / 2.0 - 900, ymax - th / 2.0 - 600, 260, "S-WALL_NUM", center=True)
    add_text(msp, "Q1 (2排) %%1328@200 水平+竖向  %%1326@600 拉筋",
             xmax / 2.0, th / 2.0 + 1500, 240, "S-WALL_TEXT", style="TSSD_Rein", center=True)

    axis_draw(msp, xs, ys, xn, yn)
    add_text(msp, "剪力墙平面布置图  1:100", xmax / 2.0, ymax + 2600, 420, "S-TEXT", center=True)

    # 墙身详图
    dy = -6500.0
    ph = 3260.0
    px0, py0 = 2500.0, dy
    add_rect(msp, px0, py0, px0 + th, py0 + ph, "S-DETAIL")
    hs = [py0 + 300 + k * 850 for k in range(4)]
    for hy in hs:
        add_line(msp, (px0 - 300, hy), (px0 + th + 300, hy), "S-WALL_REIN")
        add_text(msp, "%%1328@200", px0 + th + 500, hy - 100, 220, "S-WALL_TEXT", style="TSSD_Rein")
    for k in range(3):
        vx = px0 + (th / 4.0) * (k + 1)
        add_line(msp, (vx, py0), (vx, py0 + ph), "S-WALL_REIN")
    for vx in (px0 + th / 4.0, px0 + th * 0.75):
        for hy in hs:
            msp.add_circle((vx, hy), 60, dxfattribs={"layer": "S-WALL_REIN"})
    add_text(msp, "%%1328@200", px0 + th / 2.0, py0 - 500, 240, "S-WALL_TEXT", style="TSSD_Rein", center=True)
    add_text(msp, "墙厚 %d" % int(th), px0 + th / 2.0, py0 + ph + 300, 240, "S-WALL_TEXT", center=True)
    add_text(msp, "1 墙身详图 (Q1)  标高 -0.050 ~ +3.210  1:100",
             px0 + th / 2.0, py0 + ph + 1100, 300, "S-TEXT", center=True)

    finalize_view(doc, margin_ratio=0.03, aspect=1.78)
    fname = "剪力墙布置图_wall_r2000.dxf"
    path = os.path.join(OUT, fname)
    os.makedirs(OUT, exist_ok=True)
    doc.saveas(path)
    errs = len(doc.audit().errors)
    ne = len(list(msp))
    print("[OK] %s 实体=%d 审计错误=%d  洞口=%d 边缘构件=%d" % (path, ne, errs, len(ops), g - 1))


if __name__ == "__main__":
    main()
