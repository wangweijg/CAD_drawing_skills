"""生成一套"通用建筑符号"构件（按真实 mm 尺寸），注入 tarch_parts/ 并入库。

用途：天正「图块导出」需要人工操作 / 自动导出会弹对话框阻塞，无法完全无人值守。
本脚本用 ezdxf 按真实建筑尺寸画一套通用门/窗/楼梯/栏杆符号，走已有的
catalog + ezdxf 复用管线，使库立即可用、尺寸正确。后续用天正真实块替换同名条目即可。

每个 part：新建 R2018 dwg，内含一个 BLOCK（命名 GEN_*），块内几何直接画成真实 mm，
所以目录里 scale=1.0（特征长度=标称）。

用法：
  python make_generic_parts.py            # 生成全部通用件并入目录
  python make_generic_parts.py --check    # 只打印将生成/已存在哪些
"""
from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import ezdxf

SKILL_DIR = Path(__file__).resolve().parent.parent
PARTS_DIR = SKILL_DIR / "tarch_parts"
CATALOG = PARTS_DIR / "parts_catalog.json"


# ---------- 几何绘制辅助 ----------
def _line(b, x1, y1, x2, y2):
    b.add_line((x1, y1, 0), (x2, y2, 0))


def _arc(b, cx, cy, r, a0, a1):
    b.add_arc((cx, cy, 0), r, math.degrees(a0), math.degrees(a1))


# ---------- 各构件几何（真实 mm）----------
def door_double_1500():
    """双扇平开门 1500（每扇 750）：两铰链各一叶 + 内开弧 + 门框厚 50。"""
    W, L, T = 1500, 750, 50
    ents = []
    # 左扇：铰链 x=0
    ents += [(0, 0, 0, L), (T, 0, T, L), (0, L, T, L)]
    ents += [("ARC", 0, 0, L, math.radians(90), math.radians(0))]
    # 右扇：铰链 x=W
    ents += [(W, 0, W, L), (W - T, 0, W - T, L), (W - T, L, W, L)]
    ents += [("ARC", W, 0, L, math.radians(90), math.radians(180))]
    return "GEN_DOOR_DOUBLE", ents


def window_slide_1500():
    """推拉窗 1500（墙厚 200，两玻面 + 中梃 + 推拉短缝）。"""
    W, T = 1500, 200
    ents = []
    ents += [(0, 0, W, 0), (0, T, W, T)]          # 上下两玻面
    ents += [(W / 2, 0, W / 2, T)]                 # 中梃
    ents += [(W * 0.25, 0, W * 0.25, T), (W * 0.75, 0, W * 0.75, T)]  # 推拉分缝
    return "GEN_WIN_SLIDE", ents


def window_fixed_1800():
    """固定窗 1800（墙厚 200，两玻面 + 中梃）。"""
    W, T = 1800, 200
    ents = []
    ents += [(0, 0, W, 0), (0, T, W, T)]
    ents += [(W / 2, 0, W / 2, T)]
    return "GEN_WIN_FIXED", ents


def stair_run_1200():
    """单跑楼梯 1200 宽（踏步 12 级，级宽 200，跑深 2400）。"""
    RUN_W, STEP = 1100, 200
    RUN_L = 12 * STEP  # 2400
    ents = []
    ents += [(0, 0, RUN_W, 0), (0, RUN_L, RUN_W, RUN_L)]   # 近/远边
    for i in range(1, 13):
        x = i * STEP
        ents += [(x, 0, x, RUN_L)]                          # 踏步线
    # 上/下箭头（中心斜线）
    ents += [(RUN_W / 2, 80, RUN_W / 2, RUN_L - 80)]
    return "GEN_STAIR_RUN", ents


def railing_1000():
    """栏杆段 1000（栏高 1050，立杆间距 100）。"""
    L, H, TOP = 1000, 1050, 50
    ents = []
    ents += [(0, H, L, H)]                                  # 扶手顶
    for x in range(0, L + 1, 100):
        ents += [(x, H - TOP, x, H)]                        # 立杆
    return "GEN_RAIL", ents


PARTS = [
    ("门-双扇平开1500", "门", "GEN_DOOR_DOUBLE", "A-DOOR", 1500, door_double_1500,
     "通用双扇平开门（ezdxf 绘制，非天正块；可后续用天正导出替换）"),
    ("窗-推拉窗1500", "窗", "GEN_WIN_SLIDE", "A-WIND", 1500, window_slide_1500,
     "通用推拉窗（ezdxf 绘制，非天正块；可后续用天正导出替换）"),
    ("窗-固定窗1800", "窗", "GEN_WIN_FIXED", "A-WIND", 1800, window_fixed_1800,
     "通用固定窗（ezdxf 绘制，非天正块；可后续用天正导出替换）"),
    ("梯-单跑楼梯1200", "楼梯", "GEN_STAIR_RUN", "A-STAIR", 1200, stair_run_1200,
     "通用单跑楼梯段（ezdxf 绘制，非天正块；可后续用天正导出替换）"),
    ("栏-栏杆1000", "栏杆", "GEN_RAIL", "A-RAIL", 1000, railing_1000,
     "通用栏杆段（ezdxf 绘制，非天正块；可后续用天正导出替换）"),
]


def build_one(name, category, bname, ents):
    d = ezdxf.new("R2018")
    b = d.blocks.new(bname)
    for e in ents:
        if e[0] == "ARC":
            _arc(b, e[1], e[2], e[3], e[4], e[5])
        else:
            _line(b, e[0], e[1], e[2], e[3])
    return d


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--check", action="store_true", help="只打印，不写")
    args = ap.parse_args()

    cat = json.loads(CATALOG.read_text(encoding="utf-8")) if CATALOG.exists() else {"_comment": "", "parts": {}}
    parts = cat.setdefault("parts", {})
    for label, category, bname, layer, nominal, fn, note in PARTS:
        fname, ents = fn()
        out = PARTS_DIR / category / f"{label}.DWG"
        if out.exists():
            print(f"[SKIP] 已存在：{out}")
        else:
            if not args.check:
                d = build_one(fname, category, bname, ents)
                out.parent.mkdir(parents=True, exist_ok=True)
                d.saveas(str(out))
                print(f"[OK] 生成：{out}")
            else:
                print(f"[WILL] 将生成：{out}")
        # 目录条目
        parts.setdefault(label, {
            "category": category,
            "file": f"{category}/{label}.DWG",
            "block": bname,
            "layer": layer,
            "nominal_mm": nominal,
            "scale": 1.0,
            "note": note,
        })
    if not args.check:
        CATALOG.write_text(json.dumps(cat, ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"[OK] 已更新目录：{CATALOG}")


if __name__ == "__main__":
    main()
