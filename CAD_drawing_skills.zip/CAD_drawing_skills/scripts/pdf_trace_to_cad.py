# -*- coding: utf-8 -*-
"""
pdf_trace_to_cad.py —— 把【矢量 PDF 图纸】用「画图方式」逐路径描进已打开的 AutoCAD。

定位（姊妹脚本）：
    dxf_trace_to_cad.py  吃【任意 DXF】——源图已有完整 CAD 语义（图层/样式/标注）；
    pdf_trace_to_cad.py  吃【矢量 PDF】——PDF 没有图层/标注语义，只有路径与文字，
                         按「线宽分 3 层 + 真文字 + 填充退化边界」的规则描图。
                         SHX 文字在 PDF 里已是笔画轮廓（填充路径），描为边界多段线。

原样原则（不调整）：
    · 坐标：PDF 页面坐标 1pt=1 绘图单位，y 翻转（PDF 顶左原点 → CAD 底左原点），
            可选 --offset 整体平移；不做任何缩放/旋转/对齐修正。
    · 路径：一个 PDF 路径对象 = 一条 LWPOLYLINE（连续项串接，闭合路径闭合）；
            三次贝塞尔按 --curve-seg 段采样折线化（记 degraded）；qu 画四边形。
    · 分层：描边 width=0 → PDF-细线；width>0 → PDF-中线（层线宽随 PDF 值）；
            纯填充路径 → PDF-填充边界（只画边界，不重建填充）；真文字 → PDF-文字。
    · 文字：get_text 的真 span 用 CAD TEXT 重建（字体映射 黑体/宋体/仿宋，随旋转角）。
    · 颜色：PDF 描边色→就近 ACI（纯黑→7 随层）；填充只记边界。

用法：
    python pdf_trace_to_cad.py <in.pdf> --dry-run                     # 只统计
    python pdf_trace_to_cad.py <in.pdf> --save-as "J:\\out\\a.dwg"    # 描图并另存
    python pdf_trace_to_cad.py <in.pdf> --page 2 --current            # 画进当前文档
    python pdf_trace_to_cad.py <in.pdf> --offset 0,100000             # 整体平移
    python pdf_trace_to_cad.py <in.pdf> --report out.json

运行前提：同 dxf_trace_to_cad.py（AutoCAD + COM；本机 venv python：PyMuPDF + comtypes）。

2026-09-11 固化：源起 TEST-004 / S-G1#G2#G4#01.pdf（三层柱平面配筋图 结施-203）。
"""
import argparse
import array
import json
import math
import os
import sys
import time
import traceback
from collections import Counter

import pymupdf
from comtypes.automation import VARIANT

TTF_MAP = {"SimHei": "SimHei", "SimSun": "SimSun", "FangSong": "FangSong",
           "黑体": "SimHei", "宋体": "SimSun", "仿宋": "FangSong"}

LAYER_THIN = "PDF-细线"        # 描边 width==0
LAYER_MID = "PDF-中线"         # 描边 width>0（层线宽取 PDF 值×0.01mm 换算）
LAYER_FILL = "PDF-填充边界"     # 纯填充路径，只画边界
LAYER_TEXT = "PDF-文字"        # 真 TEXT


def log(msg):
    print(msg)
    sys.stdout.flush()


RPC_BUSY = (-2147418111, -2147417846)   # 被呼叫方拒绝 / 被呼叫方正在处理

def cretry(fn, *a, **kw):
    """COM 调用重试包装：CAD 忙碌（打开文档/缩放中）时拒绝呼叫属正常，退避重试。"""
    import comtypes
    wait = 0.4
    for i in range(50):
        try:
            return fn(*a, **kw)
        except comtypes.COMError as e:
            if getattr(e, "hresult", None) in RPC_BUSY and i < 49:
                time.sleep(min(wait, 2.0))
                wait *= 1.5
                continue
            raise
    raise RuntimeError("COM 调用持续被拒绝")


def P(x, y, z=0.0):
    v = VARIANT()
    v.value = array.array("d", [float(x), float(y), float(z)])
    return v


def varray(coords):
    v = VARIANT()
    v.value = array.array("d", [float(c) for c in coords])
    return v


def connect_cad():
    import comtypes.client
    try:
        app = comtypes.client.GetActiveObject("AutoCAD.Application")
        log("已连接运行中的 AutoCAD：%s" % app.Version)
    except Exception:
        log("未发现运行中的 CAD，尝试通过 COM 启动 AutoCAD …")
        app = comtypes.client.CreateObject("AutoCAD.Application")
        log("已启动 AutoCAD：%s" % app.Version)
    try:
        app.Visible = True
    except Exception:
        pass
    time.sleep(1.5)
    return app


def _norm(p):
    return os.path.normcase(os.path.abspath(p))


def save_confirmed(doc, app, target, report):
    """另存加固：释放占用（仅无未保存修改的文档）→ 直接另存 → 临时名兜底。"""
    target = os.path.abspath(target)
    os.makedirs(os.path.dirname(target), exist_ok=True)
    try:
        for d in list(app.Documents):
            try:
                full = cretry(lambda: d.FullName)
            except Exception:
                continue
            if full and _norm(full) == _norm(target) and cretry(lambda: d.Saved):
                log("目标被文档 %s 占用，已释放（无未保存修改）" % cretry(lambda: d.Name))
                cretry(d.Close, False)
    except Exception as e:
        log("释放占用检查失败（继续尝试保存）：%s" % str(e)[:80])
    try:
        cretry(doc.SaveAs, target)
        log("已保存：%s" % target)
        return
    except Exception as e:
        log("直接另存失败，改用临时名兜底：%s" % str(e)[:80])
    root, ext = os.path.splitext(target)
    tmp = "%s_tmp%d%s" % (root, int(time.time()), ext or ".dwg")
    try:
        cretry(doc.SaveAs, tmp)
        os.replace(tmp, target)
        log("已保存（经临时文件改名）：%s" % target)
    except Exception as e2:
        report["failed"].append(["SAVE", target, str(e2)[:120]])
        log("❌ 保存失败：%s" % str(e2)[:200])


# --------------------------------------------------------------------------
# PDF 路径 → 折线点串
# --------------------------------------------------------------------------
def flatten_path(d, curve_seg):
    """把一个 drawing 路径的 items 串接成 [(x,y)...] 折线（可多段，返回列表）。
    返回 (chains, stats)；chain = (points, closed)。"""
    chains = []
    cur = []
    closed = False
    stats = {"l": 0, "c": 0, "qu": 0, "re": 0}
    for it in d["items"]:
        k = it[0]
        if k == "l":
            a, b = it[1], it[2]
            if not cur:
                cur = [(a.x, a.y)]
            elif math.hypot(cur[-1][0] - a.x, cur[-1][1] - a.y) > 1e-6:
                chains.append((cur, closed))
                cur = [(a.x, a.y)]
            cur.append((b.x, b.y))
            stats["l"] += 1
        elif k == "c":
            p0 = it[1]
            p1, p2, p3 = it[2], it[3], it[4]
            if cur and math.hypot(cur[-1][0] - p0.x, cur[-1][1] - p0.y) > 1e-6:
                chains.append((cur, closed))
                cur = [(p0.x, p0.y)]
            elif not cur:
                cur = [(p0.x, p0.y)]
            for i in range(1, curve_seg + 1):
                t = i / curve_seg
                mt = 1 - t
                x = (mt**3 * p0.x + 3 * mt**2 * t * p1.x + 3 * mt * t**2 * p2.x + t**3 * p3.x)
                y = (mt**3 * p0.y + 3 * mt**2 * t * p1.y + 3 * mt * t**2 * p2.y + t**3 * p3.y)
                cur.append((x, y))
            stats["c"] += 1
        elif k == "qu":
            q = it[1]
            if cur:
                chains.append((cur, closed))
                cur = []
            pts = [(q.ul.x, q.ul.y), (q.ur.x, q.ur.y), (q.lr.x, q.lr.y), (q.ll.x, q.ll.y)]
            chains.append((pts, True))
            stats["qu"] += 1
        elif k == "re":
            r = it[1]
            if cur:
                chains.append((cur, closed))
                cur = []
            chains.append(([(r.x0, r.y0), (r.x1, r.y0), (r.x1, r.y1), (r.x0, r.y1)], True))
            stats["re"] += 1
    if d.get("closePath") and cur and len(cur) > 2:
        closed = True
    if cur:
        if len(cur) >= 2:
            chains.append((cur, closed))
        cur = []
    return chains, stats


def aci_from_rgb(rgb):
    if rgb is None:
        return 7
    r, g, b = [int(round(c * 255)) for c in rgb]
    if r < 40 and g < 40 and b < 40:
        return 7
    if abs(r - g) < 30 and abs(g - b) < 30:
        return 8 if r > 128 else 7
    return 7


# --------------------------------------------------------------------------
# 主流程
# --------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser(description="矢量 PDF → 画图方式描进 AutoCAD")
    ap.add_argument("pdf", help="输入 PDF 路径")
    ap.add_argument("--page", type=int, default=1, help="页码（默认第 1 页）")
    ap.add_argument("--save-as", default=None, help="画完另存路径")
    ap.add_argument("--current", action="store_true", help="画进当前活动文档（默认新建）")
    ap.add_argument("--offset", default="0,0", help="整体平移 dx,dy")
    ap.add_argument("--curve-seg", type=int, default=12, help="贝塞尔采样段数（默认 12）")
    ap.add_argument("--no-text", action="store_true", help="跳过真文字")
    ap.add_argument("--no-fill", action="store_true", help="跳过纯填充路径")
    ap.add_argument("--dry-run", action="store_true", help="只统计不连 CAD")
    ap.add_argument("--no-zoom", action="store_true", help="不执行 ZOOM E")
    ap.add_argument("--report", default=None, help="JSON 报告路径")
    ap.add_argument("--progress", type=int, default=500)
    args = ap.parse_args()

    dx, dy = [float(v) for v in args.offset.split(",")]
    report = {"source": args.pdf, "page": args.page, "offset": [dx, dy],
              "failed": [], "degraded": [], "drawn": {}, "paths": 0, "text_spans": 0}
    t0 = time.time()

    pdoc = pymupdf.open(args.pdf)
    page = pdoc[args.page - 1]
    H = page.rect.height
    log("源 PDF：%s  第 %d/%d 页  页面 %.0f×%.0f pt" % (
        os.path.basename(args.pdf), args.page, pdoc.page_count, page.rect.width, H))

    drawings = page.get_drawings()
    types = Counter(d["type"] for d in drawings)
    log("路径对象 %d 个（%s）" % (len(drawings), dict(types)))
    spans = []
    if not args.no_text:
        for b in page.get_text("dict")["blocks"]:
            if b["type"] != 0:
                continue
            for line in b["lines"]:
                dirv = line.get("dir", (1, 0))
                for s in line["spans"]:
                    if s["text"].strip():
                        spans.append((s, math.degrees(math.atan2(-dirv[1], dirv[0]))))
    log("真文字 span %d 个；曲线项 %d 个（各采样 %d 段）" % (
        len(spans), sum(1 for d in drawings for it in d["items"] if it[0] == "c"), args.curve_seg))

    if args.dry_run:
        n_pts = 0
        for d in drawings:
            ch, _ = flatten_path(d, args.curve_seg)
            n_pts += sum(len(c) for c, _ in ch)
        log("--dry-run：预计 LWPOLYLINE ≈ %d 条，总顶点 %d 个。" % (
            sum(len(flatten_path(d, args.curve_seg)[0]) for d in drawings), n_pts))
        return

    app = connect_cad()
    if args.current:
        doc = cretry(lambda: app.ActiveDocument)
    else:
        doc = cretry(lambda: app.Documents.Add())
    log("目标文档：%s" % cretry(lambda: doc.Name))

    # 分层
    for name, color, lw in ((LAYER_THIN, 7, None), (LAYER_MID, 7, 9),
                            (LAYER_FILL, 8, None), (LAYER_TEXT, 7, None)):
        try:
            o = cretry(doc.Layers.Add, name)
            cretry(lambda: setattr(o, "color", color))
            if lw:
                cretry(lambda: setattr(o, "Lineweight", lw))
        except Exception as e:
            report["failed"].append(["LAYER", name, str(e)[:80]])

    # 文字样式（TTF）
    for sty, ttf in (("PDF-黑体", "SimHei"), ("PDF-宋体", "SimSun"), ("PDF-仿宋", "FangSong")):
        try:
            o = cretry(doc.TextStyles.Add, sty)
            cretry(o.SetFont, ttf, False, False, 134, 0)
        except Exception as e:
            report["degraded"].append(["STYLE", sty, str(e)[:60]])

    space = cretry(lambda: doc.ModelSpace)

    # ① 路径
    drawn = Counter()
    for n, d in enumerate(drawings, 1):
        try:
            if d["type"] == "f" and args.no_fill:
                continue
            if d["type"] == "f":
                layer = LAYER_FILL
            elif (d.get("width") or 0) > 0:
                layer = LAYER_MID
            else:
                layer = LAYER_THIN
            chains, _ = flatten_path(d, args.curve_seg)
            for pts, closed in chains:
                if len(pts) < 2:
                    continue
                flat = []
                for x, y in pts:
                    flat.extend([x + dx, H - y + dy])   # PDF 顶左原点 → CAD 底左原点
                if len(flat) < 4:
                    continue
                o = cretry(space.AddLightWeightPolyline, varray(flat))
                if closed and len(pts) > 2:
                    cretry(lambda: setattr(o, "Closed", True))
                cretry(lambda: setattr(o, "Layer", layer))
                drawn["POLYLINE"] += 1
            report["paths"] += 1
        except Exception:
            report["failed"].append(["PATH", str(n), traceback.format_exc(limit=1).strip().splitlines()[-1]])
        if args.progress and n % args.progress == 0:
            log("  路径进度 %d/%d  已画 %s  耗时 %.1fs" % (n, len(drawings), dict(drawn), time.time() - t0))

    # ② 真文字
    for s, ang in spans:
        try:
            ox, oy = s["origin"]
            txt = s["text"]
            if not txt.strip():
                continue
            o = cretry(space.AddText, txt, P(ox + dx, H - oy + dy, 0), float(s["size"]))
            fname = s.get("font", "")
            sty = "PDF-黑体"
            if "SimSun" in fname or "宋" in fname:
                sty = "PDF-宋体"
            elif "Fang" in fname or "仿" in fname:
                sty = "PDF-仿宋"
            cretry(lambda: setattr(o, "StyleName", sty))
            if abs(ang) > 0.01:
                cretry(lambda: setattr(o, "Rotation", math.radians(ang)))
            cretry(lambda: setattr(o, "Layer", LAYER_TEXT))
            drawn["TEXT"] += 1
        except Exception as e:
            report["failed"].append(["TEXT", s.get("text", "")[:10], str(e)[:80]])
    report["text_spans"] = len(spans)

    report["drawn"] = dict(drawn)
    log("描图完成：%s" % dict(drawn))
    log("失败 %d 条，降级 %d 条" % (len(report["failed"]), len(report["degraded"])))
    for f in report["failed"][:10]:
        log("  [fail] %s" % (f,))

    if not args.no_zoom:
        try:
            cretry(doc.SendCommand, "_ZOOM\n_E\n\n")
        except Exception as e:
            log("ZOOM E 失败：%s" % e)
    try:
        report["cad_modelspace_count"] = cretry(lambda: space.Count)
    except Exception:
        pass

    if args.save_as:
        save_confirmed(doc, app, args.save_as, report)

    report["elapsed"] = round(time.time() - t0, 1)
    log("总耗时 %.1fs" % report["elapsed"])
    if args.report:
        with open(args.report, "w", encoding="utf-8") as f:
            json.dump(report, f, ensure_ascii=False, indent=2)
        log("报告：%s" % args.report)


if __name__ == "__main__":
    main()
