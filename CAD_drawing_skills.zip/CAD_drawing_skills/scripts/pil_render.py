﻿# -*- coding: utf-8 -*-
"""轻量 DXF -> PNG 渲染器 (PIL)，用于预览检查。"""
import sys, math, re
import ezdxf
from PIL import Image, ImageDraw, ImageFont

FONT_PATH = r"C:\Windows\Fonts\msyh.ttc"
FONT_FALLBACK = r"C:\Windows\Fonts\simhei.ttf"
import os
if not os.path.exists(FONT_PATH):
    FONT_PATH = FONT_FALLBACK

def decode(t):
    t = t.replace("%%132", "\u03a6").replace("%%130", "\u2160").replace("%%131", "\u2161")
    t = t.replace("%%c", "\u03c6").replace("%%d", "\u00b0").replace("%%p", "\u00b1")
    # 天正/CAD 原生 `\U+XXXX` unicode 转义 -> 真汉字
    # （技能真实模板 图框/柱表 即以该编码存中文，CAD 原生正常显示）
    t = re.sub(r"\\U\+([0-9A-Fa-f]{4})", lambda m: chr(int(m.group(1), 16)), t)
    return t

def load_font(px):
    try:
        return ImageFont.truetype(FONT_PATH, px)
    except Exception:
        return ImageFont.load_default()

def render(dxf_path, png_path, x0=None, x1=None, y0=None, y1=None,
           target_w=4200, bg="#FFFFFF", lw=2):
    doc = ezdxf.readfile(dxf_path)
    msp = doc.modelspace()
    from ezdxf.bbox import extents
    ex = extents(msp, fast=False)
    minx, maxx = ex.extmin.x, ex.extmax.x
    miny, maxy = ex.extmin.y, ex.extmax.y
    if x0 is None: x0, x1 = minx, maxx
    if y0 is None: y0, y1 = miny, maxy
    w, h = x1 - x0, y1 - y0
    scale = target_w / w
    H = int(h * scale) + 2
    W = target_w + 2
    img = Image.new("RGB", (W, H), bg)
    dr = ImageDraw.Draw(img)

    def WX(x): return (x - x0) * scale
    def WY(y): return (y1 - y) * scale

    def seg(p1, p2):
        dr.line([WX(p1[0]), WY(p1[1]), WX(p2[0]), WY(p2[1])], fill="black", width=lw)

    def poly(pts, closed=True):
        dr.polygon([(WX(p[0]), WY(p[1])) for p in pts], outline="black", width=lw) if closed else dr.line(
            [(WX(p[0]), WY(p[1])) for p in pts], fill="black", width=lw)

    cache = {}
    def font_for(px):
        k = int(px)
        if k not in cache:
            cache[k] = load_font(k)
        return cache[k]

    def render_text(txt, x, y, height, rot=0.0, halign=0, valign=0):
        s = decode(txt)
        if not s.strip():
            return
        fpx = max(4, int(round(height * scale)))
        f = font_for(fpx)
        tw = f.getlength(s)
        th = fpx
        # 锚点
        if halign == 1:   # center
            ax = x - tw / (2 * scale)
        elif halign == 2: # right
            ax = x - tw / scale
        else:
            ax = x
        if valign == 2:   # middle -> 文字中心在插入点，不再偏移
            ay = y
        elif valign == 1: # bottom -> 文字底部对齐插入点
            ay = y + th / (2 * scale)
        else:             # baseline(0)/top(3)
            ay = y
        tmp = Image.new("RGBA", (max(1, int(tw) + 4), th + 4), (0, 0, 0, 0))
        td = ImageDraw.Draw(tmp)
        td.text((2, 2), s, font=f, fill="black")
        if rot:
            tmp = tmp.rotate(-rot, expand=True, resample=Image.BICUBIC)
        iw, ih = tmp.size
        img.paste(tmp, (int(round(WX(ax) - iw / 2)), int(round(WY(ay) - ih / 2))), tmp)

    def render_entity(e):
        t = e.dxftype()
        if t == "LINE":
            seg(e.dxf.start, e.dxf.end)
        elif t == "CIRCLE":
            cx, cy, r = e.dxf.center.x, e.dxf.center.y, e.dxf.radius
            rr = r * scale
            dr.ellipse([WX(cx) - rr, WY(cy) - rr, WX(cx) + rr, WY(cy) + rr],
                       outline="black", width=lw)
        elif t == "LWPOLYLINE":
            pts = [(p[0], p[1]) for p in e.get_points()]
            if e.closed and pts:
                pts.append(pts[0])
            for a, b in zip(pts, pts[1:]):
                seg(a, b)
        elif t == "POLYLINE":
            v = [p.dxf.location for p in e.vertices]
            pts = [(p.x, p.y) for p in v]
            if e.is_closed and pts:
                pts.append(pts[0])
            for a, b in zip(pts, pts[1:]):
                seg(a, b)
        elif t == "TEXT":
            render_text(e.dxf.text, e.dxf.insert.x, e.dxf.insert.y,
                        e.dxf.height, getattr(e.dxf, "rotation", 0),
                        getattr(e.dxf, "halign", 0), getattr(e.dxf, "valign", 0))
        elif t == "MTEXT":
            render_text(e.plain_text(), e.dxf.insert.x, e.dxf.insert.y,
                        e.dxf.char_height, getattr(e.dxf, "rotation", 0))
        elif t == "DIMENSION":
            for ve in e.virtual_entities():
                render_entity(ve)
        elif t == "SOLID":
            try:
                dr.polygon([(WX(p.x), WY(p.y)) for p in
                            (e.dxf.vtx0, e.dxf.vtx1, e.dxf.vtx2, e.dxf.vtx3)],
                           fill="black")
            except Exception:
                pass
        elif t == "HATCH":
            for p in e.paths:
                try:
                    for edge in p:
                        if hasattr(edge, "start") and hasattr(edge, "end"):
                            seg(edge.start, edge.end)
                except Exception:
                    pass

    for e in msp:
        try:
            render_entity(e)
        except Exception as ex:
            print("skip", e.dxftype(), type(ex).__name__, ex)
    img.save(png_path)
    print("rendered ->", png_path, img.size)

if __name__ == "__main__":
    src = sys.argv[1]; dst = sys.argv[2]
    x0 = float(sys.argv[3]) if len(sys.argv) > 3 else None
    x1 = float(sys.argv[4]) if len(sys.argv) > 4 else None
    y0 = float(sys.argv[5]) if len(sys.argv) > 5 else None
    y1 = float(sys.argv[6]) if len(sys.argv) > 6 else None
    render(src, dst, x0, x1, y0, y1)
