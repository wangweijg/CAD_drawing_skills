# -*- coding: utf-8 -*-
"""生成后自检：跑一遍绘图脚本并审计产出的 DXF。

用法：
    python quick_validate.py                 # 跑 structural_demo_template.py（输出到临时目录）后审计
    python quick_validate.py xxx.dxf         # 直接审计一个已有 DXF
"""
import os, sys, subprocess, tempfile, shutil

HERE = os.path.dirname(os.path.abspath(__file__))
GEN = os.path.join(HERE, "structural_demo_template.py")


def audit(dxf_path):
    import ezdxf
    from ezdxf.audit import Auditor
    doc = ezdxf.readfile(dxf_path)
    a = Auditor(doc)
    a.run()
    ents = len(list(doc.modelspace()))
    h = doc.header
    print(f"OK | entities={ents} | errors={len(a.errors)} | "
          f"EXTMIN=({h['$EXTMIN'][0]:.0f},{h['$EXTMIN'][1]:.0f}) | "
          f"EXTMAX=({h['$EXTMAX'][0]:.0f},{h['$EXTMAX'][1]:.0f}) | "
          f"LIMMAX=({h['$LIMMAX'][0]:.0f},{h['$LIMMAX'][1]:.0f})")
    for e in a.errors[:5]:
        print("  AUDIT ERROR:", e)
    return len(a.errors) == 0


def main():
    if len(sys.argv) > 1:                       # 审计已有文件
        target = os.path.abspath(sys.argv[1])
        assert os.path.exists(target), f"DXF not found: {target}"
        return audit(target)

    gen = GEN
    assert os.path.exists(gen), f"generator not found: {gen}"
    tmpdir = tempfile.mkdtemp(prefix="cad_validate_")
    try:
        out = os.path.join(tmpdir, "validate_output.dxf")
        env = dict(os.environ, CAD_DXF_OUT=out)
        r = subprocess.run([sys.executable, gen], env=env,
                           capture_output=True, text=True)
        if r.returncode != 0:
            print(r.stdout[-2000:]); print(r.stderr[-2000:])
            raise RuntimeError("generator failed")
        assert os.path.exists(out), "DXF was not created"
        return audit(out)
    finally:
        shutil.rmtree(tmpdir, ignore_errors=True)


if __name__ == "__main__":
    try:
        sys.exit(0 if main() else 1)
    except Exception as e:
        print(f"VALIDATION FAILED: {type(e).__name__}: {e}")
        sys.exit(1)
