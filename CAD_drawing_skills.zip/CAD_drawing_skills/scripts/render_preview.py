# -*- coding: utf-8 -*-
"""把 DXF 渲染成 PNG，用于生成后视觉自检。"""
import sys, os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties
import ezdxf
from ezdxf.addons.drawing import RenderContext, Frontend
from ezdxf.addons.drawing.matplotlib import MatplotlibBackend
from ezdxf.addons.drawing.config import Configuration, ColorPolicy

plt.rcParams["font.sans-serif"] = ["SimHei", "Microsoft YaHei", "SimSun"]
plt.rcParams["axes.unicode_minus"] = False


def render(dxf_path, png_path, bg="#FFFFFF", dpi=170):
    doc = ezdxf.readfile(dxf_path)
    msp = doc.modelspace()
    fig = plt.figure(figsize=(20, 14))
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_facecolor(bg)
    fig.patch.set_facecolor(bg)
    ctx = RenderContext(doc)
    out = MatplotlibBackend(ax)
    cfg = Configuration(
        color_policy=ColorPolicy.BLACK,   # 白底出图，统一黑线，便于看清结构
        lineweight_scaling=1.0,
    )
    Frontend(ctx, out, config=cfg).draw_layout(msp, finalize=True)
    fig.savefig(png_path, dpi=dpi, facecolor=bg)
    plt.close(fig)
    print("rendered ->", png_path)


if __name__ == "__main__":
    base = os.path.normpath(
        os.path.join(os.path.dirname(os.path.abspath(__file__)), os.pardir, "output")
    )
    targets = sys.argv[1:] or ["structural_demo_v7_r2000.dxf"]
    for name in targets:
        src = os.path.join(base, name)
        dst = os.path.join(base, os.path.splitext(name)[0] + "_preview.png")
        try:
            render(src, dst)
        except Exception as e:
            print("FAIL", name, type(e).__name__, e)
