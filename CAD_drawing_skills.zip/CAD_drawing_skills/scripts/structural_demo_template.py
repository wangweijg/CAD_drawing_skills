# -*- coding: utf-8 -*-
"""按 22G101 平法规范绘制结构标准层施工图 DXF。

图面组成（自下而上）：
- 下图：结构标准层梁平法施工图（22G101-1 第 4 章）
- 上图：结构标准层楼板配筋平面图（22G101-1 第 5 章，有梁楼盖平法）
  两张图轴网、柱、梁布置完全相同，仅标注内容不同。

关键实现要点：
- 字体采用 AutoCAD 自带 GBENOR+GBCBIG，不依赖任何第三方插件字体；
- 标注样式 dimtsz=0.5 建筑斜线，不依赖 _ArchTick 块；
- 图层线型必须用 AutoCAD 标准名（DOT 而非 DOTE），否则 CAD 拒绝加载；
- 收尾必须调用 finalize_view()，否则 CAD 打开一片空白；
- 只输出 R2000(AC1015) 单一成品。
"""
import ezdxf, os

# 输出到本脚本同级的 ../output/ 目录，便于整包迁移；
# 也可用环境变量 CAD_DXF_OUT 指定输出全路径（quick_validate.py 用它输出到临时目录）。
_BASE = os.path.dirname(os.path.abspath(__file__))
OUT = os.environ.get("CAD_DXF_OUT") or os.path.join(
    _BASE, os.pardir, "output", "structural_demo_v7_r2000.dxf")
OUT = os.path.normpath(OUT)
os.makedirs(os.path.dirname(OUT), exist_ok=True)

doc = ezdxf.new("R2018", setup=True)
doc.header["$DIMSCALE"] = 100.0
doc.header["$LTSCALE"] = 100.0
doc.header["$TEXTSIZE"] = 200.0
doc.header["$INSUNITS"] = 4      # 毫米

# ============================================================
# 文字样式：只用 AutoCAD 自带 SHX
# ============================================================
std = doc.styles.get("Standard")
std.dxf.font = "GBENOR"     # 国标英文/数字 SHX
std.dxf.bigfont = "GBCBIG"  # 国标中文大字体

# 轴号只用 ASCII，用 txt.shx 最稳
doc.styles.new("AXIS", dxfattribs={"font": "txt.shx"})

# ============================================================
# 标注样式：建筑斜线 + 白字 + 绿色尺寸线
# ============================================================
doc.dimstyles.new("DIM100", dxfattribs={
    "dimscale": 100.0,
    "dimtxt": 2.5,
    "dimasz": 2.5,
    "dimtsz": 0.5,        # 建筑斜线，不依赖 _ArchTick 块
    "dimblk": "",
    "dimblk1": "",
    "dimblk2": "",
    "dimexe": 1.5,
    "dimexo": 1.5,
    "dimtad": 1,
    "dimlfac": 1.0,
    "dimclrd": 3,         # 尺寸线绿色
    "dimclre": 3,         # 尺寸界线绿色
    "dimclrt": 7,         # 尺寸文字白色
    "dimtxsty": "Standard",
})

# ============================================================
# 图层
# ============================================================
def add_layer(name, color, lw, linetype="Continuous"):
    doc.layers.add(name, color=color, lineweight=lw, linetype=linetype)

add_layer("S-DOTE", 253, 15, "DOT")
add_layer("S-AXIS", 3, 15)
add_layer("S-AXIS_TEXT", 7, 15)
add_layer("S-DIM", 3, 15)
add_layer("S-COLU", 6, 30)
add_layer("S-COLU_HATCH", 254, 15)
add_layer("S-COLU_NUM", 7, 15)
add_layer("S-COLU_TEXT", 7, 15)
add_layer("S-BEAM_CON", 4, 20)
add_layer("S-BEAM_TEXT", 40, 15)
add_layer("S-FLOOR_REIN", 1, 30)        # 板支座上部非贯通纵筋
add_layer("S-FLOOR_NUM", 7, 15)         # 板块编号
add_layer("S-FLOOR_DOWN_TEXT", 100, 15) # 板贯通纵筋注写
add_layer("S-FLOOR_TEXT", 30, 15)       # 板支座钢筋注写
add_layer("S-REIN", 1, 30)
add_layer("S-STIRRUP", 2, 15)
add_layer("S-DETAIL", 7, 15)
add_layer("S-DETAIL_TEXT", 7, 15)
add_layer("S-TEXT", 7, 15)
add_layer("S-TAB", 7, 15)
add_layer("S-TAB_TEXT", 7, 15)
add_layer("S-PUB_TITLE", 4, 15)
add_layer("S-DRAWING_NUMBER", 6, 30)

msp = doc.modelspace()

# ============================================================
# 几何参数
# ============================================================
XS = [0, 4000, 8000, 12000, 16000, 20000]
YS = [0, 5600, 11200]
XNUM = ["1", "2", "3", "4", "5", "6"]
YNUM = ["A", "B", "C"]
EXT = 2000
COL = 500.0
COL_HW = COL / 2
BW = 300.0          # 框架梁宽
BH = 600.0
LBW = 250.0         # 次梁宽
LB_Y = 2800         # 次梁 L1 定位（A~B 跨中）
TIT_H = 500
NOTE_H = 220
TAB_H = 200
BEAM_H = 260
SLAB_H = 240
AXIS_R = 350
AXIS_H = 280
DIM1 = 1500
DIM2 = DIM1 + 750
AXIS_ENDOFF = DIM2 + 500
AXIS_CENTER = AXIS_ENDOFF + AXIS_R

# 两张平面图的 Y 基准
OY_BEAM = 0          # 下：梁平法施工图
OY_SLAB = 22000      # 上：楼板配筋平面图

# 图签区：右下角横向
TITLE_X = 15700
TITLE_Y = -4300
TITLE_W = 6200
TITLE_H = 1800


# ============================================================
# 通用绘图工具
# ============================================================
def aligned_dim(p1, p2, distance, text=""):
    dim = msp.add_aligned_dim(p1=p1, p2=p2, distance=distance,
                              dimstyle="DIM100", dxfattribs={"layer": "S-DIM"})
    if text:
        dim.set_text(text)
    dim.render()


def rect(ll, ur, layer):
    x0, y0 = ll
    x1, y1 = ur
    pts = [(x0, y0), (x1, y0), (x1, y1), (x0, y1), (x0, y0)]
    msp.add_lwpolyline(pts, dxfattribs={"layer": layer, "closed": True})


def put_text(txt, x, y, layer, height, style="Standard", center=False, color=None):
    attr = {"layer": layer, "height": height, "style": style}
    if color is not None:
        attr["color"] = color
    t = msp.add_text(txt, dxfattribs=attr)
    x0 = x - len(txt) * height * 0.31 if center else x
    t.set_placement((x0, y))
    return t


# ============================================================
# 平面图公共部分：轴网 / 轴号 / 尺寸 / 柱 / 梁
# ============================================================
def draw_axis_grid(oy):
    for x in XS:
        msp.add_line((x, oy - AXIS_ENDOFF), (x, oy + YS[-1] + AXIS_ENDOFF),
                     dxfattribs={"layer": "S-DOTE"})
    for y in YS:
        msp.add_line((-AXIS_ENDOFF, oy + y), (XS[-1] + AXIS_ENDOFF, oy + y),
                     dxfattribs={"layer": "S-DOTE"})


def add_axis_text(text, x, y):
    t = msp.add_text(text, dxfattribs={
        "layer": "S-AXIS_TEXT", "height": AXIS_H,
        "style": "AXIS", "color": 7,
    })
    t.set_placement((x - AXIS_H * 0.25 * len(text), y - AXIS_H * 0.35))


def draw_axis_marks(oy):
    for i, x in enumerate(XS):
        for y in [oy - AXIS_CENTER, oy + YS[-1] + AXIS_CENTER]:
            msp.add_circle((x, y), AXIS_R, dxfattribs={"layer": "S-AXIS"})
            add_axis_text(XNUM[i], x, y)
    for i, y in enumerate(YS):
        for x in [-AXIS_CENTER, XS[-1] + AXIS_CENTER]:
            msp.add_circle((x, oy + y), AXIS_R, dxfattribs={"layer": "S-AXIS"})
            add_axis_text(YNUM[i], x, oy + y)


def draw_dims(oy):
    # 水平（底部）两道
    for i in range(len(XS) - 1):
        aligned_dim((XS[i], oy), (XS[i + 1], oy), -DIM1, text=str(XS[i + 1] - XS[i]))
    aligned_dim((XS[0], oy), (XS[-1], oy), -DIM2, text=str(XS[-1] - XS[0]))
    # 垂直（左侧）两道
    for i in range(len(YS) - 1):
        aligned_dim((0, oy + YS[i]), (0, oy + YS[i + 1]), DIM1,
                    text=str(YS[i + 1] - YS[i]))
    aligned_dim((0, oy + YS[0]), (0, oy + YS[-1]), DIM2, text=str(YS[-1] - YS[0]))


def add_column(cx, cy, tag=None):
    h = COL / 2
    pts = [(cx - h, cy - h), (cx + h, cy - h), (cx + h, cy + h),
           (cx - h, cy + h), (cx - h, cy - h)]
    hatch = msp.add_hatch(dxfattribs={"layer": "S-COLU_HATCH"})
    hatch.paths.add_polyline_path(pts, is_closed=True)
    msp.add_lwpolyline(pts, dxfattribs={"layer": "S-COLU", "closed": True})
    if tag:
        t = msp.add_text(tag, dxfattribs={"layer": "S-COLU_NUM",
                                          "height": 220, "style": "AXIS"})
        t.set_placement((cx - 90 * len(tag), cy - 80))


column_tags = [[f"KZ-{1 + r * len(XS) + c}" for c in range(len(XS))]
               for r in range(len(YS))]
column_tags = list(reversed(column_tags))  # 从 A 排到 C


def draw_columns(oy, with_num=True):
    for r, y in enumerate(YS):
        for c, x in enumerate(XS):
            add_column(x, oy + y, column_tags[r][c] if with_num else None)


AT_BEAM = {"layer": "S-BEAM_CON"}


def draw_beams(oy):
    """框架梁（双线，柱处断开）+ 非框架梁 L1。"""
    # X 向框架梁
    for y in YS:
        for i in range(len(XS) - 1):
            xa, xb = XS[i] + COL_HW, XS[i + 1] - COL_HW
            if xb > xa:
                msp.add_line((xa, oy + y - BW / 2), (xb, oy + y - BW / 2), AT_BEAM)
                msp.add_line((xa, oy + y + BW / 2), (xb, oy + y + BW / 2), AT_BEAM)
    # Y 向框架梁
    for x in XS:
        for i in range(len(YS) - 1):
            ya, yb = YS[i] + COL_HW, YS[i + 1] - COL_HW
            if yb > ya:
                msp.add_line((x - BW / 2, oy + ya), (x - BW / 2, oy + yb), AT_BEAM)
                msp.add_line((x + BW / 2, oy + ya), (x + BW / 2, oy + yb), AT_BEAM)
    # 非框架梁 L1（A~B 跨中，X 向贯通）
    for i in range(len(XS) - 1):
        xa, xb = XS[i] + COL_HW, XS[i + 1] - COL_HW
        msp.add_line((xa, oy + LB_Y - LBW / 2), (xb, oy + LB_Y - LBW / 2), AT_BEAM)
        msp.add_line((xa, oy + LB_Y + LBW / 2), (xb, oy + LB_Y + LBW / 2), AT_BEAM)


def draw_plan_title(oy, name, scale="1:100"):
    """图名 + 下划线 + 比例。"""
    y = oy + YS[-1] + AXIS_CENTER + 1400
    x0 = XS[-1] / 2 - len(name) * TIT_H * 0.45
    put_text(name, x0, y, "S-TEXT", TIT_H)
    w = len(name) * TIT_H * 0.9
    msp.add_line((x0, y - 200), (x0 + w, y - 200), dxfattribs={"layer": "S-TEXT"})
    put_text(scale, x0 + w + 300, y, "S-TEXT", TIT_H * 0.7)


# ============================================================
# 下图：梁平法施工图（22G101-1 第 4 章）
# ============================================================
draw_axis_grid(OY_BEAM)
draw_axis_marks(OY_BEAM)
draw_dims(OY_BEAM)
draw_columns(OY_BEAM, with_num=True)
draw_beams(OY_BEAM)

AT_BTXT = {"layer": "S-BEAM_TEXT", "height": BEAM_H, "style": "Standard"}


def beam_text(txt, x, y, height=None):
    attr = dict(AT_BTXT)
    if height:
        attr["height"] = height
    t = msp.add_text(txt, dxfattribs=attr)
    t.set_placement((x, y))
    return t


def concentrated_label(x, y, lines, leader_to=None):
    """梁集中标注（22G101-1 4.2.2）。

    行顺序：①梁编号+截面 ②箍筋 ③上部通长筋 ④侧面构造/受扭筋 ⑤顶面标高高差(选注)
    """
    if leader_to is not None:
        msp.add_line((x - 200, y - 120), (x + 1600, y - 120),
                     dxfattribs={"layer": "S-BEAM_TEXT"})
        msp.add_line((x - 200, y - 120), leader_to,
                     dxfattribs={"layer": "S-BEAM_TEXT"})
    for k, txt in enumerate(lines):
        beam_text(txt, x, y + (len(lines) - 1 - k) * BEAM_H * 1.35)


# --- X 向框架梁 KL2(5)：B 轴，5 跨 ---
concentrated_label(
    9200, 5600 + 1100,
    ["KL2(5) 300x600", "%%c8@100/200(2)", "2%%c25", "G4%%c12", "(-0.050)"],
    leader_to=(8600, 5600 + BW / 2),
)

# 支座上部纵筋原位标注（22G101-1 4.2.4）：多于一排用 "/" 分开
support_top = {
    0:     "2%%c25",
    4000:  "6%%c25 4/2",
    8000:  "6%%c25 4/2",
    12000: "6%%c25 4/2",
    16000: "6%%c25 4/2",
    20000: "2%%c25",
}
for sx, txt in support_top.items():
    beam_text(txt, sx - 500, 5600 + BW / 2 + 160)

# 跨中下部纵筋原位标注：括号内为不伸入支座的根数
span_bottom = [
    (2000,  "4%%c25"),
    (6000,  "6%%c25 2(-2)/4"),
    (10000, "6%%c25 2/4"),
    (14000, "6%%c25 2(-2)/4"),
    (18000, "4%%c25"),
]
for cx, txt in span_bottom:
    beam_text(txt, cx - 550, 5600 - BW / 2 - 420)

# --- Y 向框架梁 KL7(2)：3 轴，2 跨 ---
concentrated_label(
    8000 + 700, 8800,
    ["KL7(2) 300x600", "%%c8@100/200(2)", "2%%c22", "G4%%c12"],
    leader_to=(8000 + BW / 2, 8400),
)
for sy, txt in [(0, "2%%c22"), (5600, "4%%c22 2/2"), (11200, "2%%c22")]:
    beam_text(txt, 8000 + BW / 2 + 160, sy - 130)
for cy in (2800, 8400):
    beam_text("4%%c22", 8000 - BW / 2 - 1150, cy)

# --- 非框架梁（次梁）L1(5) ---
concentrated_label(
    3200, LB_Y + 1000,
    ["L1(5) 250x450", "%%c8@200(2)", "2%%c18"],
    leader_to=(2600, LB_Y + LBW / 2),
)
beam_text("3%%c18", 5400, LB_Y - LBW / 2 - 400)


# --- 附加吊筋（22G101-1 4.2.5）：次梁与主梁交接处 ---
def hanging_bar(x, y, txt="2%%c16"):
    w, h = 320.0, 260.0
    pts = [(x - w, y + h), (x - w * 0.45, y - h * 0.55),
           (x + w * 0.45, y - h * 0.55), (x + w, y + h)]
    msp.add_lwpolyline(pts, dxfattribs={"layer": "S-REIN"})
    msp.add_line((x, y + h * 0.2), (x + 900, y + h * 0.2),
                 dxfattribs={"layer": "S-BEAM_TEXT"})
    beam_text(txt, x + 950, y + h * 0.2 - 90, 220)


hanging_bar(8000, LB_Y)

draw_plan_title(OY_BEAM, "结构标准层梁平法施工图")


# ============================================================
# 上图：楼板配筋平面图（22G101-1 第 5 章 有梁楼盖平法）
# ============================================================
draw_axis_grid(OY_SLAB)
draw_axis_marks(OY_SLAB)
draw_dims(OY_SLAB)
draw_columns(OY_SLAB, with_num=False)   # 板图不重复标柱号
draw_beams(OY_SLAB)

OY = OY_SLAB


def slab_block_label(cx, cy, lines):
    """板块集中标注（22G101-1 5.2.2）。

    行顺序：①板块编号+板厚 ②下部贯通纵筋 ③上部贯通纵筋(有则注) ④板面标高高差(选注)
    """
    for k, txt in enumerate(lines):
        layer = "S-FLOOR_NUM" if k == 0 else "S-FLOOR_DOWN_TEXT"
        put_text(txt, cx, cy + OY - k * SLAB_H * 1.35, layer, SLAB_H, center=True)


def bar_tag(x, y, num, r=170):
    """板支座钢筋编号：带圈数字（无引线，备用）。"""
    msp.add_circle((x, y), r, dxfattribs={"layer": "S-FLOOR_TEXT"})
    put_text(str(num), x, y - r * 0.5, "S-FLOOR_TEXT", r * 1.15,
             style="AXIS", center=True)


def bar_tag_leader(x, y, num, direction="left", r=170, lead=450):
    """带引线的板支座钢筋编号：带圈数字。

    22G101-1 第 5 章习惯：编号圆圈通过短引线与负筋线相连，避免与钢筋线、
    配筋值文字重叠。direction 控制引线甩向：left/right/up/down。
    """
    dx = {"left": -lead, "right": lead}.get(direction, 0)
    dy = {"down": -lead, "up": lead}.get(direction, 0)
    end = (x + dx, y + dy)
    msp.add_line((x, y), end, dxfattribs={"layer": "S-FLOOR_TEXT"})
    msp.add_circle(end, r, dxfattribs={"layer": "S-FLOOR_TEXT"})
    put_text(str(num), end[0], end[1] - r * 0.45, "S-FLOOR_TEXT", r * 1.15,
             style="AXIS", center=True)
    return end


def slab_top_bar_h(x, y_axis, ext_dn, ext_up, num, rein=None, hook=200):
    """支座为 X 向梁（水平），负筋线竖直绘制。

    22G101-1 5.4.2：垂直于板支座绘制中粗实线代表钢筋，
    线段一侧注写编号与配筋值，端部注写自支座中线向跨内伸出长度。
    """
    y0, y1 = OY + y_axis - ext_dn, OY + y_axis + ext_up
    mid = (y0 + y1) / 2
    msp.add_line((x, y0), (x, y1), dxfattribs={"layer": "S-FLOOR_REIN"})
    # 端部弯钩
    msp.add_line((x, y0), (x + hook, y0), dxfattribs={"layer": "S-FLOOR_REIN"})
    msp.add_line((x, y1), (x + hook, y1), dxfattribs={"layer": "S-FLOOR_REIN"})
    # 编号：引到负筋线左侧（与截图②一致）
    tag_x, tag_y = bar_tag_leader(x, mid, num, direction="left")
    if rein:
        # 配筋值放在圆圈上方，与伸出长度错开
        put_text(rein, tag_x, tag_y + 420, "S-FLOOR_TEXT", 210, center=True)
    # 伸出长度（自支座中线算起），放在负筋线两端外侧，避免压编号
    if ext_dn:
        put_text(str(int(ext_dn)), x + 260, y0 - 280, "S-FLOOR_TEXT", 200)
    if ext_up:
        put_text(str(int(ext_up)), x + 260, y1 + 80, "S-FLOOR_TEXT", 200)


def slab_top_bar_v(y, x_axis, ext_lf, ext_rt, num, rein=None, hook=200):
    """支座为 Y 向梁（竖直），负筋线水平绘制。

    弯钩及伸出长度标注统一向下（指向板内 / 跨内），符合 22G101-1 制图习惯。
    编号引到负筋线上方（与截图⑤一致）。
    """
    x0, x1 = x_axis - ext_lf, x_axis + ext_rt
    mid = (x0 + x1) / 2
    base = OY + y
    msp.add_line((x0, base), (x1, base), dxfattribs={"layer": "S-FLOOR_REIN"})
    msp.add_line((x0, base), (x0, base - hook), dxfattribs={"layer": "S-FLOOR_REIN"})
    msp.add_line((x1, base), (x1, base - hook), dxfattribs={"layer": "S-FLOOR_REIN"})
    # 编号：引到负筋线上方
    tag_x, tag_y = bar_tag_leader(mid, base, num, direction="up")
    if rein:
        # 配筋值放在圆圈右侧
        put_text(rein, tag_x + 320, tag_y - 80, "S-FLOOR_TEXT", 210)
    # 伸出长度（自支座中线算起），统一向下
    if ext_lf:
        put_text(str(int(ext_lf)), x0 + 80, base - 360, "S-FLOOR_TEXT", 200)
    if ext_rt:
        put_text(str(int(ext_rt)), x1 - 620, base - 360, "S-FLOOR_TEXT", 200)


# ---- 板块集中标注 ----
# LB1: A~L1 与 L1~B（4000×2800），相同编号只在第一块注全，其余仅注编号
slab_block_label(2000, 1400, ["LB1  h=100", "B:X&Y%%c8@150"])
slab_block_label(2000, 4200, ["LB1  h=100", "B:X&Y%%c8@150"])
for cx in (6000, 10000, 14000, 18000):
    slab_block_label(cx, 1400, ["LB1"])
    slab_block_label(cx, 4200, ["LB1"])

# LB2: B~C（4000×5600）
slab_block_label(2000, 8400, ["LB2  h=120", "B:X%%c8@150", "B:Y%%c10@150"])
for cx in (6000, 10000, 14000, 18000):
    slab_block_label(cx, 8400, ["LB2"])

# LB3: 局部降板（示例，注写板面标高高差）
slab_block_label(18000, 8400 - SLAB_H * 2.7, ["(-0.050)"])

# ---- 板支座上部非贯通纵筋原位标注 ----
# ① B 轴中间支座（LB1 与 LB2 之间），第一跨注全，其余跨仅注编号
slab_top_bar_h(2000, 5600, 1000, 1400, 1, "%%c10@150")
for cx in (6000, 10000, 14000, 18000):
    slab_top_bar_h(cx, 5600, 1000, 1400, 1)

# ② L1 次梁支座
slab_top_bar_h(2000, LB_Y, 800, 800, 2, "%%c8@150")
for cx in (6000, 10000, 14000, 18000):
    slab_top_bar_h(cx, LB_Y, 800, 800, 2)

# ③ A 轴端支座（单侧伸入板内）
slab_top_bar_h(2000, 0, 0, 900, 3, "%%c8@150")
for cx in (6000, 10000, 14000, 18000):
    slab_top_bar_h(cx, 0, 0, 900, 3)

# ④ C 轴端支座
slab_top_bar_h(2000, 11200, 1400, 0, 4, "%%c10@150")
for cx in (6000, 10000, 14000, 18000):
    slab_top_bar_h(cx, 11200, 1400, 0, 4)

# ⑤ 3 轴 Y 向梁中间支座（横向布置到相邻跨）
slab_top_bar_v(8400, 8000, 1000, 1000, 5, "%%c10@150")
slab_top_bar_v(1400, 8000, 1000, 1000, 5)
slab_top_bar_v(4200, 8000, 1000, 1000, 5)

# ⑥ 1 轴 / 6 轴端支座
slab_top_bar_v(8400, 0, 0, 900, 6, "%%c8@150")
slab_top_bar_v(8400, 20000, 900, 0, 6)

# ---- 板配筋说明 ----
slab_notes = [
    "注：1. B 表示板下部贯通纵筋，T 表示板上部贯通纵筋，X&Y 表示两向配筋相同。",
    "    2. 支座钢筋伸出长度自支座中线算起；中间支座两侧对称时仅注一侧。",
    "    3. 板厚 h 单位 mm；未注明板面标高同结构层楼面标高。",
    "    4. 板内分布筋 %%c6@200，与支座负筋绑扎连接。",
]
for k, txt in enumerate(slab_notes):
    put_text(txt, -EXT, OY - AXIS_ENDOFF - 1500 - k * NOTE_H * 1.4,
             "S-TEXT", NOTE_H)

draw_plan_title(OY_SLAB, "结构标准层楼板配筋平面图")


# ============================================================
# 层高表（梁图左上角外侧）
# ============================================================
TX, TY = -5000, YS[-1] + EXT - 500
col_w = [450, 800, 800]
row_h = 320
rows = [
    ["层号", "标高(m)", "层高(m)"],
    ["3", "8.670", "3.60"],
    ["2", "4.470", "3.60"],
    ["1", "-0.030", "4.50"],
]
for i in range(len(rows) + 1):
    y_line = TY - i * row_h
    msp.add_line((TX, y_line), (TX + sum(col_w), y_line), dxfattribs={"layer": "S-TAB"})
x_cursor = TX
for w in col_w:
    msp.add_line((x_cursor, TY), (x_cursor, TY - len(rows) * row_h), dxfattribs={"layer": "S-TAB"})
    x_cursor += w
msp.add_line((x_cursor, TY), (x_cursor, TY - len(rows) * row_h), dxfattribs={"layer": "S-TAB"})
for r, row in enumerate(rows):
    x_cursor = TX
    for c, txt in enumerate(row):
        put_text(txt, x_cursor + col_w[c] / 2, TY - (r + 0.55) * row_h,
                 "S-TAB_TEXT", TAB_H, center=True)
        x_cursor += col_w[c]

put_text("结构层楼面标高  结构层高", TX, TY + 200, "S-TEXT", 240)

# ============================================================
# 柱截面详图表（下方左侧）
# ============================================================
def draw_col_detail(dx, dy, b, h, label, stir):
    pts = [(dx, dy), (dx + b, dy), (dx + b, dy + h), (dx, dy + h), (dx, dy)]
    hatch = msp.add_hatch(dxfattribs={"layer": "S-COLU_HATCH"})
    hatch.paths.add_polyline_path(pts, is_closed=True)
    msp.add_lwpolyline(pts, dxfattribs={"layer": "S-COLU", "closed": True})
    cov = 25
    msp.add_lwpolyline([
        (dx + cov, dy + cov), (dx + b - cov, dy + cov),
        (dx + b - cov, dy + h - cov), (dx + cov, dy + h - cov), (dx + cov, dy + cov)
    ], dxfattribs={"layer": "S-STIRRUP", "closed": True})
    dia = 25
    for xr in [dx + cov + dia / 2, dx + b - cov - dia / 2]:
        for yr in [dy + cov + dia / 2, dy + h - cov - dia / 2]:
            msp.add_circle((xr, yr), dia / 2, dxfattribs={"layer": "S-REIN"})
    put_text(label, dx + b / 2, dy + h + 120, "S-COLU_NUM", 180,
             style="AXIS", center=True)
    put_text(stir, dx + b / 2, dy - 260, "S-COLU_TEXT", 160, center=True)


CDX, CDY = -EXT, -EXT - 1800
col_detail_data = [(f"KZ-{i}", 500, 500, "4%%c25", "%%c8@100/200") for i in range(1, 7)]
gap = 400
for i, (label, b, h, rein, stir) in enumerate(col_detail_data):
    draw_col_detail(CDX + i * (b + gap), CDY, b, h, label, stir)

# ============================================================
# 梁截面配筋详图（梁图右侧独立区）
# ============================================================
DX, DY = 24800, 6000
B_DET, H_DET = 200.0, 200.0
COV = 25.0

rect((DX, DY), (DX + B_DET, DY + H_DET), "S-DETAIL")
rect((DX + COV, DY + COV), (DX + B_DET - COV, DY + H_DET - COV), "S-STIRRUP")

DIA = 12.0
x_l = DX + COV + DIA / 2
x_r = DX + B_DET - COV - DIA / 2
y_top = DY + H_DET - COV - DIA / 2
y_bot = DY + COV + DIA / 2
for pt in [(x_l, y_top), (x_r, y_top), (x_l, y_bot), (x_r, y_bot)]:
    msp.add_circle(pt, DIA / 2, dxfattribs={"layer": "S-REIN"})
    h_rein = msp.add_hatch(color=1, dxfattribs={"layer": "S-REIN"})
    h_rein.paths.add_edge_path().add_arc(center=pt, radius=DIA / 2)


def detail_leader(from_pt, to_x, to_y, txt, h=200):
    msp.add_line(from_pt, (to_x - 120, to_y + 80), dxfattribs={"layer": "S-DETAIL_TEXT"})
    msp.add_line((to_x - 120, to_y + 80), (to_x + 700, to_y + 80),
                 dxfattribs={"layer": "S-DETAIL_TEXT"})
    put_text(txt, to_x, to_y - 60, "S-DETAIL_TEXT", h)


detail_leader((x_r, y_top), DX + B_DET + 420, DY + H_DET + 40, "2%%c12  (上部通长筋)")
detail_leader((DX + B_DET - COV, DY + H_DET / 2), DX + B_DET + 420, DY + H_DET / 2 - 120,
              "%%c8@200(2)  (箍筋)")
detail_leader((x_r, y_bot), DX + B_DET + 420, DY - 320, "2%%c12  (下部纵筋)")

put_text("KL5(3) 200x200", DX - 120, DY + H_DET + 700, "S-DETAIL_TEXT", 260)
put_text("1-1", DX + B_DET / 2 - 180, DY - 1500, "S-DETAIL_TEXT", 240)
put_text("钢筋均为 HRB400；保护层 25mm", DX - 120, DY - 2000, "S-DETAIL_TEXT", 190)

aligned_dim((DX, DY), (DX, DY + H_DET), -800, text="200")
aligned_dim((DX, DY), (DX + B_DET, DY), -800, text="200")

# ============================================================
# 总说明
# ============================================================
notes = [
    "1. 本图按 22G101-1《混凝土结构施工图平面整体表示方法制图规则和构造详图》绘制。",
    "2. 混凝土强度等级 C30；钢筋全部采用 HRB400（%%c）三级钢。",
    "3. 未注明分布筋为 %%c8@250。",
    "4. 抗震等级：三级；保护层厚度：梁 25mm，柱 30mm，板 15mm。",
]
ny = -EXT - 1900
for k, txt in enumerate(notes):
    put_text(txt, CDX, ny - k * NOTE_H * 1.4, "S-TEXT", NOTE_H)

# ============================================================
# 图签 / 会签栏（右下角）
# ============================================================
msp.add_lwpolyline([
    (TITLE_X, TITLE_Y), (TITLE_X + TITLE_W, TITLE_Y),
    (TITLE_X + TITLE_W, TITLE_Y + TITLE_H), (TITLE_X, TITLE_Y + TITLE_H),
    (TITLE_X, TITLE_Y)
], dxfattribs={"layer": "S-PUB_TITLE", "closed": True})

info_w = 3800
sign_w = [600, 600, 600, 600, 600, 600]
msp.add_line((TITLE_X, TITLE_Y + TITLE_H / 2), (TITLE_X + info_w, TITLE_Y + TITLE_H / 2),
             dxfattribs={"layer": "S-TAB"})
msp.add_line((TITLE_X + info_w, TITLE_Y), (TITLE_X + info_w, TITLE_Y + TITLE_H),
             dxfattribs={"layer": "S-TAB"})

info_lines = [
    ("项目名称", "示例项目"),
    ("图名", "标准层梁板平法施工图"),
    ("图号", "20260804-03"),
    ("比例", "1:100"),
]
for k, (k1, v1) in enumerate(info_lines):
    y = TITLE_Y + TITLE_H - (k + 0.5) * (TITLE_H / 4)
    put_text(f"{k1}: {v1}", TITLE_X + 200, y - 80, "S-TAB_TEXT", 200)

put_text("日期: 2026.08.04", TITLE_X + 200, TITLE_Y + 100, "S-TAB_TEXT", 200)

sign_x = TITLE_X + info_w
sign_y = TITLE_Y + TITLE_H
for i in range(3):
    y = sign_y - i * (TITLE_H / 2)
    msp.add_line((sign_x, y), (TITLE_X + TITLE_W, y), dxfattribs={"layer": "S-TAB"})
x_cursor = sign_x
for w in sign_w:
    msp.add_line((x_cursor, sign_y), (x_cursor, sign_y - TITLE_H), dxfattribs={"layer": "S-TAB"})
    x_cursor += w
msp.add_line((x_cursor, sign_y), (x_cursor, sign_y - TITLE_H), dxfattribs={"layer": "S-TAB"})

sign_texts = [
    ["专业", "设计", "校对", "审核", "审定", "会签"],
    ["结构", "", "", "", "", ""],
]
for r, row in enumerate(sign_texts):
    x_cursor = sign_x
    for c, txt in enumerate(row):
        put_text(txt, x_cursor + 30, sign_y - (r + 0.55) * (TITLE_H / 2), "S-TAB_TEXT", 180)
        x_cursor += sign_w[c]

# ============================================================
# 外框
# ============================================================
FRAME_X0, FRAME_Y0 = -6500, -6500
FRAME_W, FRAME_H = 36000, 46500
msp.add_lwpolyline([
    (FRAME_X0, FRAME_Y0), (FRAME_X0 + FRAME_W, FRAME_Y0),
    (FRAME_X0 + FRAME_W, FRAME_Y0 + FRAME_H), (FRAME_X0, FRAME_Y0 + FRAME_H),
    (FRAME_X0, FRAME_Y0)
], dxfattribs={"layer": "S-PUB_TITLE", "closed": True})


# ============================================================
# 关键收尾：设置图形范围 / 图限 / 活动视口
#   不做这步，CAD 打开后视口停在原点、高度 1000，看起来"什么都没有"
# ============================================================
def finalize_view(doc, margin_ratio=0.04, aspect=1.78):
    """设置图形范围、图限与活动视口，保证 CAD 打开即看到全图。

    关键坑：ezdxf 在 saveas() 时会执行 update_extents()/update_limits()，
    用 modelspace 布局的 dxf.extmin/extmax/limmin/limmax 覆盖 header。
    因此必须设置 msp.dxf.*，直接写 doc.header["$EXTMIN"] 会被丢弃。
    """
    from ezdxf.bbox import extents as _extents
    msp = doc.modelspace()
    ext = _extents(msp, fast=False)
    if not ext.has_data:
        print("WARN: modelspace empty, skip finalize_view")
        return
    minx, miny = ext.extmin.x, ext.extmin.y
    maxx, maxy = ext.extmax.x, ext.extmax.y
    w, h = maxx - minx, maxy - miny
    mx, my = w * margin_ratio, h * margin_ratio
    lo = (minx - mx, miny - my)
    hi = (maxx + mx, maxy + my)

    msp.dxf.extmin = (lo[0], lo[1], 0.0)
    msp.dxf.extmax = (hi[0], hi[1], 0.0)
    msp.dxf.limmin = lo
    msp.dxf.limmax = hi

    cx, cy = (minx + maxx) / 2.0, (miny + maxy) / 2.0
    view_h = max(h * (1 + 2 * margin_ratio), w * (1 + 2 * margin_ratio) / aspect)

    for vp in doc.viewports.get("*Active"):
        vp.dxf.center = (cx, cy)
        vp.dxf.height = view_h
        vp.dxf.aspect_ratio = aspect

    print(f"  extents: ({minx:.0f},{miny:.0f}) - ({maxx:.0f},{maxy:.0f})  "
          f"size {w:.0f} x {h:.0f}")
    print(f"  view center=({cx:.0f},{cy:.0f}) height={view_h:.0f}")


finalize_view(doc)

# 只输出 R2000(AC1015) 单一成品：已验证绿色版 AutoCAD 2018 可正常打开。
doc.dxfversion = "AC1015"
doc.saveas(OUT)
print("saved ->", OUT)
