# -*- coding: utf-8 -*-
"""单向同步：权威主源 J:\\CAD_drawing_skills -> Hermes 已装副本。

权威源约定（2026-09-16 王工确认）：
    主源 = 本脚本所在包（J:\\CAD_drawing_skills，唯一维护地，所有生成/扩展/清理都在这做）
    Hermes 副本 = I:\\Obsidian_Data\\60_AI\\01-Hermes_agent\\skills\\cad-structural-drawing
                （Hermes 加载用，从主源单向同步；另有旧副本 cad-automation/CAD_drawing_skills）
    ★ 权威源已从 E:\\ 迁至 J:\\（2026-09 起）；E:\\ 目录已不存在。

同步内容：scripts/*.py、templates/、references/、cases/、output/*.dxf+preview.png、
          以及根目录 SKILL.md / README.md / SETUP.md / ROADMAP.md。
跳过：__pycache__、*.log、PROGRESS_UPDATE（指令留档，不随主源分发）。

用法：
    python scripts/sync_hermes.py            # 按默认主源->Hermes副本
    HERMES_CAD_DST=<目标> python scripts/sync_hermes.py   # 覆盖副本路径
"""
import os
import shutil
import sys
import io

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

PACKAGE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))   # 主源(包根)
DEFAULT_DST = r"I:\Obsidian_Data\60_AI\01-Hermes_agent\skills\cad-structural-drawing"
DST = os.environ.get("HERMES_CAD_DST") or DEFAULT_DST

SKIP_NAMES = {"__pycache__", "__init__.py"}
SKIP_SUFFIX = (".log",)
# 仅跳过临时脚本；保留合法下划线工具如 _fix_runasadmin.py
TMP_PREFIX = ("_tmp", "_scan", "_clean", "_fix_residual", "_inspect")
ROOT_MD = ["SKILL.md", "README.md", "SETUP.md", "ROADMAP.md"]
DIRS = ["scripts", "templates", "references", "cases", "output", "tarch_parts"]


def _ignore(_d, names):
    out = set()
    for n in names:
        if n in SKIP_NAMES:
            out.add(n)
        if any(n.startswith(p) for p in TMP_PREFIX):
            out.add(n)
        if n.endswith(SKIP_SUFFIX):
            out.add(n)
    return out


def sync():
    if not os.path.isdir(PACKAGE):
        raise SystemExit("主源不存在: %s" % PACKAGE)
    os.makedirs(DST, exist_ok=True)
    copied = 0

    # 目录（scripts/templates/references/cases/output）
    for d in DIRS:
        src = os.path.join(PACKAGE, d)
        if not os.path.isdir(src):
            continue
        dst = os.path.join(DST, d)
        for root, _dirs, files in os.walk(src):
            if "__pycache__" in root:
                continue
            rel = os.path.relpath(root, src)
            target = os.path.join(dst, rel if rel != "." else "")
            os.makedirs(target, exist_ok=True)
            for fn in files:
                if any(fn.startswith(p) for p in TMP_PREFIX) or fn.endswith(SKIP_SUFFIX):
                    continue
                sp = os.path.join(root, fn)
                dp = os.path.join(target, fn)
                if not os.path.isfile(dp) or os.path.getmtime(sp) > os.path.getmtime(dp):
                    shutil.copy2(sp, dp)
                    copied += 1

    # 根目录 markdown
    for f in ROOT_MD:
        sp = os.path.join(PACKAGE, f)
        if os.path.isfile(sp):
            dp = os.path.join(DST, f)
            shutil.copy2(sp, dp)
            copied += 1

    print("同步完成：%s -> %s（更新 %d 个文件）" % (PACKAGE, DST, copied))
    print("Hermes 副本版本现已与权威主源一致。")


if __name__ == "__main__":
    sync()
