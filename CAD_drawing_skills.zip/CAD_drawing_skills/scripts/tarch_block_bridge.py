"""天正构件(导出为标准 .dwg) → ezdxf 离线复用桥接工具。

路线 A：静态块库。
前提：构件已从天正「图库管理 → 图块导出」为标准 .dwg（普通 BLOCK，非 TCH 代理对象）。
本模块只负责 ezdxf 侧的「读取 → 导入 block 定义 → 多实例 INSERT 复用」，
不依赖天正运行，可纯离线出图。

典型用法见 verify_chain.py。
"""
from __future__ import annotations

from pathlib import Path
from typing import Iterable, Optional

import ezdxf
from ezdxf.addons import Importer


def list_blocks(dwg_path: str | Path) -> list[str]:
    """列出构件 dwg 里的所有 BLOCK 定义名（过滤 * 匿名块）。"""
    doc = ezdxf.readfile(str(dwg_path))
    return [b.name for b in doc.blocks if not b.name.startswith("*")]


def import_blocks(
    source_path: str | Path,
    target_doc: "ezdxf.Drawing",
    block_names: Optional[Iterable[str]] = None,
    rename: bool = False,
) -> None:
    """把源 dwg 的 block 定义（及嵌套依赖）导入到目标 doc。

    block_names=None 时导入全部；否则只导入指定名称。
    若目标已存在同名 block，rename=True 会自动加后缀避免冲突。
    """
    src = ezdxf.readfile(str(source_path))
    imp = Importer(src, target_doc)
    if block_names is None:
        imp.import_all()
    else:
        imp.import_blocks(list(block_names), rename=rename)
    imp.finalize()


def insert_block(
    target_doc: "ezdxf.Drawing",
    block_name: str,
    insert=(0.0, 0.0),
    scale: float = 1.0,
    rotation: float = 0.0,
    layer: Optional[str] = None,
) -> None:
    """在 target_doc 的 modelspace 插入一个「已导入」的 block 实例。

    scale：统一缩放（门宽方向可用 xscale/yscale 分别处理开向，这里给统一接口）。
    rotation：旋转角度（度），可用来改变门的开启方向。
    layer：指定插入图层；不传则用 block 自身图层。
    """
    msp = target_doc.modelspace()
    attribs = {
        "xscale": scale,
        "yscale": scale,
        "zscale": scale,
        "rotation": rotation,
    }
    if layer:
        attribs["layer"] = layer
    msp.add_blockref(block_name, (float(insert[0]), float(insert[1]), 0.0), dxfattribs=attribs)


def reuse_blocks_from(
    source_path: str | Path,
    target_doc: "ezdxf.Drawing",
    placements: Iterable[dict],
    block_names: Optional[Iterable[str]] = None,
) -> None:
    """一步到位：导入源 dwg 的 block，并按 placements 列表批量插入实例。

    placements 每项形如：
        {"block": "DOOR_1000", "insert": (x,y), "scale": 1.0, "rotation": 0.0, "layer": "S-DOOR"}
    其中 block 缺省取源 dwg 的第一个非匿名 block。
    """
    import_blocks(source_path, target_doc, block_names=block_names)
    default_block = list_blocks(source_path)[0]
    for p in placements:
        name = p.get("block", default_block)
        insert_block(
            target_doc,
            name,
            insert=p.get("insert", (0.0, 0.0)),
            scale=p.get("scale", 1.0),
            rotation=p.get("rotation", 0.0),
            layer=p.get("layer"),
        )
