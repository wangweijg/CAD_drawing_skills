# -*- coding: utf-8 -*-
"""模板库访问模块 —— 把王工的真实工程 DXF 模板库接进本技能。

模板库位置（技能包内）::

    <技能包>/templates/

每个模板一组 4 个文件::

    <名称>.template.json    完整提取数据（图层/文字样式/标注样式/线型/图块/构件/文本索引）
    <名称>_文本索引.txt      人类可读文本清单（按图层分组，带坐标）
    <名称>_构件参数.txt      构件统计摘要（梁/柱/板/墙 数量与清单）
    <名称>.dxf              原始 DXF 副本（保留源文件名便于对照）

用途定位
--------
模板库是**真实工程的事实标准**（从真实图纸中提取），本技能拿它做三件事：

1. **校准图层**  ——  `--diff` 比对 cad_standards.LAYERS 与真实工程图层的差异
2. **校准标注格式** —— `--beam-format` 从文本索引反推真实梁标注的行数/行序/行距/字高
3. **查素材** —— `--grep` 在所有模板的文本里搜关键字（找某种标注怎么写的）

默认**只读**查询；`--add` 可把新画的图登记为新模板（写入 4 件套）。

CLI
---
    python template_library.py --list
    python template_library.py --info 柱子_详图
    python template_library.py --layers 柱子_详图
    python template_library.py --grep "N4"
    python template_library.py --diff
    python template_library.py --beam-format 柱子_详图
    python template_library.py --add 柱表_KZ-5.dxf --name 柱子_详图_500x500 --type 柱详图
"""
import argparse
import json
import os
import re
import sys
import time
from collections import defaultdict

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# ── 模板库定位 ─────────────────────────────────────────────
# priority: env CAD_TEMPLATE_LIB > 技能包自带 templates/（自包含，无外部依赖）


def _local_candidate():
    """技能包自带模板库：<脚本所在目录>/../templates（装到任何机器都可用）。"""
    p = os.path.normpath(os.path.join(
        os.path.dirname(os.path.abspath(__file__)), "..", "templates"))
    return p if os.path.isdir(p) else None


TEMPLATE_SUFFIX = ".template.json"


def lib_dir():
    """返回模板库目录，找不到时抛 FileNotFoundError（带排查提示）。"""
    env = os.environ.get("CAD_TEMPLATE_LIB")
    local = _local_candidate()
    cands = ([env] if env else []) + ([local] if local else [])
    for p in cands:
        if p and os.path.isdir(p):
            return p
    raise FileNotFoundError(
        "找不到模板库目录。已尝试：\n  " + "\n  ".join(str(c) for c in cands) +
        "\n技能包自带 templates/ 缺失时，可设环境变量 CAD_TEMPLATE_LIB=<模板库路径> 指定。"
    )


def list_templates():
    """列出所有模板名（不含 .template.json 后缀），按名称排序。"""
    d = lib_dir()
    names = [f[:-len(TEMPLATE_SUFFIX)] for f in os.listdir(d)
             if f.endswith(TEMPLATE_SUFFIX)]
    return sorted(names)


def load(name):
    """按模板名加载 .template.json，返回 dict。支持模糊匹配（子串）。"""
    d = lib_dir()
    path = os.path.join(d, name + TEMPLATE_SUFFIX)
    if not os.path.isfile(path):
        hits = [n for n in list_templates() if name in n]
        if len(hits) == 1:
            path = os.path.join(d, hits[0] + TEMPLATE_SUFFIX)
        elif len(hits) > 1:
            raise ValueError("模板名 %r 匹配到多个：%s" % (name, hits))
        else:
            raise FileNotFoundError(
                "模板 %r 不存在。可用：%s" % (name, list_templates()))
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def layers(name):
    """返回 {图层名: (color, linetype, lineweight_mm)}。"""
    d = load(name)
    return {L["name"]: (L.get("color"), L.get("linetype"), L.get("lineweight_mm"))
            for L in d.get("layers", [])}


def components(name):
    """返回 components 段（beams/columns/slabs/walls/others）。"""
    return load(name).get("components", {})


def text_index(name):
    """返回 {图层: [ {t,pos,h,r}, ... ]}。"""
    return load(name).get("text_index", {})


def grep_text(pattern, ignore_case=True):
    """在所有模板的文本索引里搜正则，返回 [(模板, 图层, 文本, pos, h, r)]。"""
    flags = re.IGNORECASE if ignore_case else 0
    rx = re.compile(pattern, flags)
    out = []
    for name in list_templates():
        try:
            ti = text_index(name)
        except Exception:
            continue
        for lyr, items in ti.items():
            for e in items:
                t = str(e.get("t", ""))
                if rx.search(t):
                    out.append((name, lyr, t, e.get("pos"), e.get("h"), e.get("r")))
    return out


# ── 与技能标准的差异比对 ───────────────────────────────────
def _first_template():
    """返回模板库中第一个模板名（无模板时返回 None）。"""
    names = list_templates()
    return names[0] if names else None


def diff_layers(name=None):
    """把真实工程图层与 cad_standards.LAYERS 比对。

    name 缺省时自动取模板库第一个模板。

    返回 dict:
        only_skill  : 技能有、真实模板没有（可能是技能自造层，需确认）
        only_tpl    : 真实模板有、技能没有（可考虑补入）
        color_diff  : 两边都有但 ACI 颜色不同 [(层, 技能色, 模板色)]
    """
    if name is None:
        name = _first_template()
    from cad_standards import LAYERS
    tpl = layers(name)
    skill = set(LAYERS.keys())
    tset = set(tpl.keys())

    color_diff = []
    for k in sorted(skill & tset):
        sc = LAYERS[k][0]
        tc = tpl[k][0]
        if sc != tc:
            color_diff.append((k, sc, tc))

    return {
        "template": name,
        "only_skill": sorted(skill - tset),
        "only_tpl": sorted(tset - skill),
        "color_diff": color_diff,
    }


# ── 梁标注格式反推 ─────────────────────────────────────────
_BEAM_HEAD = re.compile(r"^([A-Z]{1,4})\s*-?\s*(\d+[A-Za-z]?)?\s*\((\d+[A-Za-z]?)\)")


def beam_format(name=None, tol=30.0):
    """从模板文本索引反推真实梁集中标注的排布规律。

    name 缺省时自动取模板库第一个模板（当前库中无梁模板时返回空结果并附 note）。

    做法：把梁标注图层的文字按"同一行/同一列"聚簇（容差 tol），
    以 `XX1(2) 300x600` 这种梁号行为簇首，输出每簇的行序与行距。

    返回 {"v": [...], "h": [...], "line_gap": 中位行距, "text_h": 中位字高}
    """
    if name is None:
        name = _first_template()
    ti = text_index(name)
    items = []
    for lyr, lst in ti.items():
        if "BEAM" in lyr.upper():
            for e in lst:
                items.append((lyr, e))
    if not items:
        return {"v": [], "h": [], "line_gap": None, "text_h": None,
                "note": "模板 %s 无含 BEAM 的图层（当前库中可能没有梁平法模板）" % name}

    heights = sorted(float(e.get("h") or 0) for _, e in items)
    text_h = heights[len(heights) // 2] if heights else None

    # 同一标注块内相邻行的最大间距；超过就认为是另一根梁的标注块
    split_at = float(text_h or 300.0) * 2.5

    def cluster(key_idx, sort_idx, reverse):
        """按 pos[key_idx] 聚簇 → 簇内按 pos[sort_idx] 排序 → 按间隙切成独立标注块。"""
        g = defaultdict(list)
        for lyr, e in items:
            g[round(float(e["pos"][key_idx]) / tol)].append(e)
        out = []
        for _, lst in g.items():
            if len(lst) < 2:
                continue
            row = sorted(lst, key=lambda e: float(e["pos"][sort_idx]),
                         reverse=reverse)
            # 按间隙切分：同一直线上可能排着多根梁的标注块
            blocks, cur = [], [row[0]]
            for prev, e in zip(row, row[1:]):
                if abs(float(e["pos"][sort_idx]) - float(prev["pos"][sort_idx])) > split_at:
                    blocks.append(cur)
                    cur = [e]
                else:
                    cur.append(e)
            blocks.append(cur)
            for blk in blocks:
                # 只保留以梁号开头、且不止一行的块（排除孤立的原位标注）
                if len(blk) < 2:
                    continue
                if not _BEAM_HEAD.match(str(blk[0].get("t", ""))):
                    continue
                out.append(blk)
        return out

    # 竖向梁：文字 r=90，同一 y、沿 x 自左而右
    v = cluster(1, 0, False)
    # 横向梁：文字 r=0，同一 x、沿 y 自上而下
    h = cluster(0, 1, True)

    gaps = []
    for row in v:
        for a, b in zip(row, row[1:]):
            gaps.append(abs(float(b["pos"][0]) - float(a["pos"][0])))
    for col in h:
        for a, b in zip(col, col[1:]):
            gaps.append(abs(float(b["pos"][1]) - float(a["pos"][1])))
    gaps = [g for g in sorted(gaps) if g > 1.0]
    line_gap = gaps[len(gaps) // 2] if gaps else None

    return {"v": v, "h": h, "line_gap": line_gap, "text_h": text_h}


# ── CLI ────────────────────────────────────────────────────
def _p_info(name):
    d = load(name)
    print("模板: %s" % d.get("template_name"))
    print("类型: %s   源文件: %s (%s KB)   CAD版本: %s"
          % (d.get("template_type"), d.get("source_file"),
             d.get("source_size_kb"), d.get("acad_version")))
    print("提取时间: %s" % d.get("extracted_at"))
    print()
    print("图层 %d | 文字样式 %d | 标注样式 %d | 图块 %d"
          % (len(d.get("layers", [])), len(d.get("text_styles", [])),
             len(d.get("dim_styles", [])), len(d.get("blocks", {}))))
    comp = d.get("components", {})
    for k in ("beams", "columns", "slabs", "walls"):
        v = comp.get(k) or []
        if v:
            print("  %-8s %d 个" % (k, len(v)))
    print()
    print("文字样式:")
    for s in d.get("text_styles", []):
        print("  %-22s font=%-14s bigfont=%-14s width=%s"
              % (s.get("name"), s.get("font"), s.get("bigfont"),
                 s.get("width_factor")))
    ti = d.get("text_index", {})
    if ti:
        print()
        print("文本索引(前12层):")
        for k, v in list(sorted(ti.items(), key=lambda kv: -len(kv[1])))[:12]:
            print("  %-24s %d 条" % (k, len(v)))


def _p_layers(name):
    lay = layers(name)
    print("模板 %s —— %d 个图层" % (name, len(lay)))
    print("-" * 62)
    for k in sorted(lay):
        c, lt, lw = lay[k]
        print("  %-26s color=%-5s lt=%-13s lw=%s" % (k, c, lt, lw))


def _p_diff(name):
    r = diff_layers(name)
    print("图层差异：技能 cad_standards.LAYERS  vs  模板 %s" % r["template"])
    print("=" * 62)
    print()
    print("【技能有 / 模板无】%d 个  ← 技能自造层，需确认是否合规" % len(r["only_skill"]))
    for k in r["only_skill"]:
        print("    " + k)
    print()
    print("【模板有 / 技能无】%d 个  ← 真实工程在用，可考虑补入" % len(r["only_tpl"]))
    for k in r["only_tpl"]:
        print("    " + k)
    print()
    print("【颜色不一致】%d 个  (层名, 技能ACI, 模板ACI)" % len(r["color_diff"]))
    for k, sc, tc in r["color_diff"]:
        print("    %-26s 技能=%-5s 模板=%-5s" % (k, sc, tc))


def _p_beam_format(name):
    r = beam_format(name)
    print("真实梁集中标注格式反推 —— 模板 %s" % name)
    print("=" * 62)
    if r.get("note"):
        print("提示: %s" % r["note"])
    print("字高(中位) : %s" % r["text_h"])
    print("行距(中位) : %s" % r["line_gap"])
    if r["text_h"]:
        print("行距系数   : %.4f  (行距 / 字高)"
              % (float(r["line_gap"]) / float(r["text_h"])))
    print()
    print("── 竖向梁 (Y向, 文字 r=90, 自左而右) %d 组 ──" % len(r["v"]))
    for row in r["v"]:
        print("   y=%-9.0f" % row[0]["pos"][1],
              "  →  ".join("%s" % e["t"] for e in row))
    print()
    print("── 横向梁 (X向, 文字 r=0, 自上而下) %d 组 ──" % len(r["h"]))
    for col in r["h"]:
        print("   x=%-9.0f" % col[0]["pos"][0],
              "  ↓  ".join("%s" % e["t"] for e in col))



def guess_type(name):
    """按模板名猜类型（--add 未指定 --type 时用）。"""
    if "柱" in name:
        return "柱详图"
    if "梁" in name:
        return "梁平法配筋图"
    if "板" in name:
        return "楼板配筋图"
    if "框" in name or "A1" in name.upper():
        return "A1图框"
    return "通用"


def _gbk_recover(s):
    """修复无 $DWGCODEPAGE 的 GBK 编码 DXF 文本（ezdxf 按 cp1252 误读成乱码）。

    仅当文本可无损 cp1252\u2192GBK 回环且结果含汉字时才改写；纯英文/数字/%%转义不受影响。
    """
    try:
        raw_b = s.encode("cp1252")
    except UnicodeEncodeError:
        return s
    if not any(0x80 <= b <= 0xFF for b in raw_b):
        return s
    try:
        fixed = raw_b.decode("gbk")
    except UnicodeDecodeError:
        return s
    if fixed != s and any("\u4e00" <= ch <= "\u9fff" for ch in fixed):
        return fixed
    return s


def _decode_unicode_escapes(s):
    """解码天正/TSSD DXF 文本里的 \\U+XXXX 中文转义。"""
    return re.sub(r"\\U\+([0-9A-Fa-f]{4})",
                  lambda m: chr(int(m.group(1), 16)), s)


_DIM_KEYS = ["dimtxt", "dimasz", "dimtsz", "dimscale", "dimtad", "dimexe",
             "dimexo", "dimlfac", "dimclrd", "dimclre", "dimclrt", "dimtxsty"]


def _update_index(templates_dir, name, ttype, version, nlayers, ntexts, comp):
    """把新模板追加进 references/templates_index.md（存在则更新，best-effort）。

    comp: 构件标签字符串，如 "梁33" / "板6" / "柱4 其他5"。
    """
    root = os.path.dirname(os.path.abspath(templates_dir))
    for idx in (os.path.join(root, "references", "templates_index.md"),
                os.path.join(root, "skill", "references", "templates_index.md")):
        if not os.path.isfile(idx):
            continue
        try:
            with open(idx, "r", encoding="utf-8") as f:
                t = f.read()
            if ("| `%s` |" % name) in t:
                return True
            sep = "|------|------|---------|------|------|------|"
            if sep not in t:
                return False
            row = "| `%s` | %s | %s | %d | %d | %s |" % (
                name, ttype or "通用", version, nlayers, ntexts, comp)
            nl = "\r\n" if "\r\n" in t else "\n"
            with open(idx, "w", encoding="utf-8", newline="") as f:
                f.write(t.replace(sep, sep + nl + row, 1))
            return True
        except Exception:
            return False
    return False


def add_template(dxf_path, name=None, template_type=None, dest=None):
    """把一张 DXF 登记为新模板，写入 4 件套（需要 ezdxf）。

    参数:
        dxf_path:      源 DXF 路径
        name:          模板名，缺省取 DXF 文件名（去扩展名）
        template_type: 模板类型（柱详图/梁平法配筋图/...），缺省按文件名猜
        dest:          写入目录，缺省为模板库 lib_dir()
    返回:
        写入的模板名
    """
    import ezdxf
    from collections import Counter

    dxf_path = os.path.abspath(dxf_path)
    if not os.path.isfile(dxf_path):
        raise FileNotFoundError("找不到 DXF: %s" % dxf_path)
    if name is None:
        name = os.path.splitext(os.path.basename(dxf_path))[0]
    if template_type is None:
        template_type = guess_type(name)
    target = os.path.abspath(dest) if dest else lib_dir()
    os.makedirs(target, exist_ok=True)

    doc = ezdxf.readfile(dxf_path)
    msp = doc.modelspace()

    def _layer(e):
        """取实体图层。天正 TCH_* 自定义实体无标准 layer 属性，容错跳过。"""
        try:
            return e.dxf.layer
        except Exception:
            return None

    used_layers = {e.dxf.layer for e in msp if _layer(e) is not None}
    layers = []
    for l in doc.layers:
        if l.dxf.name in used_layers or l.dxf.name in ("0", "Defpoints"):
            layers.append({"name": l.dxf.name, "color": l.dxf.color,
                           "linetype": l.dxf.linetype, "lineweight_mm": None,
                           "lineweight_1_100mm": l.dxf.lineweight})
    order = ["S-TAB_TEXT", "S-DIM", "S-REIN", "S-COLU_DE_TEXT", "S-TAB",
             "S-PUB_TEXT", "S-COLU_DE", "0", "Defpoints"]
    layers.sort(key=lambda L: (order.index(L["name"]) if L["name"] in order else 99,
                               L["name"]))

    used_text_styles = {e.dxf.style for e in msp.query("TEXT")}
    dim_names_used = {d.dxf.get("dimstyle", None) or "Standard"
                      for d in msp.query("DIMENSION")}
    arrow_blocks = set()
    for ds in doc.dimstyles:
        if ds.dxf.name in dim_names_used:
            for key in ("dimblk", "dimblk1", "dimblk2"):
                blk = ds.dxf.get(key, None)
                if blk:
                    arrow_blocks.add(blk)
            txs = ds.dxf.get("dimtxsty", None)
            if txs:
                used_text_styles.add(txs)
    text_styles = []
    for s in doc.styles:
        if s.dxf.name in used_text_styles or s.dxf.name == "Standard":
            text_styles.append({"name": s.dxf.name, "font": s.dxf.font,
                                "bigfont": s.dxf.bigfont,
                                "width_factor": s.dxf.width,
                                "height": s.dxf.height})
    dim_styles = []
    for d in doc.dimstyles:
        if d.dxf.name in dim_names_used or d.dxf.name == "Standard":
            entry = {"name": d.dxf.name}
            for k in _DIM_KEYS:
                entry[k] = d.dxf.get(k, None)
            dim_styles.append(entry)

    insert_blocks = {e.dxf.name for e in msp.query("INSERT")}
    blocks = {}
    for b in doc.blocks:
        if b.name in (insert_blocks | arrow_blocks) and not b.name.startswith("*"):
            blocks[b.name] = len(list(b))

    texts = []
    for e in msp.query("TEXT MTEXT"):
        if e.dxftype() == "TEXT":
            t_ = _gbk_recover(_decode_unicode_escapes(e.dxf.text))
            h_ = round(e.dxf.height, 2)
            r_ = round(e.dxf.rotation % 360, 2)
        else:
            t_ = _gbk_recover(_decode_unicode_escapes(e.plain_text()))
            h_ = round(e.dxf.char_height, 2)
            r_ = 0.0
        texts.append({"layer": e.dxf.layer, "text": t_,
                      "pos": [round(e.dxf.insert.x, 2), round(e.dxf.insert.y, 2)],
                      "h": h_, "r": r_})
    texts.sort(key=lambda x: (x["layer"], -x["pos"][1], x["pos"][0]))

    col_kw = ("KZ-", "%%132", "%%131", "基础顶", "角部", "角筋", "箍", "纵筋")
    is_beam_tpl = ("梁" in (template_type or "")) or ("梁" in (name or ""))
    is_slab_tpl = ("板" in (template_type or "")) or ("板" in (name or ""))

    def _bucket(text, layer):
        if is_beam_tpl and (layer.startswith("S-BEAM") or
                            _BEAM_HEAD.match(text) or "%%1" in text):
            return "beams"
        if is_slab_tpl and (layer.startswith("S-FLOOR") or
                            "板" in text or "WB" in text or "h=" in text):
            return "slabs"
        if any(k in text for k in col_kw) and layer != "S-TAB_TEXT":
            return "columns"
        return "others"

    buckets = {"beams": [], "columns": [], "slabs": [], "others": []}
    for x in texts:
        item = {"layer": x["layer"], "text": x["text"], "pos": x["pos"]}
        buckets[_bucket(x["text"], x["layer"])].append(item)

    text_index = {}
    for x in texts:
        text_index.setdefault(x["layer"], []).append(
            {"t": x["text"], "pos": x["pos"], "h": x["h"], "r": x["r"]})

    cnt = Counter(e.dxftype() for e in msp)
    data = {
        "template_name": name,
        "template_type": template_type,
        "source_file": name + ".dxf",
        "source_size_kb": round(os.path.getsize(dxf_path) / 1024.0, 1),
        "acad_version": doc.dxfversion,
        "extracted_at": time.strftime("%Y-%m-%d"),
        "layers": layers,
        "text_styles": text_styles,
        "dim_styles": dim_styles,
        "blocks": blocks,
        "components": buckets,
        "text_index": text_index,
        "entity_counts": dict(cnt),
    }

    import shutil
    shutil.copy2(dxf_path, os.path.join(target, name + ".dxf"))
    with open(os.path.join(target, name + ".template.json"), "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=1)

    L = ["模板: %s（%s）—— 构件参数统计" % (name, template_type), "=" * 60, ""]
    L.append("实体统计: " + ", ".join("%s×%d" % (k, v) for k, v in
             sorted(cnt.items(), key=lambda x: -x[1])))
    for key, label in (("beams", "梁"), ("columns", "柱"),
                       ("slabs", "板"), ("others", "其他")):
        v = data["components"].get(key) or []
        if not v:
            continue
        L.append("")
        L.append("【%s】%d 个" % (label, len(v)))
        for it in v:
            L.append("    [%s] %s" % (it["layer"], it["text"]))
    with open(os.path.join(target, name + "_component_params.txt"), "w",
              encoding="utf-8") as f:
        f.write("\n".join(L) + "\n")

    L = ["模板: %s —— 文本索引（按图层分组）" % name, "=" * 60, ""]
    for lyr in sorted(text_index):
        L.append("[%s]  %d 条" % (lyr, len(text_index[lyr])))
        for it in sorted(text_index[lyr], key=lambda x: (-x["pos"][1], x["pos"][0])):
            L.append("    @(%9.1f,%9.1f) h=%7.1f r=%6.1f  %s"
                     % (it["pos"][0], it["pos"][1], it["h"], it["r"], it["t"]))
        L.append("")
    with open(os.path.join(target, name + "_text_index.txt"), "w",
              encoding="utf-8") as f:
        f.write("\n".join(L) + "\n")

    comp_parts = []
    for key, label in (("beams", "梁"), ("columns", "柱"),
                       ("slabs", "板"), ("walls", "墙"), ("others", "其他")):
        v = buckets.get(key) or []
        if v:
            comp_parts.append("%s%d" % (label, len(v)))
    _update_index(target, name, template_type, doc.dxfversion,
                  len(layers), len(texts), " ".join(comp_parts))
    return name


def main():
    ap = argparse.ArgumentParser(
        description="模板库访问（只读）—— 真实工程 DXF 模板库与本技能的桥")
    ap.add_argument("--list", action="store_true", help="列出所有模板")
    ap.add_argument("--info", metavar="NAME", help="查看模板概况")
    ap.add_argument("--layers", metavar="NAME", help="列出模板图层")
    ap.add_argument("--grep", metavar="RE", help="在所有模板文本里搜正则")
    ap.add_argument("--diff", nargs="?", const="__auto__", metavar="NAME",
                    help="与 cad_standards.LAYERS 比对图层差异（不带参数自动取第一个模板）")
    ap.add_argument("--beam-format", nargs="?", const="__auto__", metavar="NAME",
                    help="反推真实梁集中标注格式（不带参数自动取第一个模板）")
    ap.add_argument("--add", metavar="DXF", help="把一张 DXF 登记为新模板（写入 4 件套）")
    ap.add_argument("--name", metavar="NAME", help="--add 时的模板名（缺省取 DXF 文件名）")
    ap.add_argument("--type", metavar="TYPE", help="--add 时的模板类型（缺省按文件名猜）")
    ap.add_argument("--dest", metavar="DIR", help="--add 写入目录（缺省为模板库）")
    a = ap.parse_args()

    try:
        d = lib_dir()
    except FileNotFoundError as e:
        print(e)
        return 2
    if not any([a.list, a.info, a.layers, a.grep, a.diff, a.beam_format, a.add]):
        a.list = True

    if a.list:
        names = list_templates()
        print("模板库: %s" % d)
        print("共 %d 个模板：" % len(names))
        for n in names:
            try:
                t = load(n)
                comp = t.get("components", {})
                tag = " ".join("%s%d" % (k[0].upper(), len(comp.get(k) or []))
                               for k in ("beams", "columns", "slabs", "walls")
                               if comp.get(k))
                print("  %-34s %-22s 图层%-4d %s"
                      % (n, t.get("template_type", ""), len(t.get("layers", [])), tag))
            except Exception as ex:
                print("  %-34s <读取失败: %s>" % (n, ex))
    if a.info:
        try:
            print(); _p_info(a.info)
        except FileNotFoundError as e:
            print("错误: %s" % e); return 2
    if a.layers:
        try:
            print(); _p_layers(a.layers)
        except FileNotFoundError as e:
            print("错误: %s" % e); return 2
    if a.grep:
        print()
        hits = grep_text(a.grep)
        print("搜索 %r —— 命中 %d 条" % (a.grep, len(hits)))
        for nm, lyr, t, pos, h, r in hits[:80]:
            print("  [%s] %-18s %-28s @(%.0f,%.0f) h=%s r=%s"
                  % (nm[:12], lyr, t, pos[0], pos[1], h, r))
        if len(hits) > 80:
            print("  ... 另有 %d 条" % (len(hits) - 80))
    if a.diff:
        name = None if a.diff == "__auto__" else a.diff
        if name is None:
            name = _first_template()
        print(); _p_diff(name)
    if a.beam_format:
        name = None if a.beam_format == "__auto__" else a.beam_format
        if name is None:
            name = _first_template()
        print(); _p_beam_format(name)
    if a.add:
        print()
        nm = add_template(a.add, name=a.name, template_type=a.type, dest=a.dest)
        print("已写入模板: %s（--list 可见；新模板名=%s）" % (a.add, nm))
    return 0


if __name__ == "__main__":
    sys.exit(main())
