"""天正构件静态块库融合链路自检。

验证点：
1. 构件目录可读、至少含一项；
2. bench 可生成 3 个 INSERT 实例；
3. 真实尺寸换算正确（原始 M0920 缩放 ≈ 461.54，叶宽约 900mm）；
4. 可叠加到已有建筑平面图；
5. 回读 DXF 实例与 catalog 记录一致。

用法：
  python verify_tarch_parts.py
"""
from __future__ import annotations

import json
import math
import sys
from pathlib import Path

import ezdxf
from ezdxf.math import Matrix44

SCRIPT_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPT_DIR))
from gen_tarch_parts import (load_catalog, new_doc, part_path, place,
                             compute_scale, auto_block_name, measure_characteristic_length)  # noqa: E402

SKILL_DIR = SCRIPT_DIR.parent
PARTS_DIR = SKILL_DIR / "tarch_parts"
OUT_DIR = SKILL_DIR / "output"
OUT_DIR.mkdir(exist_ok=True)


def check_catalog() -> bool:
    parts = load_catalog()
    print(f"[CHECK] 目录项数：{len(parts)}")
    for name in parts:
        p = parts[name]
        src = part_path(p)
        ok = src.exists()
        print(f"        {name}: file={p['file']} exists={ok}")
        if not ok:
            return False
    return len(parts) > 0


def check_bench() -> bool:
    doc = new_doc()
    parts = load_catalog()
    name = list(parts.keys())[0]
    p = parts[name]
    src = part_path(p)
    block = p.get("block") or auto_block_name(src)

    s1 = place(doc, name, 0, 0, rotation=0)
    s2 = place(doc, name, 1500, 0, rotation=0, scale_mul=1.2)
    s3 = place(doc, name, 3000, 0, rotation=90)

    inserts = list(doc.modelspace().query("INSERT"))
    if len(inserts) != 3:
        print(f"[FAIL] INSERT 数量应为 3，实际 {len(inserts)}")
        return False

    # 校验尺寸：原始缩放 * 特征长度 ≈ nominal_mm
    real_scale = compute_scale(p, src, block)
    L0 = measure_characteristic_length(src, block)
    real_leaf = L0 * real_scale
    nominal = float(p.get("nominal_mm", 900))
    print(f"[CHECK] 原始缩放={real_scale:.2f}，特征长度={L0:.3f}，真实叶宽={real_leaf:.1f}mm，标称={nominal}mm")
    if abs(real_leaf - nominal) / nominal > 0.05:
        print(f"[FAIL] 真实叶宽偏离标称 > 5%")
        return False

    # 校验旋转90°后 x/y 方向互换
    ins3 = inserts[2]
    if abs(ins3.dxf.rotation - 90) > 1e-3:
        print(f"[FAIL] 第三实例旋转角应为 90，实际 {ins3.dxf.rotation}")
        return False

    out = OUT_DIR / "门bench_verify.dxf"
    doc.saveas(str(out))
    print(f"[OK] bench 验证通过：{out}")
    return True


def check_overlay() -> bool:
    base = SKILL_DIR / "templates" / "建筑平面_小户型_5600x6800.dxf"
    if not base.exists():
        print(f"[SKIP] 基底模板不存在，跳过叠加测试")
        return True
    doc = ezdxf.readfile(str(base))
    parts = load_catalog()
    name = list(parts.keys())[0]
    place(doc, name, 1500, 1000, rotation=0)
    out = OUT_DIR / "建筑平面_小户型_加门_verify.dxf"
    doc.saveas(str(out))
    print(f"[OK] 叠加验证通过：{out}")
    return True


def main() -> int:
    print("=== 天正构件静态块库融合链路自检 ===")
    ok = True
    ok = check_catalog() and ok
    ok = check_bench() and ok
    ok = check_overlay() and ok
    if ok:
        print("\n[OK] 全部验证通过")
        return 0
    print("\n[FAIL] 验证失败")
    return 1


if __name__ == "__main__":
    sys.exit(main())
