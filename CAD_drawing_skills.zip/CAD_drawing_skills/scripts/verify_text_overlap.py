# -*- coding: utf-8 -*-
"""只读验证工具：检测 CAD 中各类文字标注是否相互重叠。

连接已打开的 AutoCAD，回读文字实体（轴号 / 柱号 / 梁标注 / 总说明），
用 GetBoundingBox() 真实包围盒做两两 AABB 相交检测，输出重叠明细。

⚠️ comtypes 1.4.16 坑（今日实测，务必照此写）：
  - GetBoundingBox() 是【无参】调用，以返回值 [min, max] 给出包围盒；
  - 返回值的 bb[0] 是 COM 变体数组，不能用 `x0, y0 = bb[0]` 直接解包
    （会 raise "cannot unpack"，被 except 吞掉后看起来就读不到实体）。
    必须：  a, b = bb[0], bb[1]
            x0, y0 = float(a[0]), float(a[1])
  - TextString / InsertionPoint 取不到，故只靠图层过滤 + 几何包围盒检测，
    不依赖文字内容。

用法：
  python verify_text_overlap.py
  python verify_text_overlap.py --tolerance 5   # 重叠判定容差(mm)，默认 2.0
"""
import sys
import os
import argparse

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cad_live import connect

# 参与重叠检测的文字图层（轴号 / 柱号 / 梁集中标注 3 行 / 总说明）
CHECK_LAYERS = ["S-AXIS_TEXT", "S-COLU_NUM", "S-BEAM_ID", "S-STIRRUP", "S-TEXT"]


def bbox(e):
    """取实体真实包围盒，返回 (minx, miny, maxx, maxy) 或 None。"""
    try:
        bb = e.GetBoundingBox()           # 无参调用
        a, b = bb[0], bb[1]
        x0, y0 = float(a[0]), float(a[1])
        x1, y1 = float(b[0]), float(b[1])
        return (x0, y0, x1, y1)
    except Exception:
        return None


def overlaps(b1, b2, tol):
    """AABB 是否相交（容差 tol 内接触不算重叠）。"""
    return not (b1[2] <= b2[0] + tol or b2[2] <= b1[0] + tol or
                b1[3] <= b2[1] + tol or b2[3] <= b1[1] + tol)


def main():
    ap = argparse.ArgumentParser(description="检测 CAD 文字标注重叠（只读）")
    ap.add_argument("--tolerance", type=float, default=2.0,
                    help="重叠判定容差(mm)，默认 2.0")
    args = ap.parse_args()
    tol = args.tolerance

    try:
        app = connect()
        doc = app.ActiveDocument
        msp = doc.ModelSpace
        print("已连接 -> %s %s" % (app.Application.Name, app.Version))
    except Exception as e:
        print("FAILED: 无法连接 AutoCAD: %s" % e)
        return

    total = int(msp.Count)
    items = []      # (layer, bbox)
    skipped = 0
    for i in range(total):
        try:
            e = msp.Item(i)
            lyr = str(e.Layer)
            if lyr not in CHECK_LAYERS:
                continue
            b = bbox(e)
            if b is None:
                skipped += 1
                continue
            items.append((lyr, b))
        except Exception:
            continue

    print("参与检测文字实体 %d 个（跳过 %d 个取不到包围盒）"
          % (len(items), skipped))

    n = len(items)
    hits = []
    for i in range(n):
        for j in range(i + 1, n):
            if overlaps(items[i][1], items[j][1], tol):
                hits.append((items[i][0], items[j][0]))
                print("  [重叠] %s  ×  %s" % (items[i][0], items[j][0]))

    print("重叠对数：%d" % len(hits))
    print("TEXT_OVERLAP=OK" if not hits else "TEXT_OVERLAP=FAIL")
    print("DONE")


if __name__ == "__main__":
    main()
